package com.booking.roomdetails.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.util.List;
import java.util.stream.Collectors;

/**
 * Represents the "Room Details" lightbox/modal that opens when a user
 * clicks a room name on the Hotel Page. This is the core object under test.
 *
 * Booking.com renders this as a modal dialog (role="dialog") containing:
 *  - Room title
 *  - Image gallery
 *  - Bed configuration
 *  - Size (sq m / sq ft)
 *  - A list of amenities/facilities
 *  - Price summary
 *  - A "Reserve" / "Select rooms" call-to-action
 *
 * As with the other pages: data-testid values are the most stable selectors
 * Booking.com offers, but they DO change between deployments/AB tests.
 * Confirm each one against the live DOM with DevTools before trusting it
 * in a CI pipeline.
 */
public class RoomDetailsPage extends BasePage {

    private final By modalDialog = By.cssSelector("div[role='dialog']");
    private final By roomTitle = By.cssSelector("div[role='dialog'] h3, div[role='dialog'] [data-testid='room-name']");
    private final By roomImages = By.cssSelector("div[role='dialog'] img");
    private final By bedConfiguration = By.cssSelector("[data-testid='bed-configuration'], div.hprt-roomtype-bed");
    private final By roomSize = By.xpath("//div[@role='dialog']//span[contains(text(),'m²') or contains(text(),'ft²')]");
    private final By facilitiesList = By.cssSelector("[data-testid='facility-badge'], li.bui-list__item");
    private final By priceSummary = By.cssSelector("[data-testid='price-and-discounted-price'], .prco-valign-middle-helper");
    private final By closeButton = By.cssSelector("button[aria-label='Close'], button[data-testid='modal-close-button']");
    private final By reserveButton = By.xpath("//button[contains(.,'Reserve') or contains(.,'Select rooms')]");

    public RoomDetailsPage(WebDriver driver) {
        super(driver);
        waitUtils.waitForVisible(modalDialog);
    }

    public boolean isDisplayed() {
        return waitUtils.waitForVisible(modalDialog).isDisplayed();
    }

    public String getRoomTitle() {
        return getText(roomTitle);
    }

    public int getImagesCount() {
        return findAll(roomImages).size();
    }

    public String getBedConfiguration() {
        try {
            return getText(bedConfiguration);
        } catch (Exception e) {
            return "";
        }
    }

    public String getRoomSize() {
        try {
            return getText(roomSize);
        } catch (Exception e) {
            return "";
        }
    }

    public List<String> getFacilities() {
        return findAll(facilitiesList).stream()
                .map(WebElement::getText)
                .filter(text -> !text.isBlank())
                .collect(Collectors.toList());
    }

    public String getPriceSummary() {
        try {
            return getText(priceSummary);
        } catch (Exception e) {
            return "";
        }
    }

    public boolean isReserveButtonEnabled() {
        WebElement btn = waitUtils.waitForVisible(reserveButton);
        return btn.isEnabled();
    }

    public void close() {
        click(closeButton);
        waitUtils.waitForInvisibility(modalDialog);
    }
}
