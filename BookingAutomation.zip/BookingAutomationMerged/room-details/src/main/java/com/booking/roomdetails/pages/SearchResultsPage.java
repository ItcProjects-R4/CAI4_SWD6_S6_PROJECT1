package com.booking.roomdetails.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.util.List;
import java.util.Set;

/**
 * Represents the search results listing page
 * (URL contains "searchresults.html").
 *
 * Each hotel is rendered as a "property card". Booking.com identifies these
 * cards with data-testid="property-card" — verify this still holds via
 * DevTools before relying on it long-term.
 */
public class SearchResultsPage extends BasePage {

    private final By propertyCards = By.cssSelector("div[data-testid='property-card']");
    private final By propertyTitleLink = By.cssSelector("a[data-testid='title-link']");
    private final By propertyTitle = By.cssSelector("div[data-testid='title']");

    public SearchResultsPage(WebDriver driver) {
        super(driver);
        dismissSignInPopupIfPresent();
    }

    public int getResultsCount() {
        return findAll(propertyCards).size();
    }

    /**
     * Opens the Nth hotel (0-indexed) from the results list.
     * Booking.com opens the hotel page in a NEW browser tab, so this method
     * also switches Selenium's focus to that new tab/window and returns a
     * HotelPage object bound to it.
     */
    public HotelPage openHotelByIndex(int index) {
        List<WebElement> cards = findAll(propertyCards);
        WebElement card = cards.get(index);
        scrollIntoView(card);

        String originalWindow = driver.getWindowHandle();
        WebElement link = card.findElement(propertyTitleLink);
        link.click();

        switchToNewTab(originalWindow);
        return new HotelPage(driver);
    }

    public HotelPage openHotelByName(String hotelName) {
        List<WebElement> cards = findAll(propertyCards);
        String originalWindow = driver.getWindowHandle();

        for (WebElement card : cards) {
            String title = card.findElement(propertyTitle).getText();
            if (title.equalsIgnoreCase(hotelName) || title.contains(hotelName)) {
                scrollIntoView(card);
                card.findElement(propertyTitleLink).click();
                switchToNewTab(originalWindow);
                return new HotelPage(driver);
            }
        }
        throw new RuntimeException("Hotel with name '" + hotelName + "' was not found in search results.");
    }

    private void switchToNewTab(String originalWindow) {
        waitUtils.waitForUrlContains(""); // small settle point before switching
        Set<String> allWindows = driver.getWindowHandles();
        for (String handle : allWindows) {
            if (!handle.equals(originalWindow)) {
                driver.switchTo().window(handle);
                break;
            }
        }
    }
}
