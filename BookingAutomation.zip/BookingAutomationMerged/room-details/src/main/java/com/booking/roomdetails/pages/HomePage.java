package com.booking.roomdetails.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;

import java.time.Duration;
import java.util.List;

/**
 * Represents https://www.booking.com/ (the landing / search page).
 *
 * IMPORTANT: Booking.com is an A/B-tested, frequently-redesigned site.
 * The locators below are based on the data-testid attributes Booking.com
 * has commonly used. Before running, open DevTools (Ctrl+Shift+I),
 * inspect each field, and confirm/update the locator if it has changed.
 */
public class HomePage extends BasePage {

    // --- Locators ---
    private final By destinationInput = By.cssSelector("input[name='ss']");
    private final By destinationSuggestionList = By.cssSelector("ul[role='listbox'] li");
    private final By searchButton = By.cssSelector("button[type='submit']");

    // Occupancy / "Group" dropdown (adults, children, rooms)
    private final By occupancyDropdownTrigger = By.cssSelector("button[data-testid='occupancy-config']");
    private final By increaseRoomsButton = By.cssSelector("button[aria-label='Increase number of Rooms']");
    private final By decreaseRoomsButton = By.cssSelector("button[aria-label='Decrease number of Rooms']");
    private final By increaseAdultsButton = By.cssSelector("button[aria-label='Increase number of Adults']");
    private final By occupancyApplyButton = By.xpath("//button[text()='Done' or contains(.,'Done')]");

    // Date picker
    private final By checkInDateCell = By.cssSelector("span[data-date='%s']");

    public HomePage(WebDriver driver) {
        super(driver);
    }

    public HomePage navigateTo() {
        driver.get("https://www.booking.com/");
        dismissSignInPopupIfPresent();
        return this;
    }

    /**
     * Types the destination and selects the first matching suggestion
     * from the autocomplete dropdown.
     */
    public HomePage searchDestination(String destination) {
        type(destinationInput, destination);
        waitUtils.waitForVisible(destinationSuggestionList);
        List<WebElement> suggestions = findAll(destinationSuggestionList);
        if (!suggestions.isEmpty()) {
            suggestions.get(0).click();
        }
        return this;
    }

    /**
     * Selects check-in and check-out dates from the calendar widget.
     * Dates must be passed in the format the calendar uses: yyyy-MM-dd
     * (this matches the `data-date` attribute booking.com renders on each
     * day cell — verify this in DevTools as it has changed in the past).
     */
    public HomePage selectDates(String checkInDate, String checkOutDate) {
        By checkIn = By.cssSelector(String.format("span[data-date='%s']", checkInDate));
        By checkOut = By.cssSelector(String.format("span[data-date='%s']", checkOutDate));
        click(checkIn);
        click(checkOut);
        return this;
    }

    public HomePage setOccupancy(int rooms, int adults) {
        click(occupancyDropdownTrigger);

        // Rooms default to 1, so click increase (rooms - 1) times
        for (int i = 1; i < rooms; i++) {
            click(increaseRoomsButton);
        }
        // Adults default to 2, adjust accordingly in real usage; here we just
        // demonstrate the increase action for clarity/extension.
        for (int i = 2; i < adults; i++) {
            click(increaseAdultsButton);
        }

        click(occupancyApplyButton);
        return this;
    }

    public SearchResultsPage clickSearch() {
        click(searchButton);
        waitUtils.waitForUrlContains("searchresults");
        return new SearchResultsPage(driver);
    }
}
