package com.booking.roomdetails.pages;

import com.booking.roomdetails.utils.WaitUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import java.util.List;

/**
 * Parent class for every Page Object.
 * Holds the driver reference, the WaitUtils helper, and small reusable
 * actions shared across pages (e.g. closing a cookie/sign-in popup, which
 * Booking.com shows unpredictably on almost every page).
 */
public abstract class BasePage {

    protected WebDriver driver;
    protected WaitUtils waitUtils;

    public BasePage(WebDriver driver) {
        this.driver = driver;
        this.waitUtils = new WaitUtils(driver);
        PageFactory.initElements(driver, this);
    }

    protected void click(By locator) {
        waitUtils.click(locator);
    }

    protected void type(By locator, String text) {
        waitUtils.type(locator, text);
    }

    protected String getText(By locator) {
        return waitUtils.waitForVisible(locator).getText();
    }

    protected List<WebElement> findAll(By locator) {
        return waitUtils.waitForAllVisible(locator);
    }

    protected void scrollIntoView(WebElement element) {
        ((JavascriptExecutor) driver).executeScript(
                "arguments[0].scrollIntoView({block: 'center'});", element);
    }

    /**
     * Booking.com frequently shows a "Sign in" / genius promo modal on load.
     * It is not guaranteed to appear (varies by locale, cookies, A/B test),
     * so this is a best-effort, non-failing dismissal.
     * NOTE: verify this selector in DevTools — booking.com rotates the
     * data-testid / aria-label used for the modal close button often.
     */
    public void dismissSignInPopupIfPresent() {
        try {
            By closeButton = By.cssSelector("button[aria-label='Dismiss sign-in info.']");
            if (!driver.findElements(closeButton).isEmpty()) {
                driver.findElement(closeButton).click();
            }
        } catch (Exception ignored) {
            // Popup didn't appear — nothing to do.
        }
    }

    /**
     * Switches Selenium's focus into the first available iframe matching a
     * partial title/name, used for things like the room-details lightbox or
     * map widgets that booking.com sometimes renders inside an iframe.
     */
    protected void switchToFrameIfPresent(By frameLocator) {
        List<WebElement> frames = driver.findElements(frameLocator);
        if (!frames.isEmpty()) {
            driver.switchTo().frame(frames.get(0));
        }
    }

    protected void switchToDefaultContent() {
        driver.switchTo().defaultContent();
    }
}
