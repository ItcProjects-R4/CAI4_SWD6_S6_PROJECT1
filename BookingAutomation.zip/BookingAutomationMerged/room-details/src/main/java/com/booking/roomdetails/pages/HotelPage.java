package com.booking.roomdetails.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.util.List;

/**
 * Represents an individual hotel's page (where the rooms table —
 * "hprt-table" historically — is shown, along with a "Room Details" /
 * "See availability" link per room row that opens the room details
 * lightbox/modal).
 *
 * NOTE ON SELECTORS: Booking.com's hotel page table structure has changed
 * multiple times over the years (class names like "hprt-table",
 * "js-hprt-table-room-link" etc. have existed historically). ALWAYS
 * re-verify with DevTools before a real test run. The selectors here are
 * written defensively (data-testid first, fallback to text/aria where
 * possible) to reduce breakage, but they are not guaranteed to be 100%
 * current — that part is on you to confirm against the live DOM.
 */
public class HotelPage extends BasePage {

    private final By hotelName = By.cssSelector("h2[data-testid='title']");
    private final By roomsTable = By.cssSelector("table#hprt-table, table[data-testid='room-table']");
    private final By roomRows = By.cssSelector("tr.hprt-table-row, tr[data-testid='room-row']");

    // Link/button inside a room row that opens the details lightbox
    private final By roomNameLink = By.cssSelector("span.hprt-roomtype-link, a[data-testid='room-name-link']");

    public HotelPage(WebDriver driver) {
        super(driver);
        dismissSignInPopupIfPresent();
    }

    public String getHotelName() {
        return getText(hotelName);
    }

    public int getAvailableRoomsCount() {
        return findAll(roomRows).size();
    }

    /**
     * Clicks the room name/link for the given row index (0-indexed) to open
     * the Room Details lightbox, and returns a RoomDetailsPage object.
     */
    public RoomDetailsPage openRoomDetails(int roomIndex) {
        List<WebElement> rows = findAll(roomRows);
        WebElement row = rows.get(roomIndex);
        scrollIntoView(row);

        WebElement detailsLink = row.findElement(roomNameLink);
        detailsLink.click();

        return new RoomDetailsPage(driver);
    }

    /**
     * Finds a room row by matching its visible room-type text
     * (e.g. "Deluxe Double Room") and opens its details lightbox.
     */
    public RoomDetailsPage openRoomDetailsByName(String roomTypeName) {
        List<WebElement> rows = findAll(roomRows);
        for (WebElement row : rows) {
            WebElement link = row.findElement(roomNameLink);
            if (link.getText().toLowerCase().contains(roomTypeName.toLowerCase())) {
                scrollIntoView(link);
                link.click();
                return new RoomDetailsPage(driver);
            }
        }
        throw new RuntimeException("Room type '" + roomTypeName + "' was not found on this hotel page.");
    }
}
