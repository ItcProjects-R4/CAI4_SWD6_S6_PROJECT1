package com.booking.roomdetails.tests;

import com.booking.roomdetails.pages.HomePage;
import com.booking.roomdetails.utils.ConfigReader;
import com.booking.roomdetails.utils.DriverManager;
import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;

/**
 * Every test class extends this. Centralizes:
 *  - WebDriver creation/teardown (per-test, thread-safe via ThreadLocal)
 *  - Navigating to the base URL before each test
 *  - Automatic screenshot-on-failure for easier debugging
 */
public abstract class BaseTest {

    protected WebDriver driver;
    protected HomePage homePage;

    @Parameters("browser")
    @BeforeMethod
    public void setUp(String browser) {
        String browserToUse = (browser != null && !browser.isBlank())
                ? browser
                : ConfigReader.get("browser");

        driver = DriverManager.initDriver(browserToUse);
        homePage = new HomePage(driver);
    }

    @AfterMethod
    public void tearDown(ITestResult result) {
        if (result.getStatus() == ITestResult.FAILURE) {
            takeScreenshot(result.getName());
        }
        DriverManager.quitDriver();
    }

    private void takeScreenshot(String testName) {
        try {
            File screenshotsDir = new File("test-output/screenshots");
            if (!screenshotsDir.exists()) {
                screenshotsDir.mkdirs();
            }
            File srcFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
            String destPath = "test-output/screenshots/" + testName + "_" + System.currentTimeMillis() + ".png";
            Files.copy(srcFile.toPath(), Paths.get(destPath));
            System.out.println("Screenshot saved: " + destPath);
        } catch (IOException e) {
            System.err.println("Failed to capture screenshot: " + e.getMessage());
        }
    }
}
