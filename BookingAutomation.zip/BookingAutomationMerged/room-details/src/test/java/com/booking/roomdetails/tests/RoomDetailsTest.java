package com.booking.roomdetails.tests;

import com.booking.roomdetails.pages.HotelPage;
import com.booking.roomdetails.pages.RoomDetailsPage;
import com.booking.roomdetails.pages.SearchResultsPage;
import com.booking.roomdetails.utils.ConfigReader;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.List;

/**
 * End-to-end test suite for the "Room Details" feature on Booking.com.
 *
 * Flow under test:
 *   Home page -> search a destination/dates/occupancy -> search results
 *   -> open a hotel -> open a room's "Room Details" -> verify the details
 *      shown in the lightbox.
 *
 * Each @Test method is independent (drives the full flow itself) so tests
 * can run in parallel/in any order without depending on shared state.
 */
public class RoomDetailsTest extends BaseTest {

    @Test(description = "Verify that clicking a room opens the Room Details modal with a non-empty title")
    public void verifyRoomDetailsModalOpensWithTitle() {
        HotelPage hotelPage = searchAndOpenFirstHotel();

        RoomDetailsPage roomDetailsPage = hotelPage.openRoomDetails(0);

        Assert.assertTrue(roomDetailsPage.isDisplayed(), "Room Details modal should be visible.");
        String title = roomDetailsPage.getRoomTitle();
        Assert.assertFalse(title.isBlank(), "Room title inside the details modal should not be empty.");
    }

    @Test(description = "Verify the Room Details modal shows at least one image")
    public void verifyRoomDetailsHasImages() {
        HotelPage hotelPage = searchAndOpenFirstHotel();

        RoomDetailsPage roomDetailsPage = hotelPage.openRoomDetails(0);

        int imageCount = roomDetailsPage.getImagesCount();
        Assert.assertTrue(imageCount > 0, "Room Details modal should contain at least one image.");
    }

    @Test(description = "Verify the Room Details modal lists facilities/amenities")
    public void verifyRoomDetailsHasFacilities() {
        HotelPage hotelPage = searchAndOpenFirstHotel();

        RoomDetailsPage roomDetailsPage = hotelPage.openRoomDetails(0);

        List<String> facilities = roomDetailsPage.getFacilities();
        Assert.assertFalse(facilities.isEmpty(), "Expected at least one facility/amenity to be listed.");
    }

    @Test(description = "Verify the Room Details modal displays a price summary")
    public void verifyRoomDetailsHasPrice() {
        HotelPage hotelPage = searchAndOpenFirstHotel();

        RoomDetailsPage roomDetailsPage = hotelPage.openRoomDetails(0);

        String price = roomDetailsPage.getPriceSummary();
        Assert.assertFalse(price.isBlank(), "Price summary inside Room Details modal should not be empty.");
    }

    @Test(description = "Verify the Reserve/Select rooms button is enabled inside Room Details")
    public void verifyReserveButtonIsEnabled() {
        HotelPage hotelPage = searchAndOpenFirstHotel();

        RoomDetailsPage roomDetailsPage = hotelPage.openRoomDetails(0);

        Assert.assertTrue(roomDetailsPage.isReserveButtonEnabled(),
                "Reserve / Select rooms button should be enabled by default.");
    }

    @Test(description = "Verify the Room Details modal can be closed and returns to the Hotel page")
    public void verifyRoomDetailsModalCanBeClosed() {
        HotelPage hotelPage = searchAndOpenFirstHotel();

        RoomDetailsPage roomDetailsPage = hotelPage.openRoomDetails(0);
        Assert.assertTrue(roomDetailsPage.isDisplayed());

        roomDetailsPage.close();
        // After closing, the hotel page's room rows should still be available
        Assert.assertTrue(hotelPage.getAvailableRoomsCount() > 0,
                "Hotel page room rows should still be visible after closing the modal.");
    }

    // ---- shared flow helper ----

    /**
     * Drives Home -> Search -> Results -> First Hotel, returning the
     * resulting HotelPage. Shared by all tests in this class to avoid
     * duplicating the same 4-5 navigation steps in every @Test.
     */
    private HotelPage searchAndOpenFirstHotel() {
        SearchResultsPage resultsPage = homePage
                .navigateTo()
                .searchDestination(ConfigReader.get("destination"))
                .selectDates(ConfigReader.get("check.in.date"), ConfigReader.get("check.out.date"))
                .setOccupancy(
                        Integer.parseInt(ConfigReader.get("rooms")),
                        Integer.parseInt(ConfigReader.get("adults")))
                .clickSearch();

        Assert.assertTrue(resultsPage.getResultsCount() > 0, "Search should return at least one hotel result.");

        return resultsPage.openHotelByIndex(0);
    }
}
