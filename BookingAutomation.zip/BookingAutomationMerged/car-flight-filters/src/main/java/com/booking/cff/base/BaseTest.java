package com.booking.cff.base;

import com.booking.cff.utils.ExtentReportManager;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;

import java.time.Duration;

/**
 * BaseTest – shared WebDriver lifecycle for every test class.
 * All page objects and test classes extend this.
 */
public class BaseTest {

    protected WebDriver driver;
    protected WebDriverWait wait;

    public static final String BASE_URL = "https://www.booking.com";

    // ── Test credentials (replace with real values or read from config) ──────
    public static final String TEST_EMAIL    = "your_test_email@example.com";
    public static final String TEST_PASSWORD = "your_test_password";

    @BeforeSuite(alwaysRun = true)
    public void initReport() {
        ExtentReportManager.initReport();
    }

    @BeforeMethod(alwaysRun = true)
    public void setUp() {
        WebDriverManager.chromedriver().setup();

        ChromeOptions options = new ChromeOptions();
        options.addArguments("--start-maximized");
        options.addArguments("--disable-notifications");
        options.addArguments("--disable-popup-blocking");
        options.addArguments("--lang=en-GB");
        options.setExperimentalOption("excludeSwitches", new String[]{"enable-automation"});
        options.setExperimentalOption("useAutomationExtension", false);

        driver = new ChromeDriver(options);
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
        driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(30));
        wait = new WebDriverWait(driver, Duration.ofSeconds(20));
    }

    @AfterMethod(alwaysRun = true)
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
        ExtentReportManager.flushReport();
    }
}
