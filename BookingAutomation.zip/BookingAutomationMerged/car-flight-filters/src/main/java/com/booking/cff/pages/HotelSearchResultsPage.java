package com.booking.cff.pages;

import com.booking.cff.utils.SeleniumUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.util.List;

/**
 * HotelSearchResultsPage – selects a hotel from the search list
 * and navigates to its room-selection / checkout page.
 * Used as a stepping stone before PaymentPage.
 */
public class HotelSearchResultsPage {

    private final WebDriver driver;
    private final SeleniumUtils utils;

    // ── Locators ─────────────────────────────────────────────────────────────

    private final By hotelCards       = By.cssSelector(
            "[data-testid='property-card'], " +
            "[data-testid='search-result-property'], " +
            "div[data-capla-component*='Property']");

    private final By firstHotelLink   = By.cssSelector(
            "[data-testid='property-card'] a[data-testid='title-link'], " +
            "[data-testid='property-card']:first-of-type a");

    private final By reserveBtn       = By.cssSelector(
            "[data-testid='reservation-block-reserve-button'], " +
            "button[data-testid*='reserve'], " +
            "a[data-testid='book-button']");

    private final By roomSelectBtn    = By.cssSelector(
            "[data-testid='select-room-cta'], " +
            "a[data-testid='select-room'], " +
            "button[data-testid='hb-cta']");

    public HotelSearchResultsPage(WebDriver driver) {
        this.driver = driver;
        this.utils  = new SeleniumUtils(driver);
    }

    /**
     * Click the first hotel in the results list.
     * Opens hotel detail in a new tab – we switch to it.
     */
    public void openFirstHotel() {
        utils.waitForVisible(firstHotelLink).click();
        utils.sleep(1500);
        // Switch to new tab if hotel detail opened there
        if (driver.getWindowHandles().size() > 1) {
            utils.switchToNewTab();
        }
    }

    /**
     * On the hotel detail page, click "Reserve" / "Book now" for the first room.
     */
    public void selectFirstRoom() {
        try {
            utils.waitForClickable(reserveBtn).click();
        } catch (Exception e) {
            utils.jsClick(roomSelectBtn);
        }
    }

    public boolean hasHotelResults() {
        return !driver.findElements(hotelCards).isEmpty();
    }
}
