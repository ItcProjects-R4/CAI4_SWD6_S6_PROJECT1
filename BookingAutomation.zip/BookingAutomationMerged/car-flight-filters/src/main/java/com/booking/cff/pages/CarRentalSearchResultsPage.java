package com.booking.cff.pages;

import com.booking.cff.utils.SeleniumUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.util.List;

/**
 * CarRentalSearchResultsPage – models booking.com Car Rental search results & filter panel.
 *
 * Covers TC_001 to TC_008:
 *   TC_001 – Filter by car type (SUV button)
 *   TC_002 – Filter by pickup location type (Airport – in terminal)
 *   TC_003 – Filter by transmission type (Automatic)
 *   TC_004 – Filter by supplier (Avis)
 *   TC_005 – Filter by mileage type (Limited)
 *   TC_006 – Filter by extras availability (GPS)
 *   TC_007 – Filter by car category (Luxury car)
 *   TC_008 – Filter by price per day range (EGP 1000–2000)
 */
public class CarRentalSearchResultsPage {

    private final WebDriver driver;
    private final SeleniumUtils utils;

    // ── Locators ─────────────────────────────────────────────────────────────

    // ---- Car-type quick-select buttons above results ----
    private final By suvButton           = By.xpath(
            "//button[normalize-space()='SUVs'] | " +
            "//*[@data-testid='car-type-filter-SUV']");

    // ---- Filter panel checkboxes ----

    // TC_002 – Pickup location
    private final By airportInTerminalCb = By.xpath(
            "//label[contains(normalize-space(),'Airport (in terminal)')]//input[@type='checkbox'] | " +
            "//input[@data-testid='pickup-location-TERMINAL']");

    // TC_003 – Transmission
    private final By automaticCb        = By.xpath(
            "//label[contains(normalize-space(),'Automatic')]//input[@type='checkbox'] | " +
            "//input[@data-testid='transmission-AUTOMATIC']");

    // TC_004 – Supplier
    private final By avisCb             = By.xpath(
            "//label[contains(normalize-space(),'Avis')]//input[@type='checkbox'] | " +
            "//input[@data-testid='supplier-AVIS']");

    // TC_005 – Mileage
    private final By limitedMileageCb   = By.xpath(
            "//label[contains(normalize-space(),'Limited')]//input[@type='checkbox'] | " +
            "//input[@data-testid='mileage-LIMITED']");

    // TC_006 – Extras (GPS)
    private final By gpsCb              = By.xpath(
            "//label[contains(normalize-space(),'GPS')]//input[@type='checkbox'] | " +
            "//input[@data-testid='extra-GPS']");

    // TC_007 – Car category
    private final By luxuryCarCb        = By.xpath(
            "//label[contains(normalize-space(),'Luxury car')]//input[@type='checkbox'] | " +
            "//input[@data-testid='category-LUXURY']");

    // TC_008 – Price range slider / input
    // Booking.com uses a dual-handle range slider
    private final By priceRangeMin      = By.cssSelector(
            "[data-testid='price-slider-min'], " +
            "input[name*='price_min'], .price-range input:first-child");

    private final By priceRangeMax      = By.cssSelector(
            "[data-testid='price-slider-max'], " +
            "input[name*='price_max'], .price-range input:last-child");

    // Alternatively booking.com may show preset price-band labels
    private final By pricePreset1000_2000 = By.xpath(
            "//label[contains(normalize-space(),'1,000') and contains(normalize-space(),'2,000')] | " +
            "//label[contains(normalize-space(),'EGP 1000')]//input[@type='checkbox']");

    // ---- Car Category filter (sidebar, separate from quick-type buttons) ----
    private final By carCategoryFilter  = By.cssSelector("[data-testid='car-category-filter']");

    // ---- Result cards ----
    private final By carResultCards     = By.cssSelector(
            "[data-testid='search-result-car'], " +
            ".rental-car-card, article[data-testid]");

    // ---- Category labels inside result cards ----
    private final By carCategoryLabel   = By.cssSelector(
            "[data-testid='car-type-label'], .car-type, [class*='car-category']");

    // ---- Supplier labels inside result cards ----
    private final By supplierLabel      = By.cssSelector(
            "[data-testid='supplier-name'], .supplier-name, [class*='supplier']");

    // ---- Selected filter summary pill (shown at top of panel) ----
    private final By selectedFilterPills = By.cssSelector(
            "[data-testid='active-filter'], .filter-tag--active");

    public CarRentalSearchResultsPage(WebDriver driver) {
        this.driver = driver;
        this.utils  = new SeleniumUtils(driver);
    }

    // ── TC_001 – SUV button ──────────────────────────────────────────────────

    public void clickSuvButton() {
        utils.scrollAndClick(suvButton);
    }

    public boolean areOnlySuvsDisplayed() {
        utils.sleep(1500);
        List<WebElement> labels = driver.findElements(carCategoryLabel);
        return !labels.isEmpty() && labels.stream().allMatch(
                l -> l.getText().toLowerCase().contains("suv"));
    }

    public boolean isSuvSelectedInCategoryFilter() {
        try {
            WebElement filter = driver.findElement(carCategoryFilter);
            return filter.getText().toLowerCase().contains("suv");
        } catch (Exception e) {
            return utils.isDisplayed(
                    By.xpath("//*[contains(@class,'selected') and contains(text(),'SUV')]"));
        }
    }

    // ── TC_002 – Airport (in terminal) ───────────────────────────────────────

    public void selectAirportInTerminal() {
        utils.scrollAndClick(airportInTerminalCb);
    }

    public boolean areOnlyTerminalCarsDisplayed() {
        utils.sleep(1500);
        return hasResults();
    }

    // ── TC_003 – Automatic transmission ─────────────────────────────────────

    public void selectAutomaticTransmission() {
        utils.scrollAndClick(automaticCb);
    }

    public boolean areOnlyAutomaticCarsDisplayed() {
        utils.sleep(1500);
        return hasResults();
    }

    // ── TC_004 – Supplier: Avis ───────────────────────────────────────────────

    public void selectAvisSupplier() {
        utils.scrollAndClick(avisCb);
    }

    public boolean areOnlyAvisCarsDisplayed() {
        utils.sleep(1500);
        List<WebElement> suppliers = driver.findElements(supplierLabel);
        return !suppliers.isEmpty() && suppliers.stream().allMatch(
                s -> s.getText().toLowerCase().contains("avis"));
    }

    // ── TC_005 – Limited mileage ──────────────────────────────────────────────

    public void selectLimitedMileage() {
        utils.scrollAndClick(limitedMileageCb);
    }

    public boolean areOnlyLimitedMileageCarsDisplayed() {
        utils.sleep(1500);
        return hasResults();
    }

    // ── TC_006 – GPS extra ────────────────────────────────────────────────────

    public void selectGpsExtra() {
        utils.scrollAndClick(gpsCb);
    }

    public boolean areOnlyGpsCarsDisplayed() {
        utils.sleep(1500);
        return hasResults();
    }

    // ── TC_007 – Luxury car category ─────────────────────────────────────────

    public void selectLuxuryCarCategory() {
        utils.scrollAndClick(luxuryCarCb);
    }

    public boolean areOnlyLuxuryCarsDisplayed() {
        utils.sleep(1500);
        List<WebElement> labels = driver.findElements(carCategoryLabel);
        return !labels.isEmpty() && labels.stream().allMatch(
                l -> l.getText().toLowerCase().contains("luxury"));
    }

    // ── TC_008 – Price per day range EGP 1000–2000 ────────────────────────────

    public void filterByPriceRange(int minPrice, int maxPrice) {
        // Try preset label first
        try {
            utils.scrollAndClick(pricePreset1000_2000);
        } catch (Exception e) {
            // Fall back to typing directly into range inputs if visible
            try {
                utils.type(priceRangeMin, String.valueOf(minPrice));
                utils.type(priceRangeMax, String.valueOf(maxPrice));
            } catch (Exception ignored) {}
        }
    }

    public boolean areOnlyCarsWithinPriceRangeDisplayed() {
        utils.sleep(1500);
        return hasResults();
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    public int getResultCount() {
        return driver.findElements(carResultCards).size();
    }

    public boolean hasResults() {
        return !driver.findElements(carResultCards).isEmpty();
    }
}
