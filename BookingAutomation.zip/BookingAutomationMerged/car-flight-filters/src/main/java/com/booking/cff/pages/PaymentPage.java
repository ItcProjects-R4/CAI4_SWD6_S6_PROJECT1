package com.booking.cff.pages;

import com.booking.cff.utils.SeleniumUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.util.List;

/**
 * PaymentPage – models the booking.com checkout / payment page.
 *
 * Covers:
 *   TC01 – Successful payment with valid card
 *   TC02 – Cancel payment process
 *   TC03 – Payment with invalid card details
 *   TC04 – Successful booking when payment is set to "Pay at Hotel"
 */
public class PaymentPage {

    private final WebDriver driver;
    private final SeleniumUtils utils;

    // ── Locators ─────────────────────────────────────────────────────────────

    // ---- Payment method radio buttons ----
    private final By creditCardRadio      = By.cssSelector(
            "input[type='radio'][value*='card'], " +
            "[data-testid='payment-method-credit-card']");

    private final By payAtHotelOption     = By.cssSelector(
            "[data-testid='pay-at-property-payment-method'], " +
            "label[for*='pay_at_hotel'], " +
            "input[id*='pay_at_hotel']");

    // ---- Card detail fields ----
    // Booking.com renders card fields inside an <iframe>
    private final By cardIframe           = By.cssSelector(
            "iframe[id*='card'], iframe[src*='card'], " +
            "[data-testid='card-iframe'] iframe");

    private final By cardNumberInput      = By.cssSelector(
            "input[id*='card-number'], input[autocomplete='cc-number'], " +
            "input[data-testid='card-number']");

    private final By expiryInput          = By.cssSelector(
            "input[id*='expiry'], input[autocomplete='cc-exp'], " +
            "input[data-testid='card-expiry']");

    private final By cvvInput             = By.cssSelector(
            "input[id*='cvv'], input[id*='cvc'], " +
            "input[autocomplete='cc-csc'], input[data-testid='card-cvc']");

    private final By cardHolderName       = By.cssSelector(
            "input[id*='cardholder'], input[autocomplete='cc-name'], " +
            "input[data-testid='cardholder-name']");

    // ---- Billing info ----
    private final By firstNameInput       = By.id("firstname");
    private final By lastNameInput        = By.id("lastname");
    private final By emailInput           = By.id("email");
    private final By phoneInput           = By.id("phone");

    // ---- Buttons ----
    private final By payNowBtn            = By.cssSelector(
            "button[data-testid='submit-payment'], " +
            "button[type='submit'][class*='pay'], " +
            "button:contains('Pay now'), " +
            "input[type='submit'][value*='Pay']");

    // New robust locator: any visible submit/pay button on the page
    private final By bookNowBtn           = By.cssSelector(
            "[data-testid='book-now-button'], " +
            "button[type='submit']");

    private final By cancelBtn            = By.cssSelector(
            "[data-testid='cancel-button'], " +
            "a[href*='cancel'], " +
            "button[aria-label*='cancel' i]");

    private final By backBtn              = By.cssSelector(
            "button[aria-label*='back' i], " +
            "a[data-testid='back-to-hotel']");

    // ---- Confirmation page indicators ----
    private final By confirmationHeader   = By.cssSelector(
            "[data-testid='confirmation-page-title'], " +
            "h1[class*='confirm'], " +
            ".confirmation-page__title");

    private final By confirmationNumber   = By.cssSelector(
            "[data-testid='booking-confirmation-number'], " +
            "[class*='confirmation-number']");

    private final By bookingPendingMsg    = By.cssSelector(
            "[data-testid='booking-pending'], " +
            "[class*='pending']");

    // ---- Error indicators ----
    private final By cardErrorMessage     = By.cssSelector(
            "[data-testid='card-error-message'], " +
            "[class*='invalid-card'], " +
            ".error-message, [role='alert']");

    private final By invalidCardAlert     = By.cssSelector(
            "[data-testid='payment-error'], " +
            "[aria-live='assertive'], " +
            "[class*='error']");

    // ---- Generic page-level error ----
    private final By pageErrorBanner      = By.cssSelector(
            "[data-testid='error-banner'], .alert-error, [role='alert']");

    public PaymentPage(WebDriver driver) {
        this.driver = driver;
        this.utils  = new SeleniumUtils(driver);
    }

    // ── TC01 – Successful payment with valid card ────────────────────────────

    /**
     * Full happy-path: choose card payment, fill all details, submit.
     */
    public void payWithValidCard(String cardNumber, String expiry, String cvv,
                                 String cardHolder, String firstName,
                                 String lastName,  String email) {
        selectCreditCardPayment();
        fillCardDetailsInIframe(cardNumber, expiry, cvv, cardHolder);
        fillBillingInfo(firstName, lastName, email);
        clickPayNow();
    }

    public void selectCreditCardPayment() {
        utils.jsClick(creditCardRadio);
    }

    /**
     * Card fields may live inside an iframe – we switch into it.
     * If no iframe is found (some builds inline the form), we fall through.
     */
    public void fillCardDetailsInIframe(String cardNumber, String expiry,
                                        String cvv,        String holderName) {
        try {
            WebElement iframeEl = driver.findElement(cardIframe);
            driver.switchTo().frame(iframeEl);
        } catch (Exception ignored) {
            // No iframe – fields are in main DOM
        }
        try {
            utils.type(cardNumberInput, cardNumber);
            utils.type(expiryInput,     expiry);
            utils.type(cvvInput,        cvv);
            utils.type(cardHolderName,  holderName);
        } finally {
            driver.switchTo().defaultContent();
        }
    }

    public void fillBillingInfo(String firstName, String lastName, String email) {
        safeFill(firstNameInput, firstName);
        safeFill(lastNameInput,  lastName);
        safeFill(emailInput,     email);
    }

    public void clickPayNow() {
        utils.jsClick(payNowBtn);
    }

    // ── TC02 – Cancel payment process ───────────────────────────────────────

    public void cancelPayment() {
        try {
            utils.click(cancelBtn);
        } catch (Exception e) {
            // Fall back to browser back button
            driver.navigate().back();
        }
    }

    public void clickBackButton() {
        try {
            utils.click(backBtn);
        } catch (Exception e) {
            driver.navigate().back();
        }
    }

    public boolean isBookingPending() {
        return utils.isDisplayed(bookingPendingMsg) ||
               driver.getCurrentUrl().contains("booking.com/hotel");
    }

    // ── TC03 – Payment with invalid card details ─────────────────────────────

    public void payWithInvalidCard(String badCardNumber, String cvv) {
        selectCreditCardPayment();
        fillCardDetailsInIframe(badCardNumber, "12/30", cvv, "Test User");
        clickPayNow();
    }

    public boolean isCardErrorDisplayed() {
        return utils.isDisplayed(cardErrorMessage) ||
               utils.isDisplayed(invalidCardAlert) ||
               utils.isDisplayed(pageErrorBanner);
    }

    public String getCardErrorText() {
        if (utils.isDisplayed(cardErrorMessage))  return utils.getText(cardErrorMessage);
        if (utils.isDisplayed(invalidCardAlert))  return utils.getText(invalidCardAlert);
        return utils.getText(pageErrorBanner);
    }

    // ── TC04 – Pay at Hotel ──────────────────────────────────────────────────

    public void selectPayAtHotel() {
        // Try primary locator; fall back to searching for the option by text
        try {
            utils.jsClick(payAtHotelOption);
        } catch (Exception e) {
            List<WebElement> labels = driver.findElements(
                    By.xpath("//label[contains(translate(text(),'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz'),'pay at')]"));
            if (!labels.isEmpty()) labels.get(0).click();
        }
    }

    public void clickBookNow() {
        utils.jsClick(bookNowBtn);
    }

    // ── Confirmation checks (shared by TC01 & TC04) ──────────────────────────

    public boolean isConfirmationPageDisplayed() {
        return utils.isDisplayed(confirmationHeader) ||
               driver.getCurrentUrl().contains("confirmation") ||
               driver.getCurrentUrl().contains("thankYou");
    }

    public String getConfirmationNumber() {
        try { return utils.getText(confirmationNumber); }
        catch (Exception e) { return ""; }
    }

    // ── Helper ───────────────────────────────────────────────────────────────

    private void safeFill(By locator, String value) {
        try { utils.type(locator, value); }
        catch (Exception ignored) {}
    }
}
