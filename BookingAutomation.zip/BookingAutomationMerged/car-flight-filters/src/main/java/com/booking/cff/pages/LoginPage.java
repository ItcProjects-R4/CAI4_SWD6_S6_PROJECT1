package com.booking.cff.pages;

import com.booking.cff.utils.SeleniumUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

/**
 * LoginPage – handles both steps of booking.com sign-in flow
 * (email → continue → password → sign in).
 */
public class LoginPage {

    private final WebDriver driver;
    private final SeleniumUtils utils;

    // ── Locators ─────────────────────────────────────────────────────────────
    private final By emailInput          = By.id("username");
    private final By continueBtn         = By.cssSelector("button[type='submit']");
    private final By passwordInput       = By.id("password");
    private final By signInBtn           = By.cssSelector("button[type='submit']");
    private final By errorMessage        = By.cssSelector("[data-testid='error-message']");
    private final By userAccountIcon     = By.cssSelector("[data-testid='header-user-menu-trigger']");

    public LoginPage(WebDriver driver) {
        this.driver = driver;
        this.utils  = new SeleniumUtils(driver);
    }

    // ── Public API ───────────────────────────────────────────────────────────

    public void login(String email, String password) {
        enterEmail(email);
        enterPassword(password);
    }

    public void enterEmail(String email) {
        utils.waitForVisible(emailInput);
        utils.type(emailInput, email);
        utils.click(continueBtn);
    }

    public void enterPassword(String password) {
        utils.waitForVisible(passwordInput);
        utils.type(passwordInput, password);
        utils.click(signInBtn);
    }

    public boolean isLoginSuccessful() {
        try {
            utils.waitForVisible(userAccountIcon);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public boolean isErrorDisplayed() {
        return utils.isDisplayed(errorMessage);
    }

    public String getErrorText() {
        return utils.getText(errorMessage);
    }
}
