package com.booking.cff.utils;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;

/**
 * Singleton wrapper around ExtentReports.
 * Produces a single HTML report at  test-output/ExtentReport.html
 */
public class ExtentReportManager {

    private static ExtentReports extent;
    private static final ThreadLocal<ExtentTest> testThread = new ThreadLocal<>();

    public static void initReport() {
        if (extent == null) {
            ExtentSparkReporter spark = new ExtentSparkReporter("test-output/ExtentReport.html");
            spark.config().setDocumentTitle("Booking.com Automation Report");
            spark.config().setReportName("Booking.com – Filter & Checkout Tests");
            spark.config().setTheme(Theme.DARK);

            extent = new ExtentReports();
            extent.attachReporter(spark);
            extent.setSystemInfo("Framework",  "Selenium 4 + TestNG");
            extent.setSystemInfo("Browser",    "Chrome");
            extent.setSystemInfo("Environment","booking.com – Production");
        }
    }

    public static ExtentTest createTest(String name, String description) {
        ExtentTest test = extent.createTest(name, description);
        testThread.set(test);
        return test;
    }

    public static ExtentTest getTest() {
        return testThread.get();
    }

    public static void flushReport() {
        if (extent != null) {
            extent.flush();
        }
    }
}
