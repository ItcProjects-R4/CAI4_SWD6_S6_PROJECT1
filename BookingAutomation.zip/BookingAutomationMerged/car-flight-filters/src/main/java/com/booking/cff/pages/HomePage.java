package com.booking.cff.pages;

import com.booking.cff.utils.SeleniumUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

/**
 * HomePage – handles the booking.com landing page:
 *   - dismissing cookie / sign-in banners
 *   - entering destination, dates, guests
 *   - clicking "Search"
 */
public class HomePage {

    private final WebDriver driver;
    private final SeleniumUtils utils;

    // ── Locators ─────────────────────────────────────────────────────────────

    // Cookie / consent banner
    private final By cookieAcceptBtn      = By.id("onetrust-accept-btn-handler");
    // Genius / sign-in nudge dismiss
    private final By signInDismissBtn     = By.cssSelector("button[aria-label='Dismiss sign-in info.']");
    // Destination input (new booking.com uses a combobox)
    private final By destinationInput     = By.cssSelector("input[placeholder='Where are you going?']");
    private final By firstSuggestion      = By.cssSelector("[data-testid='autocomplete-result']:first-child");
    // Date picker
    private final By checkInDatePicker    = By.cssSelector("[data-testid='searchbox-datepicker-calendar']");
    private final By searchboxDates       = By.cssSelector("[data-testid='searchbox-dates-container']");
    // Guests
    private final By occupancyConfig      = By.cssSelector("[data-testid='occupancy-config']");
    private final By adultIncreaseBtn     = By.cssSelector("[data-testid='occupancy-config'] button[aria-label*='adults' i][aria-label*='increase' i]");
    // Search button
    private final By searchBtn            = By.cssSelector("button[type='submit'][data-testid='search-button-desktop-hero-default']");
    // Sign-in (top-right)
    private final By signInLink           = By.cssSelector("[data-testid='header-sign-in-button']");

    public HomePage(WebDriver driver) {
        this.driver = driver;
        this.utils  = new SeleniumUtils(driver);
    }

    // ── Public API ───────────────────────────────────────────────────────────

    public void open(String baseUrl) {
        driver.get(baseUrl);
        dismissCookieBanner();
        dismissSignInNudge();
    }

    public void dismissCookieBanner() {
        try {
            utils.waitForClickable(cookieAcceptBtn).click();
        } catch (Exception ignored) {}
    }

    public void dismissSignInNudge() {
        try {
            utils.waitForClickable(signInDismissBtn).click();
        } catch (Exception ignored) {}
    }

    /**
     * Enter destination, pick check-in/check-out dates (by data-date attribute),
     * then click Search.
     *
     * @param destination  city name, e.g. "London"
     * @param checkIn      ISO date string, e.g. "2025-06-01"
     * @param checkOut     ISO date string, e.g. "2025-06-05"
     */
    public void searchHotel(String destination, String checkIn, String checkOut) {
        utils.click(destinationInput);
        utils.type(destinationInput, destination);
        utils.waitForClickable(firstSuggestion).click();

        // Open date picker and pick dates
        try {
            utils.click(searchboxDates);
        } catch (Exception ignored) {}

        selectDate(checkIn);
        selectDate(checkOut);

        utils.click(searchBtn);
    }

    private void selectDate(String isoDate) {
        By dateCell = By.cssSelector("[data-date='" + isoDate + "']");
        utils.waitForClickable(dateCell).click();
    }

    public void clickSignIn() {
        utils.click(signInLink);
    }

    public boolean isOnHomePage() {
        return driver.getCurrentUrl().contains("booking.com");
    }
}
