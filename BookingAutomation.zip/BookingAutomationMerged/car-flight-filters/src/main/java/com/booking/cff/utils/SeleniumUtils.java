package com.booking.cff.utils;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.Date;
import java.util.List;

/**
 * SeleniumUtils – reusable helper methods used by all Page Objects.
 */
public class SeleniumUtils {

    private final WebDriver driver;
    private final WebDriverWait wait;

    public SeleniumUtils(WebDriver driver) {
        this.driver = driver;
        this.wait   = new WebDriverWait(driver, Duration.ofSeconds(20));
    }

    // ── Waits ────────────────────────────────────────────────────────────────

    public WebElement waitForVisible(By locator) {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(locator));
    }

    public WebElement waitForClickable(By locator) {
        return wait.until(ExpectedConditions.elementToBeClickable(locator));
    }

    public boolean waitForInvisibility(By locator) {
        return wait.until(ExpectedConditions.invisibilityOfElementLocated(locator));
    }

    public List<WebElement> waitForAllVisible(By locator) {
        return wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(locator));
    }

    // ── Actions ──────────────────────────────────────────────────────────────

    /** Regular click with wait for clickability. */
    public void click(By locator) {
        waitForClickable(locator).click();
    }

    /** JavaScript click – use when overlays or animations block normal click. */
    public void jsClick(By locator) {
        WebElement el = waitForVisible(locator);
        ((JavascriptExecutor) driver).executeScript("arguments[0].click();", el);
    }

    /** Clear then type. */
    public void type(By locator, String text) {
        WebElement el = waitForClickable(locator);
        el.clear();
        el.sendKeys(text);
    }

    /** Scroll element into viewport then click. */
    public void scrollAndClick(By locator) {
        WebElement el = waitForVisible(locator);
        ((JavascriptExecutor) driver).executeScript(
                "arguments[0].scrollIntoView({block:'center'});", el);
        el.click();
    }

    /** Get trimmed text of an element. */
    public String getText(By locator) {
        return waitForVisible(locator).getText().trim();
    }

    /** Check whether element is currently displayed (no wait, returns false if absent). */
    public boolean isDisplayed(By locator) {
        try {
            return driver.findElement(locator).isDisplayed();
        } catch (NoSuchElementException e) {
            return false;
        }
    }

    /** Dismiss any modal/overlay cookie banner by pressing Escape. */
    public void dismissOverlay() {
        try {
            driver.findElement(By.tagName("body")).sendKeys(Keys.ESCAPE);
        } catch (Exception ignored) {}
    }

    // ── Screenshots ──────────────────────────────────────────────────────────

    public String takeScreenshot(String testName) {
        String timestamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
        String path      = "test-output/screenshots/" + testName + "_" + timestamp + ".png";
        try {
            File src  = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
            File dest = new File(path);
            FileUtils.copyFile(src, dest);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return path;
    }

    // ── Misc ─────────────────────────────────────────────────────────────────

    public void sleep(long millis) {
        try { Thread.sleep(millis); } catch (InterruptedException ignored) {}
    }

    public void switchToNewTab() {
        String newTab = driver.getWindowHandles().stream()
                .filter(h -> !h.equals(driver.getWindowHandle()))
                .findFirst().orElseThrow();
        driver.switchTo().window(newTab);
    }
}
