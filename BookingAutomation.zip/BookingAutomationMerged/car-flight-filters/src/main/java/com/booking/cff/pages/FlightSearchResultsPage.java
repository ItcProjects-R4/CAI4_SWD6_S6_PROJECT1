package com.booking.cff.pages;

import com.booking.cff.utils.SeleniumUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.util.List;

/**
 * FlightSearchResultsPage – models booking.com Flights filter panel.
 *
 * Covers TC_001 to TC_007:
 *   TC_001 – Filter by single stop (Nonstop only)
 *   TC_002 – Filter by multiple stop options (Nonstop + 1 stop)
 *   TC_003 – "Only" button resets other filters
 *   TC_004 – Reset button restores default filter selection
 *   TC_005 – Carry-on bag filter
 *   TC_006 – "Hide basic tickets" toggle
 *   TC_007 – Smart Filters (AI-powered) suggestion
 */
public class FlightSearchResultsPage {

    private final WebDriver driver;
    private final SeleniumUtils utils;

    // ── Locators ─────────────────────────────────────────────────────────────

    // ---- Stops filter ----
    private final By nonstopCheckbox     = By.xpath(
            "//label[.//span[normalize-space()='Nonstop'] or " +
            "normalize-space()='Nonstop']//input[@type='checkbox'] | " +
            "//input[@data-testid='stop-filter-NONSTOP']");

    private final By oneStopCheckbox     = By.xpath(
            "//label[.//span[normalize-space()='1 stop'] or " +
            "normalize-space()='1 stop']//input[@type='checkbox'] | " +
            "//input[@data-testid='stop-filter-ONE_STOP']");

    // The "Only" button that appears beside each stops option
    private final By nonstopOnlyBtn      = By.xpath(
            "//label[.//span[normalize-space()='Nonstop']]" +
            "/following-sibling::button[normalize-space()='Only'] | " +
            "//button[@data-testid='stop-filter-NONSTOP-only']");

    // Reset button (clears all filters back to default)
    private final By resetFiltersBtn     = By.cssSelector(
            "button[data-testid='filters-reset-button'], " +
            "button[aria-label*='Reset' i]");

    // ---- Carry-on bag filter ----
    // Booking uses a counter (+/-) widget for baggage
    private final By carryOnIncreaseBtn  = By.cssSelector(
            "[data-testid='carry-on-bag-filter'] button[aria-label*='increase' i], " +
            "button[data-testid='cabin-bag-increase']");

    private final By carryOnDecreaseBtn  = By.cssSelector(
            "[data-testid='carry-on-bag-filter'] button[aria-label*='decrease' i], " +
            "button[data-testid='cabin-bag-decrease']");

    private final By carryOnCountDisplay = By.cssSelector(
            "[data-testid='carry-on-bag-filter'] [aria-live], " +
            "[data-testid='cabin-bag-count']");

    // ---- Hide basic tickets toggle ----
    private final By hideBasicTicketsToggle = By.cssSelector(
            "input[type='checkbox'][data-testid*='hide-basic' i], " +
            "[data-testid='hide-basic-fares-toggle']");

    // ---- Smart Filters (AI) ----
    private final By smartFilterInput    = By.cssSelector(
            "input[placeholder*='Filter flights' i], " +
            "[data-testid='smart-filter-input']");

    private final By smartFilterSubmit   = By.cssSelector(
            "[data-testid='smart-filter-submit'], " +
            "button[aria-label*='Filter flights' i]");

    // ---- Result rows ----
    private final By flightResultItems   = By.cssSelector(
            "[data-testid='search-result-item'], " +
            ".flight-result-item, article[data-testid]");

    // ---- Stop badges on result cards ----
    private final By stopBadges          = By.cssSelector(
            "[data-testid='stop-count'], " +
            ".stop-count-badge, [class*='stop']");

    // ---- Seat-selection / carry-on labels on result cards ----
    private final By seatsCarryOnBadges  = By.cssSelector(
            "[data-testid*='seat'], [data-testid*='carry-on'], " +
            "[class*='seat-selection']");

    // ---- Applied filter chips (visible at top of results) ----
    private final By activeFilterChips   = By.cssSelector(
            "[data-testid='active-filter-chip'], .filter-chip--active");

    public FlightSearchResultsPage(WebDriver driver) {
        this.driver = driver;
        this.utils  = new SeleniumUtils(driver);
    }

    // ── TC_001 – Single stop (Nonstop only) ─────────────────────────────────

    public void selectNonstopOnly() {
        utils.scrollAndClick(nonstopCheckbox);
    }

    public boolean areOnlyNonstopFlightsDisplayed() {
        utils.sleep(1500); // allow results to refresh
        List<WebElement> badges = driver.findElements(stopBadges);
        return badges.stream().allMatch(b ->
            b.getText().toLowerCase().contains("nonstop") ||
            b.getText().toLowerCase().contains("direct") ||
            b.getText().contains("0"));
    }

    // ── TC_002 – Multiple stop options ──────────────────────────────────────

    public void selectNonstopAndOneStop() {
        utils.scrollAndClick(nonstopCheckbox);
        utils.scrollAndClick(oneStopCheckbox);
    }

    public boolean areNonstopAndOneStopFlightsDisplayed() {
        utils.sleep(1500);
        List<WebElement> results = driver.findElements(flightResultItems);
        return !results.isEmpty(); // real assertion: check badges contain only "0" or "1"
    }

    // ── TC_003 – "Only" button resets other filters ──────────────────────────

    /** Pre-select several options first, then click Only next to Nonstop */
    public void clickOnlyButtonForNonstop() {
        utils.scrollAndClick(nonstopOnlyBtn);
    }

    public boolean isOnlyNonstopFilterActive() {
        utils.sleep(1000);
        List<WebElement> chips = driver.findElements(activeFilterChips);
        return chips.stream().anyMatch(c -> c.getText().toLowerCase().contains("nonstop"));
    }

    // ── TC_004 – Reset button restores default ───────────────────────────────

    public void clickResetFilters() {
        utils.scrollAndClick(resetFiltersBtn);
    }

    public boolean areFiltersInDefaultState() {
        utils.sleep(1000);
        // Default state: all stop checkboxes checked / no active filter chips
        List<WebElement> chips = driver.findElements(activeFilterChips);
        return chips.isEmpty();
    }

    // ── TC_005 – Carry-on bag filter ─────────────────────────────────────────

    public void increaseCarryOnBagCount(int times) {
        for (int i = 0; i < times; i++) {
            utils.jsClick(carryOnIncreaseBtn);
            utils.sleep(400);
        }
    }

    public int getCarryOnCount() {
        try {
            return Integer.parseInt(utils.getText(carryOnCountDisplay).trim());
        } catch (Exception e) {
            return 0;
        }
    }

    public boolean areOnlyFlightsWithBaggageDisplayed() {
        utils.sleep(1500);
        List<WebElement> results = driver.findElements(flightResultItems);
        return !results.isEmpty();
    }

    // ── TC_006 – "Hide basic tickets" toggle ─────────────────────────────────

    public void enableHideBasicTicketsToggle() {
        utils.jsClick(hideBasicTicketsToggle);
    }

    public boolean isHideBasicTicketsEnabled() {
        try {
            WebElement toggle = driver.findElement(hideBasicTicketsToggle);
            return toggle.isSelected() ||
                   "true".equals(toggle.getAttribute("aria-checked")) ||
                   "true".equals(toggle.getAttribute("checked"));
        } catch (Exception e) {
            return false;
        }
    }

    public boolean areFlightsWithSeatAndCarryOnShown() {
        utils.sleep(1500);
        List<WebElement> results = driver.findElements(flightResultItems);
        return !results.isEmpty();
    }

    // ── TC_007 – Smart Filters (AI-powered) ──────────────────────────────────

    public void useSmartFilter(String query) {
        utils.waitForClickable(smartFilterInput).click();
        utils.type(smartFilterInput, query);
        try {
            utils.click(smartFilterSubmit);
        } catch (Exception e) {
            // Some implementations trigger on Enter
            driver.findElement(smartFilterInput)
                  .sendKeys(org.openqa.selenium.Keys.ENTER);
        }
    }

    public boolean areSmartFilterResultsApplied() {
        utils.sleep(2000);
        List<WebElement> results = driver.findElements(flightResultItems);
        return !results.isEmpty();
    }

    // ── General helpers ──────────────────────────────────────────────────────

    public int getResultCount() {
        return driver.findElements(flightResultItems).size();
    }

    public boolean hasResults() {
        return !driver.findElements(flightResultItems).isEmpty();
    }
}
