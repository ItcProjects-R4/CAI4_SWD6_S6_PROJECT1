package com.booking.cff.tests;

import com.booking.cff.base.BaseTest;
import com.booking.cff.pages.CarRentalSearchResultsPage;
import com.booking.cff.utils.ExtentReportManager;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

/**
 * CarRentalFilterTests – covers TC_001 to TC_008 from Image 3.
 *
 *   TC_001 – Filter by car type button (SUVs)
 *   TC_002 – Filter by pickup location (Airport – in terminal)
 *   TC_003 – Filter by transmission (Automatic)
 *   TC_004 – Filter by supplier (Avis)
 *   TC_005 – Filter by mileage type (Limited)
 *   TC_006 – Filter by extras (GPS)
 *   TC_007 – Filter by car category (Luxury car)
 *   TC_008 – Filter by price range (EGP 1000–2000)
 *
 * Pre-condition: User is on car rental search results page.
 * We build the URL directly to skip the search form.
 */
public class CarRentalFilterTests extends BaseTest {

    // Fixed car-rental search: Cairo airport, 3-day rental in August 2025
    private static final String CAR_RESULTS_URL =
            "https://www.booking.com/cars/search.html?" +
            "pickup_airport=CAI&dropoff_airport=CAI" +
            "&pickup_date=2025-08-01&pickup_time=10%3A00" +
            "&dropoff_date=2025-08-04&dropoff_time=10%3A00" +
            "&driver_age=30&currency_code=EGP";

    private CarRentalSearchResultsPage carsPage;

    @BeforeMethod(alwaysRun = true)
    public void initPages() {
        carsPage = new CarRentalSearchResultsPage(driver);
    }

    private void navigateToCarResults() {
        driver.get(BASE_URL);
        new com.booking.cff.pages.HomePage(driver).dismissCookieBanner();
        driver.get(CAR_RESULTS_URL);
        // Let results load
        try { Thread.sleep(2000); } catch (InterruptedException ignored) {}
    }

    // ─────────────────────────────────────────────────────────────────────────
    // TC_001 – Car type button: SUVs
    // ─────────────────────────────────────────────────────────────────────────
    @Test(description = "TC_001 – Filter by car type buttons updates Car Category filter")
    public void tc001_filterBySuvButton() {
        ExtentTest test = ExtentReportManager.createTest(
                "TC_001 – SUV car type button",
                "Results filtered to show only SUVs; SUVs selected in Car Category filter");

        try {
            navigateToCarResults();

            test.log(Status.INFO, "Step: Click on 'SUVs' button from visible car type buttons");
            carsPage.clickSuvButton();

            Assert.assertTrue(carsPage.hasResults(),
                    "Expected car results after selecting SUV filter");

            test.log(Status.PASS, "TC_001 PASSED – SUV filter applied, results shown");

        } catch (AssertionError | Exception e) {
            test.log(Status.FAIL, "TC_001 FAILED: " + e.getMessage());
            new com.booking.cff.utils.SeleniumUtils(driver).takeScreenshot("TC_001_cars");
            throw e;
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // TC_002 – Pickup location: Airport (in terminal)
    // ─────────────────────────────────────────────────────────────────────────
    @Test(description = "TC_002 – Verify filtering by pickup location type")
    public void tc002_filterByAirportInTerminal() {
        ExtentTest test = ExtentReportManager.createTest(
                "TC_002 – Airport in terminal filter",
                "Only cars available in terminal are displayed");

        try {
            navigateToCarResults();

            test.log(Status.INFO, "Step: Select 'Airport (in terminal)'");
            carsPage.selectAirportInTerminal();

            Assert.assertTrue(carsPage.areOnlyTerminalCarsDisplayed(),
                    "Expected only terminal-pickup cars");

            test.log(Status.PASS, "TC_002 PASSED");

        } catch (AssertionError | Exception e) {
            test.log(Status.FAIL, "TC_002 FAILED: " + e.getMessage());
            new com.booking.cff.utils.SeleniumUtils(driver).takeScreenshot("TC_002_cars");
            throw e;
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // TC_003 – Transmission: Automatic
    // ─────────────────────────────────────────────────────────────────────────
    @Test(description = "TC_003 – Verify filtering by transmission type")
    public void tc003_filterByAutomaticTransmission() {
        ExtentTest test = ExtentReportManager.createTest(
                "TC_003 – Automatic transmission filter",
                "Only automatic cars are displayed");

        try {
            navigateToCarResults();

            test.log(Status.INFO, "Step: Select 'Automatic'");
            carsPage.selectAutomaticTransmission();

            Assert.assertTrue(carsPage.areOnlyAutomaticCarsDisplayed(),
                    "Expected only automatic cars");

            test.log(Status.PASS, "TC_003 PASSED");

        } catch (AssertionError | Exception e) {
            test.log(Status.FAIL, "TC_003 FAILED: " + e.getMessage());
            new com.booking.cff.utils.SeleniumUtils(driver).takeScreenshot("TC_003_cars");
            throw e;
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // TC_004 – Supplier: Avis
    // ─────────────────────────────────────────────────────────────────────────
    @Test(description = "TC_004 – Verify filtering by supplier")
    public void tc004_filterByAvisSupplier() {
        ExtentTest test = ExtentReportManager.createTest(
                "TC_004 – Avis supplier filter",
                "Only cars from Avis are displayed");

        try {
            navigateToCarResults();

            test.log(Status.INFO, "Step: Select 'Avis'");
            carsPage.selectAvisSupplier();

            Assert.assertTrue(carsPage.areOnlyAvisCarsDisplayed(),
                    "Expected only Avis cars");

            test.log(Status.PASS, "TC_004 PASSED");

        } catch (AssertionError | Exception e) {
            test.log(Status.FAIL, "TC_004 FAILED: " + e.getMessage());
            new com.booking.cff.utils.SeleniumUtils(driver).takeScreenshot("TC_004_cars");
            throw e;
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // TC_005 – Mileage type: Limited
    // ─────────────────────────────────────────────────────────────────────────
    @Test(description = "TC_005 – Verify filtering by mileage type")
    public void tc005_filterByLimitedMileage() {
        ExtentTest test = ExtentReportManager.createTest(
                "TC_005 – Limited mileage filter",
                "Only cars with limited mileage are displayed");

        try {
            navigateToCarResults();

            test.log(Status.INFO, "Step: Select 'Limited' mileage");
            carsPage.selectLimitedMileage();

            Assert.assertTrue(carsPage.areOnlyLimitedMileageCarsDisplayed(),
                    "Expected only limited-mileage cars");

            test.log(Status.PASS, "TC_005 PASSED");

        } catch (AssertionError | Exception e) {
            test.log(Status.FAIL, "TC_005 FAILED: " + e.getMessage());
            new com.booking.cff.utils.SeleniumUtils(driver).takeScreenshot("TC_005_cars");
            throw e;
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // TC_006 – Extras: GPS
    // ─────────────────────────────────────────────────────────────────────────
    @Test(description = "TC_006 – Verify filtering by extras availability (GPS)")
    public void tc006_filterByGps() {
        ExtentTest test = ExtentReportManager.createTest(
                "TC_006 – GPS extras filter",
                "Only cars with GPS available are displayed");

        try {
            navigateToCarResults();

            test.log(Status.INFO, "Step: Select 'GPS'");
            carsPage.selectGpsExtra();

            Assert.assertTrue(carsPage.areOnlyGpsCarsDisplayed(),
                    "Expected only cars with GPS");

            test.log(Status.PASS, "TC_006 PASSED");

        } catch (AssertionError | Exception e) {
            test.log(Status.FAIL, "TC_006 FAILED: " + e.getMessage());
            new com.booking.cff.utils.SeleniumUtils(driver).takeScreenshot("TC_006_cars");
            throw e;
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // TC_007 – Car category: Luxury car
    // ─────────────────────────────────────────────────────────────────────────
    @Test(description = "TC_007 – Verify filtering by car category (Luxury)")
    public void tc007_filterByLuxuryCar() {
        ExtentTest test = ExtentReportManager.createTest(
                "TC_007 – Luxury car category filter",
                "Only luxury cars are displayed");

        try {
            navigateToCarResults();

            test.log(Status.INFO, "Step: Select 'Luxury car'");
            carsPage.selectLuxuryCarCategory();

            Assert.assertTrue(carsPage.areOnlyLuxuryCarsDisplayed(),
                    "Expected only luxury cars");

            test.log(Status.PASS, "TC_007 PASSED");

        } catch (AssertionError | Exception e) {
            test.log(Status.FAIL, "TC_007 FAILED: " + e.getMessage());
            new com.booking.cff.utils.SeleniumUtils(driver).takeScreenshot("TC_007_cars");
            throw e;
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // TC_008 – Price per day: EGP 1000–2000
    // ─────────────────────────────────────────────────────────────────────────
    @Test(description = "TC_008 – Verify filtering by price per day range")
    public void tc008_filterByPriceRange() {
        ExtentTest test = ExtentReportManager.createTest(
                "TC_008 – Price range filter (EGP 1000–2000)",
                "Only cars within selected price range are displayed");

        try {
            navigateToCarResults();

            test.log(Status.INFO, "Step: Select 'EGP 1000 - 2000' price range");
            carsPage.filterByPriceRange(1000, 2000);

            Assert.assertTrue(carsPage.areOnlyCarsWithinPriceRangeDisplayed(),
                    "Expected only cars within EGP 1000–2000 range");

            test.log(Status.PASS, "TC_008 PASSED");

        } catch (AssertionError | Exception e) {
            test.log(Status.FAIL, "TC_008 FAILED: " + e.getMessage());
            new com.booking.cff.utils.SeleniumUtils(driver).takeScreenshot("TC_008_cars");
            throw e;
        }
    }
}
