package com.booking.cff.tests;

import com.booking.cff.base.BaseTest;
import com.booking.cff.pages.*;
import com.booking.cff.utils.ExtentReportManager;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

/**
 * CheckoutTests – covers the four checkout / payment test cases
 * from Image 1 of the supplied test-case document.
 *
 *   TC01 – Successful payment with valid card
 *   TC02 – Cancel payment process
 *   TC03 – Payment with invalid card details
 *   TC04 – Successful booking when payment is set to "Pay at Hotel"
 *
 * Pre-condition for TC01/TC03/TC04:
 *   User is logged in, has selected a hotel & room, and is on the payment page.
 *
 * NOTE: Replace VALID_* constants with real test-card values supplied by
 *       Booking.com's sandbox or your QA environment.
 */
public class CheckoutTests extends BaseTest {

    // ── Test data ─────────────────────────────────────────────────────────────
    private static final String DESTINATION   = "London";
    private static final String CHECK_IN      = "2025-08-01";
    private static final String CHECK_OUT     = "2025-08-05";

    // Valid card (use booking.com sandbox / test cards)
    private static final String VALID_CARD    = "4111111111111111";
    private static final String VALID_EXPIRY  = "12/30";
    private static final String VALID_CVV     = "123";
    private static final String CARD_HOLDER   = "Test User";

    // Invalid card
    private static final String INVALID_CARD  = "1234567890123456";
    private static final String INVALID_CVV   = "999";

    // Billing info
    private static final String FIRST_NAME    = "Test";
    private static final String LAST_NAME     = "User";
    private static final String EMAIL         = "testuser@example.com";

    // ── Page objects ──────────────────────────────────────────────────────────
    private HomePage                homePage;
    private LoginPage               loginPage;
    private HotelSearchResultsPage  hotelResultsPage;
    private PaymentPage             paymentPage;

    @BeforeMethod(alwaysRun = true)
    public void initPages() {
        homePage         = new HomePage(driver);
        loginPage        = new LoginPage(driver);
        hotelResultsPage = new HotelSearchResultsPage(driver);
        paymentPage      = new PaymentPage(driver);
    }

    // ── Shared setup: login + search + navigate to payment page ──────────────

    private void navigateToPaymentPage() {
        homePage.open(BASE_URL);
        homePage.clickSignIn();
        loginPage.login(TEST_EMAIL, TEST_PASSWORD);
        homePage.searchHotel(DESTINATION, CHECK_IN, CHECK_OUT);
        hotelResultsPage.openFirstHotel();
        hotelResultsPage.selectFirstRoom();
        // We are now on the checkout / payment page
    }

    // ─────────────────────────────────────────────────────────────────────────
    // TC01 – Successful payment with valid card
    // ─────────────────────────────────────────────────────────────────────────
    @Test(description = "TC01 – Successful payment with valid credit/debit card")
    public void tc01_successfulPaymentWithValidCard() {
        ExtentTest test = ExtentReportManager.createTest(
                "TC01 – Successful payment with valid card",
                "Verify payment is successful with valid card details");

        try {
            test.log(Status.INFO, "Step 1: Opening Booking.com and logging in");
            navigateToPaymentPage();

            test.log(Status.INFO, "Step 2: Selecting credit/debit card payment");
            paymentPage.selectCreditCardPayment();

            test.log(Status.INFO, "Step 3: Entering valid card details");
            paymentPage.fillCardDetailsInIframe(VALID_CARD, VALID_EXPIRY, VALID_CVV, CARD_HOLDER);

            test.log(Status.INFO, "Step 4: Entering billing information");
            paymentPage.fillBillingInfo(FIRST_NAME, LAST_NAME, EMAIL);

            test.log(Status.INFO, "Step 5: Clicking Pay Now");
            paymentPage.clickPayNow();

            // ── Assertions ────────────────────────────────────────────────────
            Assert.assertTrue(
                    paymentPage.isConfirmationPageDisplayed(),
                    "Expected booking confirmation page to be displayed");

            test.log(Status.PASS,
                    "TC01 PASSED – Confirmation page displayed. Ref: " +
                    paymentPage.getConfirmationNumber());

        } catch (AssertionError | Exception e) {
            test.log(Status.FAIL, "TC01 FAILED: " + e.getMessage());
            test.addScreenCaptureFromPath(
                    new com.booking.cff.utils.SeleniumUtils(driver).takeScreenshot("TC01"));
            throw e;
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // TC02 – Cancel payment process
    // ─────────────────────────────────────────────────────────────────────────
    @Test(description = "TC02 – Cancel payment process after starting it")
    public void tc02_cancelPaymentProcess() {
        ExtentTest test = ExtentReportManager.createTest(
                "TC02 – Cancel payment process",
                "Verify no payment is processed and booking remains pending after cancel");

        try {
            test.log(Status.INFO, "Step 1: Opening Booking.com and logging in");
            navigateToPaymentPage();

            test.log(Status.INFO, "Step 2: Starting payment process (choosing credit card)");
            paymentPage.selectCreditCardPayment();

            test.log(Status.INFO, "Step 3: Clicking Cancel / Back button");
            paymentPage.cancelPayment();

            // ── Assertions ────────────────────────────────────────────────────
            Assert.assertFalse(
                    paymentPage.isConfirmationPageDisplayed(),
                    "Payment confirmation should NOT be shown after cancel");

            test.log(Status.PASS,
                    "TC02 PASSED – No payment processed; booking remains pending");

        } catch (AssertionError | Exception e) {
            test.log(Status.FAIL, "TC02 FAILED: " + e.getMessage());
            test.addScreenCaptureFromPath(
                    new com.booking.cff.utils.SeleniumUtils(driver).takeScreenshot("TC02"));
            throw e;
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // TC03 – Payment with invalid card details
    // ─────────────────────────────────────────────────────────────────────────
    @Test(description = "TC03 – Payment rejected with invalid card details")
    public void tc03_paymentWithInvalidCard() {
        ExtentTest test = ExtentReportManager.createTest(
                "TC03 – Payment with invalid card details",
                "Verify an error message appears and booking is not completed");

        try {
            test.log(Status.INFO, "Step 1: Opening Booking.com and logging in");
            navigateToPaymentPage();

            test.log(Status.INFO, "Step 2: Selecting card payment method");
            paymentPage.selectCreditCardPayment();

            test.log(Status.INFO, "Step 3: Entering invalid card number / CVV");
            paymentPage.fillCardDetailsInIframe(INVALID_CARD, VALID_EXPIRY, INVALID_CVV, CARD_HOLDER);

            test.log(Status.INFO, "Step 4: Clicking Pay Now");
            paymentPage.clickPayNow();

            // ── Assertions ────────────────────────────────────────────────────
            Assert.assertTrue(
                    paymentPage.isCardErrorDisplayed(),
                    "Expected an error message for invalid card details");

            Assert.assertFalse(
                    paymentPage.isConfirmationPageDisplayed(),
                    "Booking should NOT be completed with invalid card");

            test.log(Status.PASS,
                    "TC03 PASSED – Error displayed: " + paymentPage.getCardErrorText());

        } catch (AssertionError | Exception e) {
            test.log(Status.FAIL, "TC03 FAILED: " + e.getMessage());
            test.addScreenCaptureFromPath(
                    new com.booking.cff.utils.SeleniumUtils(driver).takeScreenshot("TC03"));
            throw e;
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // TC04 – Successful booking when payment is set to "Pay at Hotel"
    // ─────────────────────────────────────────────────────────────────────────
    @Test(description = "TC04 – Successful booking with Pay at Hotel option")
    public void tc04_successfulBookingPayAtHotel() {
        ExtentTest test = ExtentReportManager.createTest(
                "TC04 – Booking with Pay at Hotel",
                "Verify booking is created successfully when Pay at Hotel is selected");

        try {
            test.log(Status.INFO, "Step 1: Opening Booking.com, logging in, searching hotel");
            navigateToPaymentPage();

            test.log(Status.INFO, "Step 2: Choosing payment method: Pay at Hotel");
            paymentPage.selectPayAtHotel();

            test.log(Status.INFO, "Step 3: Clicking Book Now");
            paymentPage.clickBookNow();

            // ── Assertions ────────────────────────────────────────────────────
            Assert.assertTrue(
                    paymentPage.isConfirmationPageDisplayed(),
                    "Expected booking confirmation page to be displayed");

            test.log(Status.PASS,
                    "TC04 PASSED – Booking created. Ref: " +
                    paymentPage.getConfirmationNumber());

        } catch (AssertionError | Exception e) {
            test.log(Status.FAIL, "TC04 FAILED: " + e.getMessage());
            test.addScreenCaptureFromPath(
                    new com.booking.cff.utils.SeleniumUtils(driver).takeScreenshot("TC04"));
            throw e;
        }
    }
}
