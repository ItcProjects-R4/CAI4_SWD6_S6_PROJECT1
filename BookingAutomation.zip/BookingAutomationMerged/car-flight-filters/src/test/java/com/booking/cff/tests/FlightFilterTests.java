package com.booking.cff.tests;

import com.booking.cff.base.BaseTest;
import com.booking.cff.pages.FlightSearchResultsPage;
import com.booking.cff.utils.ExtentReportManager;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

/**
 * FlightFilterTests – covers TC_001 to TC_007 from Image 2.
 *
 * Pre-condition (shared): User is on the flight search results page.
 * We navigate there in navigateToFlightResults() using a fixed search.
 */
public class FlightFilterTests extends BaseTest {

    // ── Search parameters ─────────────────────────────────────────────────────
    private static final String FLIGHTS_URL =
            "https://www.booking.com/flights/search/?" +
            "from=CAI&to=DXB&depart=2025-08-01&type=ONEWAY&adult=1";

    private FlightSearchResultsPage flightsPage;

    @BeforeMethod(alwaysRun = true)
    public void initPages() {
        flightsPage = new FlightSearchResultsPage(driver);
    }

    /** Navigate to Booking.com flights results page. */
    private void navigateToFlightResults() {
        driver.get(BASE_URL);
        new com.booking.cff.pages.HomePage(driver).dismissCookieBanner();
        driver.get(FLIGHTS_URL);
        // Wait for at least one result card
        flightsPage.areOnlyNonstopFlightsDisplayed(); // side-effect: waits for page load
    }

    // ─────────────────────────────────────────────────────────────────────────
    // TC_001 – Filter by single stop option (Nonstop only)
    // ─────────────────────────────────────────────────────────────────────────
    @Test(description = "TC_001 – Verify filtering by single option of Stops")
    public void tc001_filterByNonstop() {
        ExtentTest test = ExtentReportManager.createTest(
                "TC_001 – Nonstop filter", "Only nonstop flights should be displayed");

        try {
            test.log(Status.INFO, "Pre-condition: Navigate to flight search results page");
            navigateToFlightResults();

            test.log(Status.INFO, "Step: Select 'Nonstop' only");
            flightsPage.selectNonstopOnly();

            Assert.assertTrue(flightsPage.hasResults(),
                    "Expected flight results to be shown after Nonstop filter");

            test.log(Status.PASS, "TC_001 PASSED – Nonstop filter applied successfully");

        } catch (AssertionError | Exception e) {
            test.log(Status.FAIL, "TC_001 FAILED: " + e.getMessage());
            new com.booking.cff.utils.SeleniumUtils(driver).takeScreenshot("TC_001");
            throw e;
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // TC_002 – Select multiple stop options (Nonstop + 1 stop)
    // ─────────────────────────────────────────────────────────────────────────
    @Test(description = "TC_002 – Verify selecting multiple stop options")
    public void tc002_filterByNonstopAndOneStop() {
        ExtentTest test = ExtentReportManager.createTest(
                "TC_002 – Nonstop + 1 stop filter",
                "Results should include nonstop and 1-stop flights only");

        try {
            navigateToFlightResults();

            test.log(Status.INFO, "Step: Select 'Nonstop' + '1 stop'");
            flightsPage.selectNonstopAndOneStop();

            Assert.assertTrue(flightsPage.areNonstopAndOneStopFlightsDisplayed(),
                    "Expected both Nonstop and 1-stop flights");

            test.log(Status.PASS, "TC_002 PASSED");

        } catch (AssertionError | Exception e) {
            test.log(Status.FAIL, "TC_002 FAILED: " + e.getMessage());
            new com.booking.cff.utils.SeleniumUtils(driver).takeScreenshot("TC_002");
            throw e;
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // TC_003 – "Only" button resets other filters
    // ─────────────────────────────────────────────────────────────────────────
    @Test(description = "TC_003 – Verify 'Only' button resets other filters")
    public void tc003_onlyButtonResetsOtherFilters() {
        ExtentTest test = ExtentReportManager.createTest(
                "TC_003 – Only button reset",
                "All previously selected filters should be cleared; only nonstop shown");

        try {
            navigateToFlightResults();
            flightsPage.selectNonstopAndOneStop();   // pre-select two options

            test.log(Status.INFO, "Step: Click 'Only' button next to Nonstop option");
            flightsPage.clickOnlyButtonForNonstop();

            Assert.assertTrue(flightsPage.hasResults(),
                    "Expected flight results after clicking Only");

            test.log(Status.PASS, "TC_003 PASSED – Only-Nonstop filter applied");

        } catch (AssertionError | Exception e) {
            test.log(Status.FAIL, "TC_003 FAILED: " + e.getMessage());
            new com.booking.cff.utils.SeleniumUtils(driver).takeScreenshot("TC_003");
            throw e;
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // TC_004 – Reset button restores default filter selection
    // ─────────────────────────────────────────────────────────────────────────
    @Test(description = "TC_004 – Verify Reset button restores default filter selection")
    public void tc004_resetButtonRestoresDefaults() {
        ExtentTest test = ExtentReportManager.createTest(
                "TC_004 – Reset filters",
                "All filters should return to default state after reset");

        try {
            navigateToFlightResults();
            flightsPage.selectNonstopOnly();   // modify a filter first

            test.log(Status.INFO, "Step: Click 'Reset' button");
            flightsPage.clickResetFilters();

            Assert.assertTrue(flightsPage.areFiltersInDefaultState(),
                    "Expected all filter options to be back to default");

            Assert.assertTrue(flightsPage.hasResults(), "Expected results after reset");

            test.log(Status.PASS, "TC_004 PASSED – Filters reset to default");

        } catch (AssertionError | Exception e) {
            test.log(Status.FAIL, "TC_004 FAILED: " + e.getMessage());
            new com.booking.cff.utils.SeleniumUtils(driver).takeScreenshot("TC_004");
            throw e;
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // TC_005 – Carry-on bag filter
    // ─────────────────────────────────────────────────────────────────────────
    @Test(description = "TC_005 – Verify carry-on bag filter")
    public void tc005_carryOnBagFilter() {
        ExtentTest test = ExtentReportManager.createTest(
                "TC_005 – Carry-on bag filter",
                "Only flights with selected baggage count should appear");

        try {
            navigateToFlightResults();

            test.log(Status.INFO, "Step: Increase carry-on bag count by 1");
            flightsPage.increaseCarryOnBagCount(1);

            Assert.assertTrue(flightsPage.areOnlyFlightsWithBaggageDisplayed(),
                    "Expected only flights with the specified carry-on count");

            test.log(Status.PASS, "TC_005 PASSED – Carry-on bag filter working");

        } catch (AssertionError | Exception e) {
            test.log(Status.FAIL, "TC_005 FAILED: " + e.getMessage());
            new com.booking.cff.utils.SeleniumUtils(driver).takeScreenshot("TC_005");
            throw e;
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // TC_006 – "Hide basic tickets" toggle
    // ─────────────────────────────────────────────────────────────────────────
    @Test(description = "TC_006 – Verify 'Hide basic tickets' toggle")
    public void tc006_hideBasicTicketsToggle() {
        ExtentTest test = ExtentReportManager.createTest(
                "TC_006 – Hide basic tickets toggle",
                "Only flights with seat selection & carry-on should be shown");

        try {
            navigateToFlightResults();

            test.log(Status.INFO, "Step: Enable 'Hide basic tickets' toggle");
            flightsPage.enableHideBasicTicketsToggle();

            Assert.assertTrue(flightsPage.isHideBasicTicketsEnabled(),
                    "Expected toggle to be enabled");

            Assert.assertTrue(flightsPage.areFlightsWithSeatAndCarryOnShown(),
                    "Expected filtered results after enabling toggle");

            test.log(Status.PASS, "TC_006 PASSED – Hide basic tickets toggle enabled");

        } catch (AssertionError | Exception e) {
            test.log(Status.FAIL, "TC_006 FAILED: " + e.getMessage());
            new com.booking.cff.utils.SeleniumUtils(driver).takeScreenshot("TC_006");
            throw e;
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // TC_007 – Smart Filters (AI-powered) suggestion works correctly
    // ─────────────────────────────────────────────────────────────────────────
    @Test(description = "TC_007 – Verify Smart Filters (AI-powered) suggestion works correctly")
    public void tc007_smartFiltersAi() {
        ExtentTest test = ExtentReportManager.createTest(
                "TC_007 – Smart Filters AI",
                "Relevant filters applied automatically based on natural-language query");

        try {
            navigateToFlightResults();

            String query = "nonstop flights under 15000";
            test.log(Status.INFO, "Step: Enter query in Smart Filters: '" + query + "'");
            flightsPage.useSmartFilter(query);

            Assert.assertTrue(flightsPage.areSmartFilterResultsApplied(),
                    "Expected Smart Filter to apply and return results");

            test.log(Status.PASS, "TC_007 PASSED – Smart Filter applied, results shown");

        } catch (AssertionError | Exception e) {
            test.log(Status.FAIL, "TC_007 FAILED: " + e.getMessage());
            new com.booking.cff.utils.SeleniumUtils(driver).takeScreenshot("TC_007");
            throw e;
        }
    }
}
