package com.booking.hotels.pages;

import com.booking.hotels.base.BasePage;
import com.booking.hotels.utils.MailosaurOtpReader;
import org.openqa.selenium.*;
import org.openqa.selenium.support.*;
import org.openqa.selenium.support.ui.*;

import java.time.Duration;

public class SignInPage extends BasePage {

    private final By emailInput   = By.cssSelector("#username");
    private final By continueBtn  = By.xpath("//button[.//span[text()='Continue with email']]");
    private final By otpSubmitBtn = By.xpath("//button[.//span[text()='Verify email']]");
    private final By errorMsg     = By.xpath("//div[@role='alert'] | //span[contains(@class,'error')]");

    // CAPTCHA
    private final By captchaIframe    = By.xpath("//iframe[contains(@src,'recaptcha') or contains(@src,'hcaptcha') or contains(@src,'challenge')]");
    private final By captchaContainer = By.xpath("//div[contains(@class,'g-recaptcha') or contains(@class,'h-captcha') or contains(@id,'captcha')]");

    public SignInPage(WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
    }

    public boolean isSignInPageDisplayed() {
        return isDisplayed(emailInput) || getCurrentUrl().contains("sign-in");
    }

    public void enterEmail(String email) {
        WebElement el = waitForVisible(emailInput);
        el.clear();
        el.sendKeys(email);
    }

    public void clickContinue() {
        click(continueBtn);
    }

    public boolean isCaptchaDisplayed() {
        return isDisplayed(captchaIframe) || isDisplayed(captchaContainer);
    }

    /**
     * booking.com may occasionally present a CAPTCHA challenge during sign-in.
     * This pauses the automated run and gives a human a window to solve it
     * manually in the open browser, rather than attempting to bypass it.
     */
    public void waitForManualCaptchaSolve() {
        System.out.println("\n=== CAPTCHA DETECTED ===");
        System.out.println("Please solve the CAPTCHA in the browser manually.");
        System.out.println("Waiting up to 120 seconds for you to solve it...");
        long deadline = System.currentTimeMillis() + 120_000;
        while (System.currentTimeMillis() < deadline) {
            sleep(2000);
            if (!isCaptchaDisplayed()) {
                System.out.println("CAPTCHA solved! Continuing...\n");
                sleep(2000);
                return;
            }
        }
        System.out.println("CAPTCHA wait timed out after 120s.");
    }

    public boolean isOtpPageDisplayed() {
        for (int i = 0; i < 6; i++) {
            try {
                if (driver.findElement(By.cssSelector("input[name='code_" + i + "']")).isDisplayed()) {
                    return true;
                }
            } catch (NoSuchElementException e) {
                return false;
            }
        }
        return false;
    }

    public void enterOtp(String otp) {
        wait.until(d -> {
            for (int i = 0; i < otp.length(); i++) {
                try {
                    WebElement f = d.findElement(By.cssSelector("input[name='code_" + i + "']"));
                    if (!f.isDisplayed()) return null;
                } catch (NoSuchElementException e) {
                    return null;
                }
            }
            return true;
        });
        for (int i = 0; i < otp.length(); i++) {
            WebElement el = driver.findElement(By.cssSelector("input[name='code_" + i + "']"));
            el.click();
            el.sendKeys(String.valueOf(otp.charAt(i)));
            sleep(250);
        }
    }

    public void clickSubmitOtp() {
        By profileAvatar = By.xpath("//button[@data-testid='header-profile']");

        // First, give auto-submit a chance (OTP form may submit after 6th char)
        long autoSubmitWait = System.currentTimeMillis() + 3_000;
        while (System.currentTimeMillis() < autoSubmitWait) {
            if (!driver.findElements(profileAvatar).isEmpty()) {
                System.out.println("Auto-authenticated after OTP entry");
                return;
            }
            sleep(200);
        }

        // Poll for the button or redirect
        long deadline = System.currentTimeMillis() + 15_000;
        while (System.currentTimeMillis() < deadline) {
            if (!driver.findElements(profileAvatar).isEmpty()) {
                System.out.println("Already authenticated during polling");
                return;
            }
            try {
                WebElement btn = driver.findElement(otpSubmitBtn);
                if (btn.isDisplayed() && btn.isEnabled()) {
                    btn.click();
                    System.out.println("OTP submit button clicked");
                    WebDriverWait postWait = new WebDriverWait(driver, Duration.ofSeconds(10));
                    postWait.until(d -> !d.findElements(profileAvatar).isEmpty());
                    return;
                }
            } catch (NoSuchElementException | ElementNotInteractableException e) {
            }
            sleep(300);
        }
        if (isRedirected()) {
            return;
        }
        try {
            jsClick(otpSubmitBtn);
            System.out.println("OTP submitted via JS fallback");
        } catch (Exception e2) {
            throw new RuntimeException("Could not submit OTP. URL: " + getCurrentUrl(), e2);
        }
    }

    private boolean isRedirected() {
        return !driver.findElements(By.xpath("//button[@data-testid='header-profile']")).isEmpty();
    }

    public boolean isErrorDisplayed() {
        return isDisplayed(errorMsg);
    }

    public String getErrorMessage() {
        return getText(errorMsg);
    }

    public void loginWithRandomEmail() throws Exception {
        String email = MailosaurOtpReader.randomEmail();
        System.out.println("Using email: " + email);

        enterEmail(email);
        clickContinue();

        // Poll for OTP page, CAPTCHA, or error — no fixed sleep
        long deadline = System.currentTimeMillis() + 12_000;
        while (System.currentTimeMillis() < deadline) {
            if (isOtpPageDisplayed()) break;
            if (isCaptchaDisplayed()) {
                waitForManualCaptchaSolve();
                break;
            }
            if (isErrorDisplayed()) break;
            sleep(300);
        }

        if (isErrorDisplayed()) {
            throw new RuntimeException("Login failed: " + getErrorMessage());
        }

        String otp = MailosaurOtpReader.getOtp(email);
        System.out.println("OTP: " + otp);

        enterOtp(otp);
        clickSubmitOtp();
        System.out.println("OTP submitted successfully");
    }

    private void sleep(long ms) {
        try {
            Thread.sleep(ms);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}
