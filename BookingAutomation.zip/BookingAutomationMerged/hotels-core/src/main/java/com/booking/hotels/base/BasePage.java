package com.booking.hotels.base;

import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.*;
import java.time.Duration;

/**
 * Shared Page Object base class for the "hotels-core" module.
 *
 * Merged from two teammates' submissions ("Tester1" and "myaccount"):
 *   - Tester1 had the original simple click()/type() helpers.
 *   - myaccount extended them with retry-on-stale-element and a JS-click
 *     fallback for elements that are present but not "interactable" yet
 *     (booking.com's React UI sometimes attaches click handlers a tick
 *     after the element becomes visible). That sturdier version is kept
 *     here since it is a strict improvement with no behavior loss.
 */
public class BasePage {

    protected WebDriver driver;
    protected WebDriverWait wait;

    public BasePage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(15));
    }

    // ─── Wait Helpers ────────────────────────────────────────────
    protected WebElement waitForVisible(By locator) {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(locator));
    }

    protected WebElement waitForClickable(By locator) {
        return wait.until(ExpectedConditions.elementToBeClickable(locator));
    }

    protected boolean waitForInvisible(By locator) {
        return wait.until(ExpectedConditions.invisibilityOfElementLocated(locator));
    }

    // ─── Actions (retry-safe) ────────────────────────────────────
    protected void click(By locator) {
        for (int i = 0; i < 3; i++) {
            try {
                waitForClickable(locator).click();
                return;
            } catch (StaleElementReferenceException e) {
                if (i == 2) throw e;
            } catch (ElementNotInteractableException e) {
                jsClick(locator);
                return;
            }
        }
    }

    protected void type(By locator, String text) {
        for (int i = 0; i < 3; i++) {
            try {
                WebElement el = waitForVisible(locator);
                el.clear();
                el.sendKeys(text);
                return;
            } catch (StaleElementReferenceException e) {
                if (i == 2) throw e;
            } catch (ElementNotInteractableException e) {
                WebElement el = driver.findElement(locator);
                ((JavascriptExecutor) driver).executeScript(
                    "arguments[0].value = arguments[1];" +
                    "arguments[0].dispatchEvent(new Event('input', {bubbles: true}));" +
                    "arguments[0].dispatchEvent(new Event('change', {bubbles: true}));",
                    el, text
                );
                return;
            }
        }
    }

    protected void jsClick(By locator) {
        WebElement el = wait.until(d -> {
            WebElement e = d.findElement(locator);
            if (e.isDisplayed()) return e;
            return null;
        });
        ((JavascriptExecutor) driver).executeScript("arguments[0].click();", el);
    }

    protected String getText(By locator) {
        return waitForVisible(locator).getText();
    }

    protected boolean isDisplayed(By locator) {
        try {
            return wait.until(ExpectedConditions.visibilityOfElementLocated(locator)).isDisplayed();
        } catch (NoSuchElementException | StaleElementReferenceException | TimeoutException e) {
            return false;
        }
    }

    protected void scrollTo(By locator) {
        WebElement el = driver.findElement(locator);
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", el);
    }

    public String getPageTitle() {
        return driver.getTitle();
    }

    public String getCurrentUrl() {
        return driver.getCurrentUrl();
    }
}
