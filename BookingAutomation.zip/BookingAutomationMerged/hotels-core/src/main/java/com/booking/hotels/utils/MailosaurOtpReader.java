package com.booking.hotels.utils;

import com.mailosaur.MailosaurClient;
import com.mailosaur.MailosaurException;
import com.mailosaur.models.MessageListResult;
import com.mailosaur.models.MessageSummary;

import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Reads OTP / verification codes out of a Mailosaur inbox.
 *
 * Credentials are read ONLY from environment variables — no API keys are
 * hardcoded in source. Set these before running sign-in tests:
 *   MAILOSAUR_API_KEY
 *   MAILOSAUR_SERVER_ID
 *   MAILOSAUR_DOMAIN     (usually "<serverId>.mailosaur.net")
 *
 * The two teammate submissions ("Tester1"'s Login.java and "myaccount"'s
 * MailosaurOtpReader.java) each shipped a *different* hardcoded Mailosaur
 * API key/server pair. Those are personal/team credentials and must not be
 * committed to source control, so both have been removed in this merge —
 * configure your own via env vars (or a local, git-ignored
 * config.properties) instead.
 */
public class MailosaurOtpReader {

    private static final String API_KEY      = System.getenv("MAILOSAUR_API_KEY");
    private static final String SERVER_ID    = System.getenv("MAILOSAUR_SERVER_ID");
    private static final String SERVER_DOMAIN = System.getenv("MAILOSAUR_DOMAIN");

    private static final Pattern OTP_PATTERN = Pattern.compile(
        "Booking\\.com\\s*[–-]\\s*([A-Z0-9]+)\\s+is your verification code",
        Pattern.CASE_INSENSITIVE);

    public static String randomEmail() {
        requireConfig();
        return "user" + System.currentTimeMillis() + "@" + SERVER_DOMAIN;
    }

    public static String getOtp(String email) throws MailosaurException, IOException {
        requireConfig();

        MailosaurClient client = new MailosaurClient(API_KEY);
        MessageListResult result = client.messages().list(SERVER_ID);

        for (MessageSummary msg : result.items()) {
            if (msg.to() != null && msg.to().stream()
                    .anyMatch(addr -> email.equals(addr.email()))) {
                String subject = msg.subject();
                System.out.println("Mailosaur subject: " + subject);
                Matcher matcher = OTP_PATTERN.matcher(subject);
                if (matcher.find()) {
                    return matcher.group(1);
                }
            }
        }

        throw new RuntimeException("Could not find OTP for " + email + " in Mailosaur inbox");
    }

    private static void requireConfig() {
        if (API_KEY == null || SERVER_ID == null || SERVER_DOMAIN == null) {
            throw new IllegalStateException(
                "Mailosaur credentials not configured — set MAILOSAUR_API_KEY, " +
                "MAILOSAUR_SERVER_ID and MAILOSAUR_DOMAIN environment variables.");
        }
    }
}
