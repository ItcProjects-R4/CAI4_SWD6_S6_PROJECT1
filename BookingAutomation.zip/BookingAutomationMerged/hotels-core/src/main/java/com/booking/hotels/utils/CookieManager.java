package com.booking.hotels.utils;

import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.*;

import java.io.*;
import java.time.Duration;

/**
 * Saves/restores the signed-in session's cookies between test runs so that
 * tests which require an authenticated user (My Account, Confirmation page)
 * don't have to re-run the full OTP sign-in flow every single time.
 */
public class CookieManager {

    private static final String COOKIE_FILE = "target/.booking-cookies.ser";

    public static boolean tryRestoreSession(WebDriver driver) {
        File f = new File(COOKIE_FILE);
        if (!f.exists()) return false;

        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(f))) {
            @SuppressWarnings("unchecked")
            java.util.Set<Cookie> cookies = (java.util.Set<Cookie>) ois.readObject();
            for (Cookie ck : cookies) {
                try {
                    driver.manage().addCookie(ck);
                } catch (Exception ignored) {}
            }

            driver.navigate().refresh();
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
            wait.until(ExpectedConditions.presenceOfElementLocated(
                By.xpath("//button[@data-testid='header-profile']")));
            System.out.println("Session restored from saved cookies");
            return true;
        } catch (Exception e) {
            System.out.println("Saved cookies expired or invalid: " + e.getMessage());
            f.delete();
            return false;
        }
    }

    public static void cleanCookies() {
        File f = new File(COOKIE_FILE);
        if (f.exists() && f.delete()) {
            System.out.println("Cleaned up session cookies");
        }
    }

    public static void saveSession(WebDriver driver) {
        File f = new File(COOKIE_FILE);
        f.getParentFile().mkdirs();
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(f))) {
            oos.writeObject(driver.manage().getCookies());
            System.out.println("Session cookies saved to " + COOKIE_FILE);
        } catch (IOException e) {
            System.err.println("Failed to save cookies: " + e.getMessage());
        }
    }
}
