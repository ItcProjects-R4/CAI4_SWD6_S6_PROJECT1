package com.booking.hotels.base;

import com.booking.hotels.pages.HomePage;
import com.booking.hotels.pages.SignInPage;
import com.booking.hotels.utils.CookieManager;
import org.testng.annotations.BeforeMethod;

public class AuthenticatedBaseTest extends BaseTest {

    protected HomePage homePage;
    protected SignInPage signInPage;

    @BeforeMethod
    public void setUpWithSignIn() throws Exception {
        // Try to restore session from saved cookies first
        if (CookieManager.tryRestoreSession(driver)) {
            homePage = new HomePage(driver);
            return;
        }

        homePage = new HomePage(driver);
        homePage.signInDirect();
        signInPage = new SignInPage(driver);
        signInPage.loginWithRandomEmail();
        CookieManager.saveSession(driver);
    }
}
