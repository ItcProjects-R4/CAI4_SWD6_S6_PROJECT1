package com.booking.hotels.pages;

import com.booking.hotels.base.BasePage;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

/**
 * Merged from two near-identical submissions: the in-project version
 * checked isLoaded() via the URL ("/hotel/"), while a separately uploaded
 * version checked it via the visible hotel-name heading. Both checks are
 * kept here since they cover slightly different failure modes (URL check
 * still passes even if the page is blank/erroring; element check confirms
 * actual content rendered).
 */
public class PropertyDetailsPage extends BasePage {

    @FindBy(css = "h2.pp-header__title")
    private WebElement hotelName;

    public PropertyDetailsPage(WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
    }

    public boolean isLoaded() {
        return getCurrentUrl().contains("/hotel/") && hotelName.isDisplayed();
    }

    public String getHotelName() {
        return hotelName.getText();
    }
}
