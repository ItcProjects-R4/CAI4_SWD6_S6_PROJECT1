package com.booking.hotels.pages;

import com.booking.hotels.base.BasePage;
import org.openqa.selenium.*;
import org.openqa.selenium.support.*;
import org.openqa.selenium.support.ui.*;

import java.time.Duration;

/**
 * Home page object.
 *
 * Merged from two teammates:
 *   - "Tester1" wrote the original search bar / nav tabs / deals section.
 *   - "myaccount" added the sign-in popup flow and profile-dropdown
 *     navigation on top of the same class, so this is the superset of
 *     both — nothing from either submission was dropped.
 */
public class HomePage extends BasePage {

    // ─── Locators ────────────────────────────────────────────────

    // Nav Tabs
    private final By staysTab        = By.xpath("//a[contains(@aria-label,'Stays') or .//span[text()='Stays']]");
    private final By flightsTab      = By.xpath("//a[contains(@aria-label,'Flights') or .//span[text()='Flights']]");
    private final By carRentalsTab   = By.xpath("//a[contains(@aria-label,'Car rentals') or .//span[text()='Car rentals']]");
    private final By attractionsTab  = By.xpath("//a[contains(@aria-label,'Attractions') or .//span[text()='Attractions']]");
    private final By airportTaxisTab = By.xpath("//a[contains(@aria-label,'Airport taxis') or .//span[text()='Airport taxis']]");

    // Search Bar
    private final By destinationInput    = By.xpath("//input[@placeholder='Where are you going?']");
    private final By destinationDropdown = By.xpath("//ul[@role='listbox']//li[1]");
    private final By checkInDate         = By.xpath("//button[@data-testid='date-display-field-start']");
    private final By checkOutDate        = By.xpath("//button[@data-testid='date-display-field-end']");
    private final By guestsRoomsBtn      = By.xpath("//button[@data-testid='occupancy-config']");
    private final By searchBtn           = By.xpath("//button[@type='submit' and .//span[text()='Search']]");

    // Guests & Rooms
    private final By adultsIncrease   = By.xpath("(//button[@aria-label='Increase number of Adults'])[1]");
    private final By adultsDecrease   = By.xpath("(//button[@aria-label='Decrease number of Adults'])[1]");
    private final By childrenIncrease = By.xpath("(//button[@aria-label='Increase number of Children'])[1]");
    private final By roomsIncrease    = By.xpath("(//button[@aria-label='Increase number of Rooms'])[1]");

    // Calendar
    private final By nextMonthArrow  = By.xpath("//button[@aria-label='Next month']");

    // Currency / Language
    private final By currencyBtn     = By.xpath("//button[@data-testid='header-currency-picker-trigger']");
    private final By languageBtn     = By.xpath("//button[@data-testid='header-language-picker-trigger']");

    // Sign In
    private final By signInBtn        = By.xpath("//a[contains(@href,'sign-in') or .//span[text()='Sign in']]");
    private final By signInOrRegister = By.xpath("//button[.//span[text()='Sign in or register']] | //a[.//span[text()='Sign in or register']]");

    // Profile dropdown (post sign-in)
    private final By profileAvatar  = By.xpath("//button[@data-testid='header-profile']");
    private final By myAccountLink  = By.xpath("//a[contains(@href,'myaccount')]");

    // Register your property
    private final By listPropertyBtn = By.xpath("//a[.//span[contains(text(),'List your property')]]");

    // Deals & Offers section
    private final By dealsSection    = By.xpath("//section[contains(@aria-labelledby,'deals')]");
    private final By dealCards       = By.xpath("//div[@data-testid='deal-component']");

    // ─── Constructor ─────────────────────────────────────────────

    public HomePage(WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
    }

    // ─── Navigation ──────────────────────────────────────────────

    public void clickStaysTab()        { click(staysTab); }
    public void clickFlightsTab()      { click(flightsTab); }
    public void clickCarRentalsTab()   { click(carRentalsTab); }
    public void clickAttractionsTab()  { click(attractionsTab); }
    public void clickAirportTaxisTab() { click(airportTaxisTab); }
    public void clickSignIn()          { click(signInBtn); }
    public void clickListProperty()    { click(listPropertyBtn); }
    public void clickCurrencyBtn()     { click(currencyBtn); }
    public void clickLanguageBtn()     { click(languageBtn); }

    public boolean isSignInTriggerDisplayed() { return isDisplayed(signInBtn); }

    // ─── Sign-In Flow ─────────────────────────────────────────────

    public SignInPage signInFromPopup() {
        try {
            WebDriverWait quick = new WebDriverWait(driver, Duration.ofSeconds(3));
            quick.until(ExpectedConditions.visibilityOfElementLocated(signInOrRegister));
            jsClick(signInOrRegister);
        } catch (TimeoutException e) {
            driver.get("https://account.booking.com/sign-in");
        }

        waitForSignInPage();
        return new SignInPage(driver);
    }

    public void signInDirect() {
        driver.get("https://account.booking.com/sign-in");
        waitForSignInPage();
    }

    private void waitForSignInPage() {
        wait.until(ExpectedConditions.or(
            ExpectedConditions.urlContains("account.booking.com"),
            ExpectedConditions.presenceOfElementLocated(By.cssSelector("#username"))
        ));
    }

    // ─── Profile Dropdown (post sign-in) ──────────────────────────

    public MyAccountPage navigateToMyAccount() {
        wait.until(ExpectedConditions.elementToBeClickable(profileAvatar));
        click(profileAvatar);
        wait.until(ExpectedConditions.elementToBeClickable(myAccountLink));
        WebElement el = driver.findElement(myAccountLink);
        new org.openqa.selenium.interactions.Actions(driver).doubleClick(el).perform();
        return new MyAccountPage(driver);
    }

    // ─── Search Actions ──────────────────────────────────────────

    public void enterDestination(String destination) {
        click(destinationInput);
        type(destinationInput, destination);
        waitForVisible(destinationDropdown);
        click(destinationDropdown);
    }

    public void selectDateByText(String date) {
        // date format: "2024-05-10"
        By dateCell = By.xpath("//td[@data-date='" + date + "']//span");
        waitForClickable(dateCell);
        click(dateCell);
    }

    public void clickNextMonth() {
        click(nextMonthArrow);
    }

    public void openGuestsPanel() {
        click(guestsRoomsBtn);
    }

    public void increaseAdults(int times) {
        for (int i = 0; i < times; i++) click(adultsIncrease);
    }

    public void decreaseAdults(int times) {
        for (int i = 0; i < times; i++) click(adultsDecrease);
    }

    public void increaseChildren(int times) {
        for (int i = 0; i < times; i++) click(childrenIncrease);
    }

    public void increaseRooms(int times) {
        for (int i = 0; i < times; i++) click(roomsIncrease);
    }

    public void clickSearch() {
        click(searchBtn);
    }

    // ─── Full Search Flow ─────────────────────────────────────────

    public SearchResultsPage searchFor(String destination, String checkIn, String checkOut) {
        enterDestination(destination);
        click(checkInDate);
        selectDateByText(checkIn);
        selectDateByText(checkOut);
        clickSearch();
        return new SearchResultsPage(driver);
    }

    // ─── Getters / Verifications ──────────────────────────────────

    public boolean isSearchBarDisplayed()    { return isDisplayed(destinationInput); }
    public boolean isSignInBtnDisplayed()    { return isDisplayed(signInBtn); }
    public boolean isDealsSectionDisplayed() { return isDisplayed(dealsSection); }
    public boolean isStaysTabActive()        { return isDisplayed(staysTab); }

    public String getDestinationInputValue() {
        return driver.findElement(destinationInput).getAttribute("value");
    }

    public int getDealCardsCount() {
        return driver.findElements(dealCards).size();
    }
}
