package com.booking.hotels.base;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.*;

import java.time.Duration;

/**
 * BaseTest for the hotels-core module.
 *
 * NOTE: the "myaccount" submission included Chrome DevTools Protocol (CDP)
 * commands that actively hid navigator.webdriver, spoofed the WebGL/canvas
 * fingerprint, and overrode the user-agent — i.e. anti-bot-detection
 * "stealth" evasion aimed at booking.com's own bot defenses. That has been
 * intentionally removed here: it isn't needed for functional UI testing
 * and isn't something this merge should carry forward by default. If your
 * test run genuinely needs it, re-add it deliberately with the team's
 * sign-off rather than by default.
 */
public class BaseTest {

    protected WebDriver driver;
    protected static final String BASE_URL = "https://www.booking.com";

    @BeforeMethod
    public void setUp() {
        WebDriverManager.chromedriver().setup();

        ChromeOptions options = new ChromeOptions();
        options.addArguments("--start-maximized");
        options.addArguments("--disable-notifications");
        options.addArguments("--disable-popup-blocking");
        // options.addArguments("--headless=new");  // uncomment for CI/CD

        driver = new ChromeDriver(options);
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
        driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(30));
        driver.get(BASE_URL);
    }

    @AfterMethod
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }
}
