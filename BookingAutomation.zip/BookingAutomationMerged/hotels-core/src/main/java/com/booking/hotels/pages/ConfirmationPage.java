package com.booking.hotels.pages;

import com.booking.hotels.base.BasePage;
import org.openqa.selenium.*;
import org.openqa.selenium.support.*;

public class ConfirmationPage extends BasePage {

    private final By confirmationHeader = By.xpath("//h1[contains(@class,'confirmation') or contains(text(),'confirmed')]");
    private final By bookingRefNumber   = By.xpath("//span[@data-testid='booking-reference'] | //strong[contains(text(),'PIN')]");
    private final By propertyName       = By.xpath("//div[@data-testid='property-card-title'] | //h2[contains(@class,'hotel-title')]");
    private final By checkInDate        = By.xpath("//div[@data-testid='checkin-date'] | //p[contains(text(),'Check-in')]");
    private final By checkOutDate       = By.xpath("//div[@data-testid='checkout-date'] | //p[contains(text(),'Check-out')]");
    private final By roomDetails        = By.xpath("//div[@data-testid='room-details']");
    private final By guestName          = By.xpath("//div[@data-testid='guest-details']//span[contains(@class,'name')]");
    private final By totalPrice         = By.xpath("//div[@data-testid='price-summary']//span[contains(@class,'total')] | //span[@data-testid='total-price']");
    private final By bookingStatus      = By.xpath("//div[@data-testid='booking-status'] | //span[contains(text(),'confirmed')]");
    private final By printBtn           = By.xpath("//button[.//span[text()='Print']] | //a[contains(text(),'Print')]");
    private final By emailBtn           = By.xpath("//button[.//span[text()='Email']] | //button[contains(text(),'Email')]");
    private final By viewBookingBtn     = By.xpath("//a[contains(text(),'View booking')]");
    private final By paymentSummary     = By.xpath("//div[contains(@data-testid,'payment-summary')]");
    private final By addressField       = By.xpath("//div[contains(@data-testid,'property-address')]");

    public ConfirmationPage(WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
    }

    public boolean isConfirmationDisplayed() {
        return isDisplayed(confirmationHeader);
    }

    public String getBookingReference() { return getText(bookingRefNumber); }
    public String getPropertyName()     { return getText(propertyName); }
    public String getCheckInDate()      { return getText(checkInDate); }
    public String getCheckOutDate()     { return getText(checkOutDate); }
    public String getGuestName()        { return getText(guestName); }
    public String getTotalPrice()       { return getText(totalPrice); }
    public String getBookingStatus()    { return getText(bookingStatus); }

    public boolean isRoomDetailsDisplayed()    { return isDisplayed(roomDetails); }
    public boolean isPrintBtnDisplayed()       { return isDisplayed(printBtn); }
    public boolean isEmailBtnDisplayed()       { return isDisplayed(emailBtn); }
    public boolean isViewBookingBtnDisplayed() { return isDisplayed(viewBookingBtn); }
    public boolean isPaymentSummaryDisplayed() { return isDisplayed(paymentSummary); }
    public boolean isAddressDisplayed()        { return isDisplayed(addressField); }

    public void clickPrint()       { click(printBtn); }
    public void clickEmail()       { click(emailBtn); }
    public void clickViewBooking() { click(viewBookingBtn); }

    public boolean isBookingRefValid() {
        String ref = getBookingReference();
        return ref != null && !ref.isEmpty() && ref.length() >= 6;
    }

    public boolean isUrlConfirmation() {
        return getCurrentUrl().contains("confirmation") ||
               getCurrentUrl().contains("booking/confirmed");
    }
}
