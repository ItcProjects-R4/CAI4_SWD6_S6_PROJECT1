package com.booking.hotels.tests;

import com.booking.hotels.base.BaseTest;
import com.booking.hotels.pages.HomePage;
import com.booking.hotels.pages.SignInPage;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class SignInPageTest extends BaseTest {

    private HomePage homePage;
    private SignInPage signInPage;

    @BeforeMethod
    public void initPages() {
        homePage = new HomePage(driver);
    }

    @Test(description = "TC_SIGN_006: Full sign-in flow with Mailosaur temp email")
    public void verifyFullSignInFlow() throws Exception {
        String apiKey = System.getenv("MAILOSAUR_API_KEY");
        String serverId = System.getenv("MAILOSAUR_SERVER_ID");
        String domain = System.getenv("MAILOSAUR_DOMAIN");

        if (apiKey == null || serverId == null || domain == null) {
            System.out.println("Mailosaur env vars not set - skipping full sign-in");
            Assert.assertTrue(true, "Mailosaur not configured, skipping test");
            return;
        }

        try {
            signInPage = homePage.signInFromPopup();
        } catch (Exception e) {
            System.out.println("Popup sign-in failed, using direct URL: " + e.getMessage());
            homePage.signInDirect();
            signInPage = new SignInPage(driver);
        }
        signInPage.loginWithRandomEmail();

        Assert.assertTrue(driver.getCurrentUrl().contains("booking.com"),
                "Should land on booking.com after successful sign-in");
    }
}
