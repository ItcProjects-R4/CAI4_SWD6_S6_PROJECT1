package com.booking.hotels.tests;

import com.booking.hotels.base.BaseTest;
import com.booking.hotels.pages.HomePage;
import com.booking.hotels.pages.SearchResultsPage;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class HomePageTest extends BaseTest {

    private HomePage homePage;

    @BeforeMethod
    public void initPage() {
        homePage = new HomePage(driver);
    }

    @Test(description = "TC_HOME_001: Verify Home Page loads successfully")
    public void verifyHomePageLoads() {
        Assert.assertTrue(driver.getTitle().contains("Booking.com"),
                "Page title should contain Booking.com");
        Assert.assertTrue(homePage.isSearchBarDisplayed(),
                "Search bar should be visible on home page");
    }

    @Test(description = "TC_HOME_002: Verify search bar elements are displayed")
    public void verifySearchBarElements() {
        Assert.assertTrue(homePage.isSearchBarDisplayed(),
                "Destination input should be displayed");
        Assert.assertTrue(homePage.isStaysTabActive(),
                "Stays tab should be active by default");
    }

    @Test(description = "TC_HOME_003: Verify all navigation tabs are clickable")
    public void verifyNavigationTabs() {
        homePage.clickFlightsTab();
        Assert.assertTrue(driver.getCurrentUrl().contains("flights") ||
                        driver.getTitle().toLowerCase().contains("flight"),
                "Should navigate to flights section");

        driver.navigate().back();
        homePage = new HomePage(driver);
        homePage.clickCarRentalsTab();
        Assert.assertTrue(driver.getCurrentUrl().contains("car") ||
                        driver.getTitle().toLowerCase().contains("car"),
                "Should navigate to car rentals section");
    }

    @Test(description = "TC_HOME_004: Verify destination input accepts text and shows suggestions")
    public void verifyDestinationInput() {
        homePage.enterDestination("Cairo");
        Assert.assertFalse(homePage.getDestinationInputValue().isEmpty(),
                "Destination field should not be empty after entering text");
    }

    @Test(description = "TC_HOME_005: Verify search redirects to results page with valid inputs")
    public void verifySearchWithValidData() {
        SearchResultsPage resultsPage = homePage.searchFor(
                "Cairo",
                "2026-08-10",
                "2026-08-15"
        );
        Assert.assertTrue(resultsPage.isResultsPageDisplayed(),
                "Should navigate to search results page");
        Assert.assertTrue(resultsPage.isUrlContains("searchresults"),
                "URL should contain 'searchresults'");
    }

    @Test(description = "TC_HOME_006: Verify error shown when searching with empty destination")
    public void verifyEmptyDestinationSearch() {
        homePage.clickSearch();
        Assert.assertFalse(driver.getCurrentUrl().contains("searchresults"),
                "Should NOT navigate to results when destination is empty");
    }

    @Test(description = "TC_HOME_007: Verify guests panel - increase adults count")
    public void verifyIncreaseAdults() {
        homePage.openGuestsPanel();
        homePage.increaseAdults(2); // default 2 -> becomes 4
        Assert.assertTrue(homePage.isSearchBarDisplayed(),
                "Page should still be stable after adjusting guests");
    }

    @Test(description = "TC_HOME_008: Verify children can be added in guests panel")
    public void verifyAddChildren() {
        homePage.openGuestsPanel();
        homePage.increaseChildren(1);
        Assert.assertTrue(homePage.isSearchBarDisplayed(),
                "Page should be stable after adding children");
    }

    @Test(description = "TC_HOME_009: Verify Sign In button is displayed and clickable")
    public void verifySignInButton() {
        Assert.assertTrue(homePage.isSignInBtnDisplayed(),
                "Sign In button should be visible");
        homePage.clickSignIn();
        Assert.assertTrue(driver.getCurrentUrl().contains("sign-in") ||
                        driver.getCurrentUrl().contains("login"),
                "Should navigate to sign in page");
    }

    @Test(description = "TC_HOME_010: Verify 'List your property' link navigates correctly")
    public void verifyListYourProperty() {
        homePage.clickListProperty();
        Assert.assertTrue(driver.getCurrentUrl().contains("partner") ||
                        driver.getCurrentUrl().contains("list-your-property"),
                "Should navigate to property listing page");
    }

    @Test(description = "TC_HOME_011: Verify deals/offers section is visible on homepage")
    public void verifyDealsSection() {
        Assert.assertTrue(homePage.isDealsSectionDisplayed(),
                "Deals & Offers section should be visible");
    }

    @Test(description = "TC_HOME_012: Verify currency picker opens")
    public void verifyCurrencyPicker() {
        homePage.clickCurrencyBtn();
        Assert.assertTrue(driver.getPageSource().contains("currency") ||
                        driver.getPageSource().contains("EGP") ||
                        driver.getPageSource().contains("USD"),
                "Currency picker should open");
    }
}
