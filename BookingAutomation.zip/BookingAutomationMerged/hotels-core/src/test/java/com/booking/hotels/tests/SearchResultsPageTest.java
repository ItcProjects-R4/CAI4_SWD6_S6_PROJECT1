package com.booking.hotels.tests;

import com.booking.hotels.base.BaseTest;
import com.booking.hotels.pages.HomePage;
import com.booking.hotels.pages.SearchResultsPage;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class SearchResultsPageTest extends BaseTest {

    private SearchResultsPage resultsPage;

    @BeforeMethod
    public void navigateToResults() {
        HomePage homePage = new HomePage(driver);
        resultsPage = homePage.searchFor("Cairo", "2026-08-10", "2026-08-15");
        resultsPage.waitForResultsToLoad();
    }

    @Test(description = "TC_SR_001: Verify search results page loads with results")
    public void verifyResultsPageLoads() {
        Assert.assertTrue(resultsPage.isResultsPageDisplayed(),
                "Results count should be visible");
        Assert.assertTrue(resultsPage.getPropertyCount() > 0,
                "At least one property card should be shown");
    }

    @Test(description = "TC_SR_002: Verify results count text contains 'found'")
    public void verifyResultsCountText() {
        String countText = resultsPage.getResultsCountText();
        Assert.assertTrue(countText.contains("found"),
                "Results count text should contain 'found': " + countText);
    }

    @Test(description = "TC_SR_003: Verify filter sidebar is displayed")
    public void verifyFilterSectionVisible() {
        Assert.assertTrue(resultsPage.isFilterSectionDisplayed(),
                "Filter section should be visible on results page");
    }

    @Test(description = "TC_SR_004: Verify sort dropdown is displayed")
    public void verifySortDropdownVisible() {
        Assert.assertTrue(resultsPage.isSortDropdownDisplayed(),
                "Sort dropdown should be visible");
    }

    @Test(description = "TC_SR_005: Verify sorting by lowest price updates results")
    public void verifySortByLowestPrice() {
        int countBefore = resultsPage.getPropertyCount();
        resultsPage.sortByLowestPrice();
        Assert.assertTrue(resultsPage.getPropertyCount() > 0,
                "Results should still appear after sorting by lowest price");
        Assert.assertTrue(resultsPage.isUrlContains("price") ||
                        resultsPage.getPropertyCount() == countBefore,
                "Sort by price should work");
    }

    @Test(description = "TC_SR_006: Verify sorting by top review score updates results")
    public void verifySortByTopReview() {
        resultsPage.sortByTopReviewScore();
        Assert.assertTrue(resultsPage.getPropertyCount() > 0,
                "Results should appear after sorting by review score");
    }

    @Test(description = "TC_SR_007: Verify filter by 5-star rating narrows results")
    public void verifyFilterBy5Stars() {
        int countBefore = resultsPage.getPropertyCount();
        resultsPage.filterByStar(5);
        int countAfter = resultsPage.getPropertyCount();
        Assert.assertTrue(countAfter <= countBefore,
                "5-star filter should reduce or maintain property count");
    }

    @Test(description = "TC_SR_008: Verify filter by 4-star rating works")
    public void verifyFilterBy4Stars() {
        resultsPage.filterByStar(4);
        Assert.assertTrue(resultsPage.getPropertyCount() > 0,
                "Should find 4-star properties in Cairo");
    }

    @Test(description = "TC_SR_009: Verify filter by 3-star rating works")
    public void verifyFilterBy3Stars() {
        resultsPage.filterByStar(3);
        Assert.assertTrue(resultsPage.isResultsPageDisplayed(),
                "Results page should still be displayed after 3-star filter");
    }

    @Test(description = "TC_SR_010: Verify filter by 'Very Good 8+' review score")
    public void verifyFilterByVeryGoodReview() {
        int countBefore = resultsPage.getPropertyCount();
        resultsPage.filterByReviewVeryGood();
        int countAfter = resultsPage.getPropertyCount();
        Assert.assertTrue(countAfter <= countBefore,
                "Review filter should reduce or maintain results count");
    }

    @Test(description = "TC_SR_011: Verify filter by 'Wonderful 9+' review score")
    public void verifyFilterByExcellentReview() {
        resultsPage.filterByReviewExcellent();
        Assert.assertTrue(resultsPage.isResultsPageDisplayed(),
                "Page should be stable after excellent review filter");
    }

    @Test(description = "TC_SR_012: Verify filter by property type Hotels")
    public void verifyFilterByHotels() {
        resultsPage.filterByHotels();
        Assert.assertTrue(resultsPage.getPropertyCount() > 0,
                "Should find hotels in Cairo");
    }

    @Test(description = "TC_SR_013: Verify filter by property type Apartments")
    public void verifyFilterByApartments() {
        resultsPage.filterByApartments();
        Assert.assertTrue(resultsPage.isResultsPageDisplayed(),
                "Results page should be stable after apartment filter");
    }

    @Test(description = "TC_SR_014: Verify filter by Free WiFi amenity")
    public void verifyFilterByFreeWifi() {
        int countBefore = resultsPage.getPropertyCount();
        resultsPage.filterByWifi();
        int countAfter = resultsPage.getPropertyCount();
        Assert.assertTrue(countAfter <= countBefore,
                "Free WiFi filter should reduce or maintain property count");
    }

    @Test(description = "TC_SR_015: Verify filter by Free Parking amenity")
    public void verifyFilterByFreeParking() {
        resultsPage.filterByParking();
        Assert.assertTrue(resultsPage.isResultsPageDisplayed(),
                "Page should be stable after parking filter");
    }

    @Test(description = "TC_SR_016: Verify filter by Swimming Pool amenity")
    public void verifyFilterByPool() {
        resultsPage.filterByPool();
        Assert.assertTrue(resultsPage.isResultsPageDisplayed(),
                "Page should be stable after pool filter");
    }

    @Test(description = "TC_SR_017: Verify filter by Breakfast Included")
    public void verifyFilterByBreakfast() {
        resultsPage.filterByBreakfast();
        Assert.assertTrue(resultsPage.isResultsPageDisplayed(),
                "Page should be stable after breakfast filter");
    }

    @Test(description = "TC_SR_018: Verify filter by All-Inclusive meal plan")
    public void verifyFilterByAllInclusive() {
        resultsPage.filterByAllInclusive();
        Assert.assertTrue(resultsPage.isResultsPageDisplayed(),
                "Page should be stable after all-inclusive filter");
    }

    @Test(description = "TC_SR_019: Verify Genius filter shows Genius deals")
    public void verifyFilterByGenius() {
        resultsPage.filterByGenius();
        Assert.assertTrue(resultsPage.isResultsPageDisplayed(),
                "Page should be stable after Genius filter");
    }

    @Test(description = "TC_SR_020: Verify Travel Sustainable filter")
    public void verifyFilterBySustainable() {
        resultsPage.filterBySustainable();
        Assert.assertTrue(resultsPage.isResultsPageDisplayed(),
                "Page should be stable after sustainable filter");
    }

    @Test(description = "TC_SR_021: Verify Clear All Filters resets the results")
    public void verifyClearAllFilters() {
        resultsPage.filterByStar(5);
        int filteredCount = resultsPage.getPropertyCount();
        resultsPage.clearAllFilters();
        int clearedCount = resultsPage.getPropertyCount();
        Assert.assertTrue(clearedCount >= filteredCount,
                "Clearing filters should restore more or equal results");
    }

    @Test(description = "TC_SR_022: Verify switching between list and grid view")
    public void verifyViewToggle() {
        resultsPage.switchToGridView();
        Assert.assertTrue(resultsPage.getPropertyCount() > 0,
                "Properties should still show in grid view");
        resultsPage.switchToListView();
        Assert.assertTrue(resultsPage.getPropertyCount() > 0,
                "Properties should still show in list view");
    }

    @Test(description = "TC_SR_023: Verify 'Show on Map' button is displayed")
    public void verifyShowOnMapButton() {
        Assert.assertTrue(resultsPage.isMapButtonDisplayed(),
                "Show on Map button should be visible");
    }

    @Test(description = "TC_SR_024: Verify clicking first property navigates to property details")
    public void verifyClickFirstProperty() {
        String propertyName = resultsPage.getFirstPropertyName();
        Assert.assertFalse(propertyName.isEmpty(),
                "First property should have a name");
        resultsPage.clickFirstProperty();
        Assert.assertTrue(driver.getWindowHandles().size() > 1 ||
                        driver.getCurrentUrl().contains("hotel"),
                "Should navigate to property details page");
    }

    @Test(description = "TC_SR_025: Verify combining multiple filters works correctly")
    public void verifyCombineMultipleFilters() {
        resultsPage.filterByStar(5);
        resultsPage.filterByWifi();
        Assert.assertTrue(resultsPage.isResultsPageDisplayed(),
                "Page should be stable after applying multiple filters");
    }
}
