package com.booking.flights.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import java.util.List;

/**
 * Page Object for Booking.com Flights Search Page.
 * Covers: one-way / round-trip toggle, origin, destination,
 * date picker, passenger selector, cabin class, and search submit.
 */
public class FlightSearchPage extends BasePage {

    // ── Trip Type ──────────────────────────────────────────────────────────────
    @FindBy(css = "[data-testid='flight-type-selector-item-ROUND_TRIP'], " +
                  "label[for*='roundtrip'], span[data-ui-name='input_round_trip_radio']")
    private WebElement roundTripBtn;

    @FindBy(css = "[data-testid='flight-type-selector-item-ONE_WAY'], " +
                  "label[for*='oneway'], span[data-ui-name='input_one_way_radio']")
    private WebElement oneWayBtn;

    // ── Origin / Destination ──────────────────────────────────────────────────
    @FindBy(css = "input[placeholder*='Where from'], [data-testid='origin-airport']," +
                  " [aria-label*='From']")
    private WebElement originInput;

    @FindBy(css = "input[placeholder*='Where to'], [data-testid='destination-airport']," +
                  " [aria-label*='To']")
    private WebElement destinationInput;

    // ── Dates ──────────────────────────────────────────────────────────────────
    @FindBy(css = "[data-testid='depart-date'], [placeholder*='Depart'], " +
                  "[aria-label*='Departure']")
    private WebElement departDateField;

    @FindBy(css = "[data-testid='return-date'], [placeholder*='Return'], " +
                  "[aria-label*='Return']")
    private WebElement returnDateField;

    // ── Passengers ─────────────────────────────────────────────────────────────
    @FindBy(css = "[data-testid='passengers-selector'], [aria-label*='Passengers']," +
                  " button[data-ui-name*='passenger']")
    private WebElement passengersDropdown;

    @FindBy(css = "button[data-testid='adults-increase'], [aria-label='Increase number of Adults']")
    private WebElement adultsIncreaseBtn;

    @FindBy(css = "[data-testid='adults-count'], [data-ui-name='input_adults_count']")
    private WebElement adultsCount;

    // ── Cabin Class ────────────────────────────────────────────────────────────
    @FindBy(css = "[data-testid='cabin-class-selector'], select[name*='cabin']," +
                  " [aria-label*='Cabin class']")
    private WebElement cabinClassDropdown;

    // ── Search Button ──────────────────────────────────────────────────────────
    @FindBy(css = "button[type='submit'], [data-testid='search-button']," +
                  " button[aria-label*='Search']")
    private WebElement searchButton;

    // ── Autocomplete suggestions ───────────────────────────────────────────────
    private static final By SUGGESTION_LIST =
            By.cssSelector("[data-testid='autocomplete-result'], " +
                           "li[role='option'], .dropdown-list-item");

    // =========================================================================
    // Public Actions
    // =========================================================================

    public FlightSearchPage selectRoundTrip() {
        log.info("Selecting Round Trip");
        jsClick(roundTripBtn);
        return this;
    }

    public FlightSearchPage selectOneWay() {
        log.info("Selecting One Way");
        jsClick(oneWayBtn);
        return this;
    }

    public FlightSearchPage setOrigin(String origin) {
        log.info("Setting origin: {}", origin);
        click(originInput);
        type(originInput, origin);
        selectFirstSuggestion();
        return this;
    }

    public FlightSearchPage setDestination(String destination) {
        log.info("Setting destination: {}", destination);
        click(destinationInput);
        type(destinationInput, destination);
        selectFirstSuggestion();
        return this;
    }

    public FlightSearchPage setDepartureDate(String date) {
        log.info("Setting departure date: {}", date);
        click(departDateField);
        // Try direct input first, fall back to calendar picker
        try {
            departDateField.clear();
            departDateField.sendKeys(date);
            departDateField.sendKeys(Keys.TAB);
        } catch (Exception e) {
            pickDateFromCalendar(date);
        }
        return this;
    }

    public FlightSearchPage setReturnDate(String date) {
        log.info("Setting return date: {}", date);
        try {
            click(returnDateField);
            returnDateField.clear();
            returnDateField.sendKeys(date);
            returnDateField.sendKeys(Keys.TAB);
        } catch (Exception e) {
            pickDateFromCalendar(date);
        }
        return this;
    }

    public FlightSearchPage setAdults(int count) {
        log.info("Setting adults count: {}", count);
        click(passengersDropdown);
        // Click "+" until desired count is reached (default is usually 1)
        int current = getCurrentAdultsCount();
        while (current < count) {
            click(adultsIncreaseBtn);
            current++;
        }
        // Close the dropdown
        click(By.cssSelector("button[data-testid='passengers-done'], " +
                             "button[aria-label*='Done'], button[data-ui-name*='done']"));
        return this;
    }

    public FlightSearchResultsPage clickSearch() {
        log.info("Clicking Search button");
        jsScrollIntoView(searchButton);
        click(searchButton);
        return new FlightSearchResultsPage();
    }

    // =========================================================================
    // Private Helpers
    // =========================================================================

    private void selectFirstSuggestion() {
        try {
            List<WebElement> suggestions = wait.until(
                    d -> {
                        List<WebElement> els = d.findElements(SUGGESTION_LIST);
                        return els.isEmpty() ? null : els;
                    }
            );
            if (suggestions != null && !suggestions.isEmpty()) {
                suggestions.get(0).click();
                log.debug("First autocomplete suggestion selected.");
            }
        } catch (Exception e) {
            log.warn("No autocomplete suggestion appeared – continuing.");
        }
    }

    private int getCurrentAdultsCount() {
        try {
            return Integer.parseInt(adultsCount.getText().trim());
        } catch (Exception e) {
            return 1;
        }
    }

    private void pickDateFromCalendar(String date) {
        // date format: YYYY-MM-DD
        // Find a day cell with data-date attribute matching the date
        By dayCell = By.cssSelector("[data-date='" + date + "']");
        try {
            waitForVisible(dayCell).click();
        } catch (Exception e) {
            log.warn("Calendar date cell not found for {}", date);
        }
    }
}
