package com.booking.flights.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import java.util.List;

/**
 * Page Object for the Flight Search Results Page.
 * Handles reading results, sorting/filtering, and selecting a flight.
 */
public class FlightSearchResultsPage extends BasePage {

    // ── Results Container ─────────────────────────────────────────────────────
    private static final By RESULTS_CARD =
            By.cssSelector("[data-testid='flight-card'], .flight-card, " +
                           "[class*='ResultCard'], [data-ui-name='flight_result']");

    private static final By LOADING_SPINNER =
            By.cssSelector("[data-testid='loading-spinner'], .bui-spinner, [class*='loading']");

    // ── Sort & Filter ──────────────────────────────────────────────────────────
    @FindBy(css = "[data-testid='sort-cheapest'], button[aria-label*='Cheapest']," +
                  " [data-ui-name='sort_cheapest']")
    private WebElement sortCheapestBtn;

    @FindBy(css = "[data-testid='sort-fastest'], button[aria-label*='Fastest']," +
                  " [data-ui-name='sort_fastest']")
    private WebElement sortFastestBtn;

    // ── Price ──────────────────────────────────────────────────────────────────
    private static final By FLIGHT_PRICE =
            By.cssSelector("[data-testid='price-tag'], .price-text, " +
                           "[class*='price'], [data-ui-name='price']");

    private static final By SELECT_BUTTON =
            By.cssSelector("[data-testid='select-button'], button[class*='select']," +
                           " button[aria-label*='Select'], [data-ui-name='flight_select']");

    // ── Result Summary ─────────────────────────────────────────────────────────
    @FindBy(css = "[data-testid='results-count'], [class*='results-header']")
    private WebElement resultsCount;

    // =========================================================================

    public FlightSearchResultsPage waitForResults() {
        log.info("Waiting for flight search results to load...");
        try {
            waitForInvisibility(LOADING_SPINNER);
        } catch (Exception e) {
            // Spinner may not appear; wait for cards instead
        }
        waitForVisible(RESULTS_CARD);
        log.info("Flight results loaded. Count element: {}", getResultsCountText());
        return this;
    }

    public int getResultsCount() {
        List<WebElement> cards = driver.findElements(RESULTS_CARD);
        log.info("Number of flight cards visible: {}", cards.size());
        return cards.size();
    }

    public String getResultsCountText() {
        try {
            return resultsCount.getText().trim();
        } catch (Exception e) {
            return "N/A";
        }
    }

    public FlightSearchResultsPage sortByCheapest() {
        log.info("Sorting by cheapest");
        jsClick(sortCheapestBtn);
        waitForResults();
        return this;
    }

    public FlightSearchResultsPage sortByFastest() {
        log.info("Sorting by fastest");
        jsClick(sortFastestBtn);
        waitForResults();
        return this;
    }

    public String getFirstFlightPrice() {
        List<WebElement> prices = driver.findElements(FLIGHT_PRICE);
        if (prices.isEmpty()) return "N/A";
        return prices.get(0).getText().trim();
    }

    public FlightDetailsPage selectFirstFlight() {
        log.info("Selecting first available flight");
        List<WebElement> selectBtns = driver.findElements(SELECT_BUTTON);
        if (selectBtns.isEmpty()) {
            throw new RuntimeException("No 'Select' buttons found on results page.");
        }
        jsScrollIntoView(selectBtns.get(0));
        jsClick(selectBtns.get(0));
        return new FlightDetailsPage();
    }

    public boolean hasResults() {
        return getResultsCount() > 0;
    }

    public boolean isOnResultsPage() {
        return getCurrentUrl().contains("flights") &&
               (getCurrentUrl().contains("results") || getCurrentUrl().contains("search"));
    }
}
