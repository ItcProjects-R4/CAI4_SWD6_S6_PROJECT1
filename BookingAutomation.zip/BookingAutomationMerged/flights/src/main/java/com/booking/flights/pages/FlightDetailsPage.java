package com.booking.flights.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

/**
 * Page Object for the Flight Details / Fare Selection Page.
 */
public class FlightDetailsPage extends BasePage {

    // ── Fare Options ──────────────────────────────────────────────────────────
    private static final By FARE_CARD =
            By.cssSelector("[data-testid='fare-card'], .fare-option, [class*='FareCard']");

    private static final By FARE_SELECT_BTN =
            By.cssSelector("[data-testid='fare-select'], button[class*='select-fare']," +
                           " button[aria-label*='Select fare']");

    // ── Flight Summary ────────────────────────────────────────────────────────
    @FindBy(css = "[data-testid='flight-summary-origin'], [class*='departure-city']")
    private WebElement originCity;

    @FindBy(css = "[data-testid='flight-summary-destination'], [class*='arrival-city']")
    private WebElement destinationCity;

    @FindBy(css = "[data-testid='total-price'], [class*='total-price']")
    private WebElement totalPrice;

    // ── CTA ───────────────────────────────────────────────────────────────────
    @FindBy(css = "button[data-testid='continue-to-checkout'], button[class*='continue']," +
                  " button[aria-label*='Continue']")
    private WebElement continueBtn;

    // =========================================================================

    public FlightDetailsPage waitForPage() {
        log.info("Waiting for Flight Details page to load...");
        waitForVisible(FARE_CARD);
        return this;
    }

    public String getTotalPrice() {
        try {
            return totalPrice.getText().trim();
        } catch (Exception e) {
            return "N/A";
        }
    }

    public FlightDetailsPage selectFirstFare() {
        log.info("Selecting first available fare");
        waitForVisible(FARE_SELECT_BTN);
        jsClick(driver.findElements(FARE_SELECT_BTN).get(0));
        return this;
    }

    public PassengerDetailsPage continueToCheckout() {
        log.info("Continuing to checkout");
        waitForVisible(By.cssSelector("button[data-testid='continue-to-checkout']," +
                                      " button[class*='continue']"));
        jsClick(continueBtn);
        return new PassengerDetailsPage();
    }

    public boolean isOnDetailsPage() {
        return getCurrentUrl().contains("flights") && isDisplayed(FARE_CARD);
    }
}
