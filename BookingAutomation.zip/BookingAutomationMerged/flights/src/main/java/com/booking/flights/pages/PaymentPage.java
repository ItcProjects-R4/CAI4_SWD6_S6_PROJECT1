package com.booking.flights.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

/**
 * Page Object for the Payment Page during flight checkout.
 * NOTE: In a real test run against production, you would use a
 * Booking.com sandbox / test card number.  No real payment is made.
 */
public class PaymentPage extends BasePage {

    // ── Card Fields (typically inside an iframe) ───────────────────────────────
    @FindBy(css = "input[name*='cardNumber'], input[data-testid='card-number']," +
                  " input[placeholder*='Card number']")
    private WebElement cardNumberInput;

    @FindBy(css = "input[name*='cardHolder'], input[data-testid='card-name']," +
                  " input[placeholder*='Name on card']")
    private WebElement cardHolderInput;

    @FindBy(css = "input[name*='expiry'], input[data-testid='expiry']," +
                  " input[placeholder*='MM/YY']")
    private WebElement expiryInput;

    @FindBy(css = "input[name*='cvv'], input[data-testid='cvv']," +
                  " input[placeholder*='CVV']")
    private WebElement cvvInput;

    // ── Order Summary ──────────────────────────────────────────────────────────
    @FindBy(css = "[data-testid='order-total'], .total-price, [class*='order-total']")
    private WebElement orderTotal;

    // ── Pay Button ─────────────────────────────────────────────────────────────
    @FindBy(css = "button[data-testid='pay-now'], button[type='submit']," +
                  " button[aria-label*='Pay now']")
    private WebElement payNowButton;

    // ── Confirmation indicators ────────────────────────────────────────────────
    private static final By PAYMENT_IFRAME =
            By.cssSelector("iframe[name*='card'], iframe[id*='payment']," +
                           " iframe[title*='Payment']");

    // =========================================================================

    public PaymentPage waitForPage() {
        log.info("Waiting for Payment page...");
        // Payment page may have iframes – wait for overall page structure
        waitForVisible(By.cssSelector("[data-testid='order-total'], " +
                                      "[class*='order-summary'], .payment-form"));
        return this;
    }

    public String getOrderTotal() {
        try {
            return orderTotal.getText().trim();
        } catch (Exception e) {
            return "N/A";
        }
    }

    /**
     * Fill card details – switches to payment iframe if present.
     * Uses Booking.com test card: 4111 1111 1111 1111.
     */
    public PaymentPage fillCardDetails(String cardNumber, String holder,
                                        String expiry, String cvv) {
        log.info("Filling card details");
        // Switch to iframe if payment is inside one
        boolean insideIframe = false;
        try {
            WebElement iframe = driver.findElement(PAYMENT_IFRAME);
            driver.switchTo().frame(iframe);
            insideIframe = true;
        } catch (Exception ignored) {}

        try {
            type(cardNumberInput, cardNumber);
            type(cardHolderInput, holder);
            type(expiryInput, expiry);
            type(cvvInput, cvv);
        } finally {
            if (insideIframe) driver.switchTo().defaultContent();
        }
        return this;
    }

    public BookingConfirmationPage submitPayment() {
        log.info("Submitting payment");
        jsScrollIntoView(payNowButton);
        click(payNowButton);
        return new BookingConfirmationPage();
    }

    public boolean isOnPaymentPage() {
        return getCurrentUrl().contains("payment") ||
               getCurrentUrl().contains("checkout") ||
               isDisplayed(By.cssSelector("[data-testid='pay-now'], [class*='payment']"));
    }
}
