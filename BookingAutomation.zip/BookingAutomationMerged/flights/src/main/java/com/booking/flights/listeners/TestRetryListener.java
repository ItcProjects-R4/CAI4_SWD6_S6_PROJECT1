package com.booking.flights.listeners;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.IRetryAnalyzer;
import org.testng.ITestResult;

/**
 * Retries a failed test up to MAX_RETRY times before marking it as failed.
 */
public class TestRetryListener implements IRetryAnalyzer {

    private static final Logger log = LogManager.getLogger(TestRetryListener.class);
    private static final int MAX_RETRY = 1;
    private int retryCount = 0;

    @Override
    public boolean retry(ITestResult result) {
        if (retryCount < MAX_RETRY) {
            retryCount++;
            log.warn("Retrying test '{}' – attempt {}/{}",
                     result.getName(), retryCount, MAX_RETRY);
            return true;
        }
        return false;
    }
}
