package com.booking.flights.config;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

/**
 * Singleton ConfigReader – loads config.properties once and provides
 * typed getters throughout the framework.
 */
public class ConfigReader {

    private static final Logger log = LogManager.getLogger(ConfigReader.class);
    private static ConfigReader instance;
    private final Properties properties = new Properties();

    private static final String CONFIG_PATH =
            "src/test/resources/config.properties";

    private ConfigReader() {
        try (FileInputStream fis = new FileInputStream(CONFIG_PATH)) {
            properties.load(fis);
            log.info("Configuration loaded from: {}", CONFIG_PATH);
        } catch (IOException e) {
            throw new RuntimeException("Could not load config.properties: " + e.getMessage(), e);
        }
    }

    public static synchronized ConfigReader getInstance() {
        if (instance == null) {
            instance = new ConfigReader();
        }
        return instance;
    }

    // ── Generic ──────────────────────────────────────────────────────────────

    public String get(String key) {
        String value = System.getProperty(key, properties.getProperty(key));
        if (value == null) {
            throw new RuntimeException("Property '" + key + "' not found in config.properties");
        }
        return value.trim();
    }

    public String get(String key, String defaultValue) {
        return System.getProperty(key, properties.getProperty(key, defaultValue)).trim();
    }

    public int getInt(String key) {
        return Integer.parseInt(get(key));
    }

    public boolean getBoolean(String key) {
        return Boolean.parseBoolean(get(key));
    }

    // ── Convenience getters ───────────────────────────────────────────────────

    public String getBaseUrl()              { return get("base.url"); }
    public String getBrowser()              { return get("browser", "chrome"); }
    public int    getImplicitWait()         { return getInt("implicit.wait"); }
    public int    getExplicitWait()         { return getInt("explicit.wait"); }
    public int    getPageLoadTimeout()      { return getInt("page.load.timeout"); }
    public boolean isHeadless()             { return getBoolean("headless"); }
    public boolean isScreenshotOnFailure()  { return getBoolean("screenshot.on.failure"); }
    public String getReportsDir()           { return get("reports.dir"); }

    // Mailosaur
    public String getMailosaurApiKey()      { return get("mailosaur.api.key"); }
    public String getMailosaurServerId()    { return get("mailosaur.server.id"); }
    public String getMailosaurDomain()      { return get("mailosaur.server.domain"); }
    public String getMailosaurTestAlias()   { return get("mailosaur.test.email.alias"); }
    public int    getMailosaurTimeout()     { return getInt("mailosaur.email.timeout"); }

    // Test Account
    public String getTestEmail()            { return get("test.account.email"); }
    public String getTestPassword()         { return get("test.account.password"); }
    public String getTestFirstName()        { return get("test.account.first.name"); }
    public String getTestLastName()         { return get("test.account.last.name"); }
    public String getTestPhone()            { return get("test.account.phone"); }

    // Flight
    public String getFlightOrigin()         { return get("flight.origin"); }
    public String getFlightDestination()    { return get("flight.destination"); }
    public String getFlightDepartureDate()  { return get("flight.departure.date"); }
    public String getFlightReturnDate()     { return get("flight.return.date"); }
    public int    getFlightAdults()         { return getInt("flight.adults"); }
    public String getFlightCabinClass()     { return get("flight.cabin.class"); }
}
