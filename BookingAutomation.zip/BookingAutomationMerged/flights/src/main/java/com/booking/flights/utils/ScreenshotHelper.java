package com.booking.flights.utils;

import com.booking.flights.config.ConfigReader;
import org.apache.commons.io.FileUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import java.io.File;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * Utility for capturing screenshots.
 */
public class ScreenshotHelper {

    private static final Logger log = LogManager.getLogger(ScreenshotHelper.class);
    private static final ConfigReader config = ConfigReader.getInstance();
    private static final DateTimeFormatter FMT =
            DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss");

    private ScreenshotHelper() {}

    public static String capture(WebDriver driver, String testName) {
        try {
            String timestamp = LocalDateTime.now().format(FMT);
            String fileName  = testName + "_" + timestamp + ".png";
            String filePath  = config.getReportsDir() + "/screenshots/" + fileName;

            File src  = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
            File dest = new File(filePath);
            FileUtils.copyFile(src, dest);

            log.info("Screenshot saved: {}", filePath);
            return filePath;
        } catch (Exception e) {
            log.error("Failed to capture screenshot: {}", e.getMessage());
            return null;
        }
    }
}
