package com.booking.flights.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

/**
 * Page Object for Passenger / Contact Details form during flight checkout.
 */
public class PassengerDetailsPage extends BasePage {

    // ── Passenger Form Fields ─────────────────────────────────────────────────
    @FindBy(css = "input[name*='firstName'], input[data-testid='first-name']," +
                  " input[placeholder*='First name']")
    private WebElement firstNameInput;

    @FindBy(css = "input[name*='lastName'], input[data-testid='last-name']," +
                  " input[placeholder*='Last name']")
    private WebElement lastNameInput;

    @FindBy(css = "input[name*='email'], input[data-testid='email']," +
                  " input[type='email']")
    private WebElement emailInput;

    @FindBy(css = "input[name*='phone'], input[data-testid='phone']," +
                  " input[type='tel']")
    private WebElement phoneInput;

    // Gender / Title
    @FindBy(css = "select[name*='title'], select[data-testid='title']," +
                  " [aria-label*='Title']")
    private WebElement titleSelect;

    // Date of birth
    @FindBy(css = "input[name*='birthDay'], input[data-testid='dob-day']")
    private WebElement dobDayInput;

    @FindBy(css = "input[name*='birthMonth'], select[data-testid='dob-month']")
    private WebElement dobMonthInput;

    @FindBy(css = "input[name*='birthYear'], input[data-testid='dob-year']")
    private WebElement dobYearInput;

    // Passport / Travel docs
    @FindBy(css = "input[name*='passportNumber'], input[data-testid='passport']")
    private WebElement passportInput;

    @FindBy(css = "input[name*='nationality'], select[data-testid='nationality']")
    private WebElement nationalityInput;

    // ── Continue ──────────────────────────────────────────────────────────────
    @FindBy(css = "button[data-testid='continue'], button[type='submit']," +
                  " button[aria-label*='Continue to payment']")
    private WebElement continueBtn;

    // ── Validation ────────────────────────────────────────────────────────────
    private static final By FORM_ERROR =
            By.cssSelector("[class*='error'], [data-testid*='error'], .field-error");

    // =========================================================================

    public PassengerDetailsPage waitForPage() {
        log.info("Waiting for Passenger Details page...");
        waitForVisible(By.cssSelector("input[name*='firstName'], input[type='email']"));
        return this;
    }

    public PassengerDetailsPage fillFirstName(String name) {
        type(firstNameInput, name);
        return this;
    }

    public PassengerDetailsPage fillLastName(String name) {
        type(lastNameInput, name);
        return this;
    }

    public PassengerDetailsPage fillEmail(String email) {
        log.info("Filling email: {}", email);
        type(emailInput, email);
        return this;
    }

    public PassengerDetailsPage fillPhone(String phone) {
        type(phoneInput, phone);
        return this;
    }

    public PassengerDetailsPage fillPassengerDetails(String firstName, String lastName,
                                                      String email, String phone) {
        log.info("Filling passenger details for: {} {}", firstName, lastName);
        fillFirstName(firstName);
        fillLastName(lastName);
        fillEmail(email);
        fillPhone(phone);
        return this;
    }

    public PaymentPage continueToPayment() {
        log.info("Continuing to payment page");
        jsScrollIntoView(continueBtn);
        click(continueBtn);
        return new PaymentPage();
    }

    public boolean hasValidationErrors() {
        return !driver.findElements(FORM_ERROR).isEmpty();
    }

    public boolean isOnPassengerPage() {
        return getCurrentUrl().contains("passenger") ||
               getCurrentUrl().contains("checkout") ||
               isDisplayed(By.cssSelector("input[name*='firstName']"));
    }
}
