package com.booking.flights.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

/**
 * Page Object for Booking.com Sign-In Page.
 */
public class SignInPage extends BasePage {

    @FindBy(css = "input[name='username'], input[type='email'], #username")
    private WebElement emailInput;

    @FindBy(css = "input[name='password'], input[type='password'], #password")
    private WebElement passwordInput;

    @FindBy(css = "button[type='submit'], [data-testid='sign-in-button']," +
                  " button[aria-label*='Sign in']")
    private WebElement signInBtn;

    @FindBy(css = "button[data-testid='continue-with-email'], button[data-action='continue']")
    private WebElement continueWithEmailBtn;

    private static final By ERROR_MSG =
            By.cssSelector("[class*='error'], [data-testid='error-message'], .alert-danger");

    // =========================================================================

    public SignInPage waitForPage() {
        log.info("Waiting for Sign-In page...");
        waitForVisible(By.cssSelector("input[name='username'], input[type='email']"));
        return this;
    }

    public SignInPage enterEmail(String email) {
        log.info("Entering email: {}", email);
        type(emailInput, email);
        return this;
    }

    public SignInPage clickContinue() {
        try {
            click(continueWithEmailBtn);
            waitForVisible(By.cssSelector("input[type='password']"));
        } catch (Exception ignored) {}
        return this;
    }

    public SignInPage enterPassword(String password) {
        log.info("Entering password");
        type(passwordInput, password);
        return this;
    }

    public HomePage clickSignIn() {
        log.info("Clicking Sign In button");
        click(signInBtn);
        return new HomePage();
    }

    public HomePage signIn(String email, String password) {
        enterEmail(email);
        clickContinue();
        enterPassword(password);
        return clickSignIn();
    }

    public boolean hasError() {
        return isDisplayed(ERROR_MSG);
    }

    public String getErrorMessage() {
        return getText(ERROR_MSG);
    }
}
