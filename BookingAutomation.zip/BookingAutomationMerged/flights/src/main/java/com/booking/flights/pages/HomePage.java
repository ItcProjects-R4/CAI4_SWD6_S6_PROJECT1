package com.booking.flights.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

/**
 * Page Object for Booking.com Home Page.
 * Handles navigation tabs (Flights, Hotels, etc.) and sign-in.
 */
public class HomePage extends BasePage {

    // ── Header Navigation ─────────────────────────────────────────────────────
    @FindBy(css = "a[data-traveller-header='flights'], a[href*='/flights']")
    private WebElement flightsNavTab;

    @FindBy(css = "button[data-testid='header-sign-in-button'], a[href*='login']")
    private WebElement signInButton;

    @FindBy(css = "[data-testid='user-account-menu'], span.bui-avatar__text")
    private WebElement userAccountMenu;

    // Cookie banner
    @FindBy(id = "onetrust-accept-btn-handler")
    private WebElement cookieAcceptBtn;

    // ── Public Methods ────────────────────────────────────────────────────────

    public HomePage open() {
        navigateTo(config.getBaseUrl());
        dismissCookieBanner();
        log.info("Home page opened: {}", getCurrentUrl());
        return this;
    }

    public FlightSearchPage goToFlights() {
        log.info("Navigating to Flights tab");
        // Try the top navigation link first
        try {
            waitForClickable(By.cssSelector("a[href*='/flights']")).click();
        } catch (Exception e) {
            // Fallback: direct URL
            navigateTo(config.getBaseUrl() + "/flights");
        }
        dismissCookieBanner();
        return new FlightSearchPage();
    }

    public SignInPage goToSignIn() {
        log.info("Navigating to Sign-in page");
        click(signInButton);
        return new SignInPage();
    }

    public boolean isUserLoggedIn() {
        return isDisplayed(By.cssSelector("[data-testid='user-account-menu']"));
    }

    public MyBookingsPage goToMyBookings() {
        log.info("Navigating to My Bookings");
        click(userAccountMenu);
        click(By.cssSelector("a[href*='mybookings'], a[data-testid='my-bookings']"));
        return new MyBookingsPage();
    }

    public String getPageHeading() {
        return getText(By.cssSelector("h1, [data-testid='hero-header-title']"));
    }
}
