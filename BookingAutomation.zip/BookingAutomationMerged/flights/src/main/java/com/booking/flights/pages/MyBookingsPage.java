package com.booking.flights.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import java.util.List;

/**
 * Page Object for the "My Bookings" page.
 */
public class MyBookingsPage extends BasePage {

    private static final By BOOKING_CARD =
            By.cssSelector("[data-testid='booking-card'], [class*='BookingCard']," +
                           " [class*='booking-item'], .my-booking");

    private static final By BOOKING_STATUS =
            By.cssSelector("[data-testid='booking-status'], [class*='status-badge']");

    private static final By BOOKING_REFERENCE =
            By.cssSelector("[data-testid='booking-reference'], [class*='booking-ref']");

    private static final By LOADING =
            By.cssSelector("[data-testid='loading'], .bui-spinner");

    @FindBy(css = "h1, [data-testid='page-title']")
    private WebElement pageTitle;

    @FindBy(css = "[data-testid='no-bookings'], [class*='empty-state']")
    private WebElement noBookingsMsg;

    // Filter tabs
    @FindBy(css = "[data-testid='tab-upcoming'], button[aria-label*='Upcoming']")
    private WebElement upcomingTab;

    @FindBy(css = "[data-testid='tab-past'], button[aria-label*='Past']")
    private WebElement pastTab;

    @FindBy(css = "[data-testid='tab-cancelled'], button[aria-label*='Cancelled']")
    private WebElement cancelledTab;

    // =========================================================================

    public MyBookingsPage waitForPage() {
        log.info("Waiting for My Bookings page...");
        try { waitForInvisibility(LOADING); } catch (Exception ignored) {}
        waitForVisible(By.cssSelector("h1, [data-testid='page-title']"));
        return this;
    }

    public int getBookingCount() {
        List<WebElement> cards = driver.findElements(BOOKING_CARD);
        log.info("Booking cards found: {}", cards.size());
        return cards.size();
    }

    public boolean hasBookings() {
        return getBookingCount() > 0;
    }

    public boolean hasNoBookingsMessage() {
        return isDisplayed(By.cssSelector("[data-testid='no-bookings'], [class*='empty-state']"));
    }

    public MyBookingsPage clickUpcoming() {
        log.info("Clicking Upcoming tab");
        click(upcomingTab);
        try { waitForInvisibility(LOADING); } catch (Exception ignored) {}
        return this;
    }

    public MyBookingsPage clickPast() {
        log.info("Clicking Past tab");
        click(pastTab);
        try { waitForInvisibility(LOADING); } catch (Exception ignored) {}
        return this;
    }

    public String getFirstBookingReference() {
        List<WebElement> refs = driver.findElements(BOOKING_REFERENCE);
        return refs.isEmpty() ? "N/A" : refs.get(0).getText().trim();
    }

    public String getFirstBookingStatus() {
        List<WebElement> statuses = driver.findElements(BOOKING_STATUS);
        return statuses.isEmpty() ? "N/A" : statuses.get(0).getText().trim();
    }

    public boolean isOnMyBookingsPage() {
        return getCurrentUrl().contains("mybookings") ||
               getCurrentUrl().contains("my-bookings") ||
               getPageTitle().toLowerCase().contains("booking");
    }

    /**
     * Searches for a booking by reference number in the list.
     */
    public boolean findBookingByReference(String reference) {
        List<WebElement> refs = driver.findElements(BOOKING_REFERENCE);
        return refs.stream().anyMatch(el -> el.getText().contains(reference));
    }
}
