package com.booking.flights.utils;

import com.booking.flights.config.ConfigReader;
import com.mailosaur.MailosaurClient;
import com.mailosaur.models.Message;
import com.mailosaur.models.MessageSearchParams;
import com.mailosaur.models.SearchCriteria;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * Wrapper around the Mailosaur Java SDK.
 *
 * Usage:
 *   MailosaurHelper mailosaur = new MailosaurHelper();
 *   Message email = mailosaur.waitForEmail("booking-test");
 *   String body  = mailosaur.getEmailBodyText(email);
 */
public class MailosaurHelper {

    private static final Logger log = LogManager.getLogger(MailosaurHelper.class);
    private static final ConfigReader config = ConfigReader.getInstance();

    private final MailosaurClient client;
    private final String serverId;
    private final int timeoutSeconds;

    public MailosaurHelper() {
        this.client         = new MailosaurClient(config.getMailosaurApiKey());
        this.serverId       = config.getMailosaurServerId();
        this.timeoutSeconds = config.getMailosaurTimeout();
        log.info("MailosaurHelper initialised. Server ID: {}", serverId);
    }

    // ── Email Address Builder ─────────────────────────────────────────────────

    /**
     * Returns a full Mailosaur inbox address from an alias.
     * Format: alias@serverId.mailosaur.net
     */
    public String buildEmail(String alias) {
        return alias + "@" + config.getMailosaurDomain();
    }

    /** Returns the default test email from config.properties. */
    public String getTestEmail() {
        return config.getTestEmail();
    }

    // ── Waiting for Emails ────────────────────────────────────────────────────

    /**
     * Waits for the newest email sent to the given alias (full address auto-built).
     */
    public Message waitForEmail(String alias) throws Exception {
        String email = buildEmail(alias);
        log.info("Waiting for email to: {}", email);

        SearchCriteria criteria = new SearchCriteria();
        criteria.withSentTo(email);

        MessageSearchParams params = new MessageSearchParams();
        params.withTimeout(timeoutSeconds * 1000L); // SDK uses ms
        params.withServer(serverId);

        Message msg = client.messages().get(serverId, criteria, params);
        log.info("Email received – Subject: {}", msg.subject());
        return msg;
    }

    /**
     * Waits for an email containing a specific subject keyword.
     */
    public Message waitForEmailWithSubject(String alias, String subjectContains) throws Exception {
        String email = buildEmail(alias);
        log.info("Waiting for email to: {} with subject containing: '{}'", email, subjectContains);

        SearchCriteria criteria = new SearchCriteria();
        criteria.withSentTo(email);
        criteria.withSubject(subjectContains);

        MessageSearchParams params = new MessageSearchParams();
        params.withTimeout(timeoutSeconds * 1000L);
        params.withServer(serverId);

        Message msg = client.messages().get(serverId, criteria, params);
        log.info("Email received – Subject: {}", msg.subject());
        return msg;
    }

    // ── Extractors ────────────────────────────────────────────────────────────

    public String getSubject(Message msg) {
        return msg.subject();
    }

    public String getEmailBodyText(Message msg) {
        if (msg.text() != null && msg.text().body() != null) {
            return msg.text().body();
        }
        return "";
    }

    public String getEmailBodyHtml(Message msg) {
        if (msg.html() != null && msg.html().body() != null) {
            return msg.html().body();
        }
        return "";
    }

    /**
     * Extracts the first hyperlink from the email body that contains a keyword.
     */
    public String extractLinkContaining(Message msg, String keyword) {
        if (msg.html() == null || msg.html().links() == null) return null;
        return msg.html().links().stream()
                .filter(l -> l.href() != null && l.href().contains(keyword))
                .map(l -> l.href())
                .findFirst()
                .orElse(null);
    }

    /**
     * Extracts a verification / OTP code from the email body using a simple regex.
     * Looks for 4–8 consecutive digits.
     */
    public String extractVerificationCode(Message msg) {
        String body = getEmailBodyText(msg);
        java.util.regex.Matcher m =
                java.util.regex.Pattern.compile("\\b(\\d{4,8})\\b").matcher(body);
        return m.find() ? m.group(1) : null;
    }

    // ── Cleanup ───────────────────────────────────────────────────────────────

    /** Deletes all messages from the Mailosaur server inbox. */
    public void deleteAllMessages() throws Exception {
        client.messages().deleteAll(serverId);
        log.info("All Mailosaur messages deleted.");
    }

    /** Deletes a single message by ID. */
    public void deleteMessage(Message msg) throws Exception {
        client.messages().delete(msg.id());
        log.info("Mailosaur message deleted: {}", msg.id());
    }
}
