package com.booking.flights.listeners;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;
import com.booking.flights.config.ConfigReader;
import com.booking.flights.utils.DriverManager;
import com.booking.flights.utils.ScreenshotHelper;
import org.testng.*;

import java.io.File;

/**
 * TestNG listener that generates an Extent HTML report after the suite.
 */
public class ExtentReportListener implements ISuiteListener, ITestListener {

    private static ExtentReports extent;
    private static final ThreadLocal<ExtentTest> testThread = new ThreadLocal<>();
    private static final ConfigReader config = ConfigReader.getInstance();

    // ── Suite ─────────────────────────────────────────────────────────────────

    @Override
    public void onStart(ISuite suite) {
        String reportDir  = config.getReportsDir();
        new File(reportDir + "/screenshots").mkdirs();

        ExtentSparkReporter spark = new ExtentSparkReporter(reportDir + "/ExtentReport.html");
        spark.config().setDocumentTitle("Booking.com Automation Report");
        spark.config().setReportName("Booking.com Test Results");
        spark.config().setTheme(Theme.DARK);
        spark.config().setEncoding("utf-8");

        extent = new ExtentReports();
        extent.attachReporter(spark);
        extent.setSystemInfo("Application", "Booking.com");
        extent.setSystemInfo("Browser", config.getBrowser());
        extent.setSystemInfo("Environment", config.getBaseUrl());
        extent.setSystemInfo("Tester", System.getProperty("user.name"));
    }

    @Override
    public void onFinish(ISuite suite) {
        if (extent != null) {
            extent.flush();
        }
    }

    // ── Test ──────────────────────────────────────────────────────────────────

    @Override
    public void onTestStart(ITestResult result) {
        ExtentTest test = extent.createTest(
                result.getMethod().getMethodName(),
                result.getMethod().getDescription()
        );
        testThread.set(test);
        getTest().log(Status.INFO, "Test started: " + result.getMethod().getMethodName());
    }

    @Override
    public void onTestSuccess(ITestResult result) {
        getTest().log(Status.PASS, "Test PASSED");
    }

    @Override
    public void onTestFailure(ITestResult result) {
        getTest().log(Status.FAIL, "Test FAILED: " + result.getThrowable().getMessage());
        try {
            String screenshotPath = ScreenshotHelper.capture(
                    DriverManager.getDriver(), result.getMethod().getMethodName());
            if (screenshotPath != null) {
                getTest().addScreenCaptureFromPath(screenshotPath, "Failure Screenshot");
            }
        } catch (Exception ignored) {}
    }

    @Override
    public void onTestSkipped(ITestResult result) {
        getTest().log(Status.SKIP, "Test SKIPPED: " + result.getThrowable());
    }

    // ── Helper ────────────────────────────────────────────────────────────────

    public static ExtentTest getTest() {
        return testThread.get();
    }
}
