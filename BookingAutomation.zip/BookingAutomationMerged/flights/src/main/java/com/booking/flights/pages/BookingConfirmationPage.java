package com.booking.flights.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

/**
 * Page Object for Booking Confirmation Page.
 */
public class BookingConfirmationPage extends BasePage {

    @FindBy(css = "[data-testid='confirmation-number'], [class*='booking-ref']," +
                  " [class*='confirmation-code']")
    private WebElement confirmationNumber;

    @FindBy(css = "[data-testid='confirmation-header'], h1[class*='confirmation']," +
                  " [class*='success-title']")
    private WebElement confirmationHeader;

    @FindBy(css = "[data-testid='passenger-name'], [class*='traveller-name']")
    private WebElement passengerName;

    @FindBy(css = "[data-testid='flight-route'], [class*='route-summary']")
    private WebElement flightRoute;

    private static final By CONFIRMATION_CONTAINER =
            By.cssSelector("[data-testid='confirmation-page'], [class*='ConfirmationPage']," +
                           " [class*='booking-confirmation']");

    // =========================================================================

    public BookingConfirmationPage waitForConfirmation() {
        log.info("Waiting for booking confirmation...");
        waitForVisible(CONFIRMATION_CONTAINER);
        log.info("Booking confirmed! Reference: {}", getConfirmationNumber());
        return this;
    }

    public String getConfirmationNumber() {
        try {
            return confirmationNumber.getText().trim();
        } catch (Exception e) {
            return "N/A";
        }
    }

    public String getConfirmationHeaderText() {
        try {
            return confirmationHeader.getText().trim();
        } catch (Exception e) {
            return getText(By.tagName("h1"));
        }
    }

    public boolean isBookingConfirmed() {
        String header = getConfirmationHeaderText().toLowerCase();
        return header.contains("confirmed") || header.contains("booking")
               || header.contains("success") || !getConfirmationNumber().equals("N/A");
    }

    public String getPassengerName() {
        try { return passengerName.getText().trim(); }
        catch (Exception e) { return "N/A"; }
    }

    public String getFlightRoute() {
        try { return flightRoute.getText().trim(); }
        catch (Exception e) { return "N/A"; }
    }
}
