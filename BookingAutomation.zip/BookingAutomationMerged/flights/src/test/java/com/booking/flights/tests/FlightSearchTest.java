package com.booking.flights.tests;

import com.booking.flights.pages.FlightSearchPage;
import com.booking.flights.pages.FlightSearchResultsPage;
import com.booking.flights.pages.HomePage;
import org.testng.Assert;
import org.testng.annotations.Test;

/**
 * Unit-level tests for the Flight Search functionality.
 */
public class FlightSearchTest extends BaseTest {

    // ── TC-FL-001 ─────────────────────────────────────────────────────────────
    @Test(groups = {"smoke", "flight"},
          description = "Verify home page loads and Flights tab is accessible")
    public void testHomePageLoads() {
        log.info("TC-FL-001: Home page loads");
        HomePage homePage = new HomePage().open();
        String title = homePage.getPageTitle();
        log.info("Page title: {}", title);
        Assert.assertFalse(title.isEmpty(), "Page title should not be empty");
        Assert.assertTrue(title.toLowerCase().contains("booking"),
                "Title should contain 'Booking'");
    }

    // ── TC-FL-002 ─────────────────────────────────────────────────────────────
    @Test(groups = {"smoke", "flight"},
          description = "Verify Flight search page opens from home")
    public void testFlightSearchPageOpens() {
        log.info("TC-FL-002: Flight search page opens");
        FlightSearchPage searchPage = new HomePage().open().goToFlights();
        Assert.assertTrue(driver.getCurrentUrl().contains("flights"),
                "URL should contain 'flights'");
    }

    // ── TC-FL-003 ─────────────────────────────────────────────────────────────
    @Test(groups = {"smoke", "flight"},
          description = "Verify flight search returns results for valid origin/destination")
    public void testFlightSearchReturnsResults() {
        log.info("TC-FL-003: Flight search returns results");

        FlightSearchResultsPage results = new HomePage().open()
                .goToFlights()
                .selectRoundTrip()
                .setOrigin(config.getFlightOrigin())
                .setDestination(config.getFlightDestination())
                .setDepartureDate(config.getFlightDepartureDate())
                .setReturnDate(config.getFlightReturnDate())
                .clickSearch()
                .waitForResults();

        Assert.assertTrue(results.isOnResultsPage(),
                "Should be on flight results page");
        Assert.assertTrue(results.hasResults(),
                "Flight results should not be empty");
        log.info("Results found: {}", results.getResultsCount());
    }

    // ── TC-FL-004 ─────────────────────────────────────────────────────────────
    @Test(groups = {"flight"},
          description = "Verify one-way flight search works")
    public void testOneWayFlightSearch() {
        log.info("TC-FL-004: One-way flight search");

        FlightSearchResultsPage results = new HomePage().open()
                .goToFlights()
                .selectOneWay()
                .setOrigin(config.getFlightOrigin())
                .setDestination(config.getFlightDestination())
                .setDepartureDate(config.getFlightDepartureDate())
                .clickSearch()
                .waitForResults();

        Assert.assertTrue(results.hasResults(),
                "One-way flight results should not be empty");
    }

    // ── TC-FL-005 ─────────────────────────────────────────────────────────────
    @Test(groups = {"flight"},
          description = "Verify sort by cheapest works on results page")
    public void testSortByCheapest() {
        log.info("TC-FL-005: Sort by cheapest");

        FlightSearchResultsPage results = new HomePage().open()
                .goToFlights()
                .selectRoundTrip()
                .setOrigin(config.getFlightOrigin())
                .setDestination(config.getFlightDestination())
                .setDepartureDate(config.getFlightDepartureDate())
                .setReturnDate(config.getFlightReturnDate())
                .clickSearch()
                .waitForResults()
                .sortByCheapest();

        Assert.assertTrue(results.hasResults(),
                "Results should still be visible after sorting");
        log.info("First price after sort: {}", results.getFirstFlightPrice());
    }
}
