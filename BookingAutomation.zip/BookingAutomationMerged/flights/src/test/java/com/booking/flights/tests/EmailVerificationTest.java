package com.booking.flights.tests;

import com.booking.flights.utils.MailosaurHelper;
import com.mailosaur.models.Message;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

/**
 * Tests for email verification via Mailosaur.
 *
 * These tests assume a booking was made earlier in the suite using the
 * Mailosaur inbox address (test.account.email in config.properties).
 *
 * Run after FlightBookingE2ETest in testng.xml.
 */
public class EmailVerificationTest extends BaseTest {

    private MailosaurHelper mailosaur;

    @BeforeClass
    public void setupMailosaur() {
        mailosaur = new MailosaurHelper();
        log.info("MailosaurHelper ready. Test inbox: {}", config.getTestEmail());
    }

    // ── TC-EMAIL-001 ──────────────────────────────────────────────────────────
    @Test(groups = {"email"},
          description = "Verify booking confirmation email is received via Mailosaur")
    public void testBookingConfirmationEmailReceived() throws Exception {
        log.info("TC-EMAIL-001: Booking confirmation email check");

        Message email = mailosaur.waitForEmailWithSubject(
                config.getMailosaurTestAlias(), "booking");

        Assert.assertNotNull(email, "Confirmation email should be received");
        log.info("Email received – Subject: {}", mailosaur.getSubject(email));

        String subject = mailosaur.getSubject(email).toLowerCase();
        Assert.assertTrue(subject.contains("booking") || subject.contains("confirmation"),
                "Email subject should mention booking or confirmation. Actual: " + subject);
    }

    // ── TC-EMAIL-002 ──────────────────────────────────────────────────────────
    @Test(groups = {"email"},
          description = "Verify confirmation email body contains passenger name")
    public void testConfirmationEmailBodyContainsPassengerName() throws Exception {
        log.info("TC-EMAIL-002: Confirmation email contains passenger name");

        Message email = mailosaur.waitForEmailWithSubject(
                config.getMailosaurTestAlias(), "booking");

        String body = mailosaur.getEmailBodyText(email);
        Assert.assertFalse(body.isEmpty(), "Email body should not be empty");

        String fullName = (config.getTestFirstName() + " " + config.getTestLastName()).toLowerCase();
        Assert.assertTrue(body.toLowerCase().contains(fullName) ||
                          body.toLowerCase().contains(config.getTestFirstName().toLowerCase()),
                "Email body should contain passenger name. Body snippet: " +
                body.substring(0, Math.min(body.length(), 200)));
        log.info("TC-EMAIL-002 PASS: Passenger name found in email body");
    }

    // ── TC-EMAIL-003 ──────────────────────────────────────────────────────────
    @Test(groups = {"email"},
          description = "Verify confirmation email contains a booking reference / itinerary link")
    public void testConfirmationEmailContainsBookingLink() throws Exception {
        log.info("TC-EMAIL-003: Confirmation email contains booking link");

        Message email = mailosaur.waitForEmailWithSubject(
                config.getMailosaurTestAlias(), "booking");

        // Look for a link that references the booking / itinerary
        String link = mailosaur.extractLinkContaining(email, "booking");
        if (link == null) {
            link = mailosaur.extractLinkContaining(email, "itinerary");
        }

        Assert.assertNotNull(link,
                "Confirmation email should contain a booking or itinerary link");
        log.info("TC-EMAIL-003 PASS: Booking link found: {}", link);
    }

    // ── TC-EMAIL-004 ──────────────────────────────────────────────────────────
    @Test(groups = {"email"},
          description = "Verify flight route details are present in the email body")
    public void testConfirmationEmailContainsFlightRoute() throws Exception {
        log.info("TC-EMAIL-004: Confirmation email contains flight route");

        Message email = mailosaur.waitForEmailWithSubject(
                config.getMailosaurTestAlias(), "booking");

        String body = mailosaur.getEmailBodyHtml(email) + mailosaur.getEmailBodyText(email);
        body = body.toLowerCase();

        String origin      = config.getFlightOrigin().toLowerCase();
        String destination = config.getFlightDestination().toLowerCase();

        Assert.assertTrue(body.contains(origin) || body.contains(destination),
                "Email should mention origin (" + origin + ") or destination (" +
                destination + ")");
        log.info("TC-EMAIL-004 PASS: Flight route details found in email");
    }
}
