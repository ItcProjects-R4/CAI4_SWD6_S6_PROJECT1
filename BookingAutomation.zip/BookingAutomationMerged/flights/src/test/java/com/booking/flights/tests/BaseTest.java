package com.booking.flights.tests;

import com.booking.flights.config.ConfigReader;
import com.booking.flights.utils.DriverManager;
import com.booking.flights.utils.ScreenshotHelper;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;

/**
 * BaseTest – initialises WebDriver before each test and tears it down after.
 * All test classes extend this.
 */
public class BaseTest {

    protected static final Logger log = LogManager.getLogger(BaseTest.class);
    protected static final ConfigReader config = ConfigReader.getInstance();
    protected WebDriver driver;

    @BeforeMethod(alwaysRun = true)
    @Parameters({"browser"})
    public void setUp(@Optional("chrome") String browser) {
        log.info("========== Test Setup | Browser: {} ==========", browser);
        DriverManager.initDriver(browser);
        driver = DriverManager.getDriver();
        driver.get(config.getBaseUrl());
    }

    @AfterMethod(alwaysRun = true)
    public void tearDown(ITestResult result) {
        if (result.getStatus() == ITestResult.FAILURE) {
            log.error("Test FAILED: {}", result.getName());
            if (config.isScreenshotOnFailure()) {
                String path = ScreenshotHelper.capture(driver, result.getName());
                log.info("Failure screenshot: {}", path);
            }
        }
        log.info("========== Test Teardown | Status: {} ==========",
                result.getStatus() == ITestResult.SUCCESS ? "PASS" : "FAIL");
        DriverManager.quitDriver();
    }
}
