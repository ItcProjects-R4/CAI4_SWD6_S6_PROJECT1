package com.booking.flights.tests;

import com.booking.flights.pages.*;
import org.testng.Assert;
import org.testng.annotations.Test;

/**
 * End-to-End test: Search Flight → Select → Passenger Details → Payment → Confirmation.
 *
 * NOTE: This test uses a Mailosaur inbox email so the confirmation email
 *       can be verified in EmailVerificationTest.
 *       Payment uses a test/sandbox card – no real charge is made.
 */
public class FlightBookingE2ETest extends BaseTest {

    // Sandbox test card details (Booking.com test environment)
    private static final String TEST_CARD_NUMBER = "4111111111111111";
    private static final String TEST_CARD_HOLDER = "Test User";
    private static final String TEST_CARD_EXPIRY  = "12/26";
    private static final String TEST_CARD_CVV     = "123";

    // ── TC-E2E-001 ────────────────────────────────────────────────────────────
    @Test(groups = {"e2e", "flight"},
          description = "Full E2E: Search flight → select fare → fill passenger → payment → confirm")
    public void testFlightBookingEndToEnd() {
        log.info("TC-E2E-001: Full flight booking E2E flow");

        // Step 1 – Open home & go to flights
        HomePage home = new HomePage().open();
        log.info("Step 1: Home page opened");

        // Step 2 – Search for flights
        FlightSearchResultsPage results = home
                .goToFlights()
                .selectRoundTrip()
                .setOrigin(config.getFlightOrigin())
                .setDestination(config.getFlightDestination())
                .setDepartureDate(config.getFlightDepartureDate())
                .setReturnDate(config.getFlightReturnDate())
                .setAdults(config.getFlightAdults())
                .clickSearch()
                .waitForResults();

        Assert.assertTrue(results.hasResults(), "Step 2: Flight results should not be empty");
        log.info("Step 2: {} flights found", results.getResultsCount());

        // Step 3 – Select first flight
        FlightDetailsPage details = results.sortByCheapest().selectFirstFlight();
        details.waitForPage();
        log.info("Step 3: Flight details page loaded. Total: {}", details.getTotalPrice());

        // Step 4 – Select fare and continue to checkout
        PassengerDetailsPage passengerPage = details.selectFirstFare().continueToCheckout();
        passengerPage.waitForPage();
        log.info("Step 4: Passenger details page loaded");

        // Step 5 – Fill passenger details (using Mailosaur email for confirmation)
        PaymentPage paymentPage = passengerPage
                .fillPassengerDetails(
                        config.getTestFirstName(),
                        config.getTestLastName(),
                        config.getTestEmail(),
                        config.getTestPhone()
                )
                .continueToPayment();

        paymentPage.waitForPage();
        log.info("Step 5: Payment page loaded. Order total: {}", paymentPage.getOrderTotal());

        // Step 6 – Fill payment details
        paymentPage.fillCardDetails(
                TEST_CARD_NUMBER,
                TEST_CARD_HOLDER,
                TEST_CARD_EXPIRY,
                TEST_CARD_CVV
        );
        log.info("Step 6: Card details filled");

        // Step 7 – Submit payment
        BookingConfirmationPage confirmation = paymentPage.submitPayment();
        confirmation.waitForConfirmation();

        // Step 8 – Assert confirmation
        Assert.assertTrue(confirmation.isBookingConfirmed(),
                "Step 8: Booking should be confirmed");
        String ref = confirmation.getConfirmationNumber();
        log.info("Step 8: Booking confirmed. Reference: {}", ref);
        Assert.assertFalse(ref.equals("N/A"), "Confirmation number should be present");
    }

    // ── TC-E2E-002 ────────────────────────────────────────────────────────────
    @Test(groups = {"e2e", "flight"},
          description = "E2E with signed-in user: login → search → book → my bookings")
    public void testFlightBookingAsSignedInUser() {
        log.info("TC-E2E-002: Signed-in user flight booking flow");

        // Step 1 – Sign in
        HomePage home = new HomePage().open();
        SignInPage signIn = home.goToSignIn();
        signIn.waitForPage();
        home = signIn.signIn(config.getTestEmail(), config.getTestPassword());

        Assert.assertTrue(home.isUserLoggedIn(),
                "Step 1: User should be logged in after sign-in");
        log.info("Step 1: Signed in as {}", config.getTestEmail());

        // Step 2 – Search & select flight
        FlightSearchResultsPage results = home
                .goToFlights()
                .selectRoundTrip()
                .setOrigin(config.getFlightOrigin())
                .setDestination(config.getFlightDestination())
                .setDepartureDate(config.getFlightDepartureDate())
                .setReturnDate(config.getFlightReturnDate())
                .clickSearch()
                .waitForResults();

        Assert.assertTrue(results.hasResults(), "Step 2: Results should not be empty");

        // Step 3 – Select first flight & fare
        PassengerDetailsPage passengerPage = results
                .selectFirstFlight()
                .waitForPage()
                .selectFirstFare()
                .continueToCheckout();

        passengerPage.waitForPage();

        // For a signed-in user the form may be pre-filled; just verify & continue
        PaymentPage paymentPage = passengerPage
                .fillPassengerDetails(
                        config.getTestFirstName(),
                        config.getTestLastName(),
                        config.getTestEmail(),
                        config.getTestPhone()
                )
                .continueToPayment();

        paymentPage.waitForPage();

        // Step 4 – Pay
        BookingConfirmationPage confirmation = paymentPage
                .fillCardDetails(TEST_CARD_NUMBER, TEST_CARD_HOLDER,
                                  TEST_CARD_EXPIRY, TEST_CARD_CVV)
                .submitPayment();

        confirmation.waitForConfirmation();
        Assert.assertTrue(confirmation.isBookingConfirmed(),
                "Step 4: Booking should be confirmed");
        log.info("Step 4: Booking confirmed. Ref: {}", confirmation.getConfirmationNumber());
    }
}
