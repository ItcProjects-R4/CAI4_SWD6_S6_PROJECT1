package com.booking.flights.tests;

import com.booking.flights.pages.HomePage;
import com.booking.flights.pages.MyBookingsPage;
import com.booking.flights.pages.SignInPage;
import org.testng.Assert;
import org.testng.annotations.Test;

/**
 * Tests for the "My Bookings" section.
 */
public class MyBookingsTest extends BaseTest {

    // ── TC-MB-001 ─────────────────────────────────────────────────────────────
    @Test(groups = {"mybookings", "smoke"},
          description = "Verify My Bookings page loads for a signed-in user")
    public void testMyBookingsPageLoads() {
        log.info("TC-MB-001: My Bookings page loads for signed-in user");

        // Sign in
        HomePage home = new HomePage().open();
        SignInPage signIn = home.goToSignIn();
        signIn.waitForPage();
        home = signIn.signIn(config.getTestEmail(), config.getTestPassword());

        Assert.assertTrue(home.isUserLoggedIn(),
                "User should be logged in");

        // Navigate to My Bookings
        MyBookingsPage myBookings = home.goToMyBookings();
        myBookings.waitForPage();

        Assert.assertTrue(myBookings.isOnMyBookingsPage(),
                "Should be on My Bookings page");
        log.info("TC-MB-001 PASS: My Bookings page loaded successfully");
    }

    // ── TC-MB-002 ─────────────────────────────────────────────────────────────
    @Test(groups = {"mybookings"},
          description = "Verify upcoming tab is visible and shows bookings or empty state")
    public void testUpcomingBookingsTab() {
        log.info("TC-MB-002: Upcoming bookings tab");

        HomePage home = new HomePage().open();
        home = home.goToSignIn().waitForPage()
                   .signIn(config.getTestEmail(), config.getTestPassword());

        MyBookingsPage myBookings = home.goToMyBookings().waitForPage();
        myBookings.clickUpcoming();

        boolean hasBookings     = myBookings.hasBookings();
        boolean hasEmptyState   = myBookings.hasNoBookingsMessage();

        Assert.assertTrue(hasBookings || hasEmptyState,
                "Should show bookings list or empty state message");
        log.info("TC-MB-002 PASS | Bookings: {} | Empty state: {}",
                 hasBookings, hasEmptyState);
    }

    // ── TC-MB-003 ─────────────────────────────────────────────────────────────
    @Test(groups = {"mybookings"},
          description = "Verify past bookings tab is accessible")
    public void testPastBookingsTab() {
        log.info("TC-MB-003: Past bookings tab");

        HomePage home = new HomePage().open();
        home = home.goToSignIn().waitForPage()
                   .signIn(config.getTestEmail(), config.getTestPassword());

        MyBookingsPage myBookings = home.goToMyBookings().waitForPage();
        myBookings.clickPast();

        boolean hasBookings   = myBookings.hasBookings();
        boolean hasEmptyState = myBookings.hasNoBookingsMessage();

        Assert.assertTrue(hasBookings || hasEmptyState,
                "Past tab should show bookings or empty state");
        log.info("TC-MB-003 PASS | Past Bookings: {} | Empty: {}",
                 hasBookings, hasEmptyState);
    }

    // ── TC-MB-004 ─────────────────────────────────────────────────────────────
    @Test(groups = {"mybookings"},
          description = "Verify redirect to sign-in when accessing My Bookings without login")
    public void testMyBookingsRedirectsUnauthenticated() {
        log.info("TC-MB-004: Unauthenticated access to My Bookings");

        driver.get(config.getBaseUrl() + "/mybookings");

        String currentUrl = driver.getCurrentUrl();
        boolean redirectedToLogin = currentUrl.contains("login") ||
                                    currentUrl.contains("signin") ||
                                    currentUrl.contains("account");

        Assert.assertTrue(redirectedToLogin,
                "Unauthenticated user should be redirected to login. Actual URL: " + currentUrl);
        log.info("TC-MB-004 PASS: Redirected to: {}", currentUrl);
    }
}
