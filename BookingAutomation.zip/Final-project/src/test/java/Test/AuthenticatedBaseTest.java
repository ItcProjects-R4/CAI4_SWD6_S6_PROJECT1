package Test;

import Page.HomePage;
import Page.SignInPage;
import utils.CookieManager;
import org.testng.annotations.BeforeMethod;

public class AuthenticatedBaseTest extends BaseTest {

    protected HomePage homePage;
    protected SignInPage signInPage;

    @BeforeMethod
    public void setUpWithSignIn() throws Exception {
        if (CookieManager.tryRestoreSession(driver)) {
            homePage = new HomePage(driver);
            return;
        }

        homePage = new HomePage(driver);
        homePage.signInDirect();
        signInPage = new SignInPage(driver);
        signInPage.loginWithRandomEmail();
        CookieManager.saveSession(driver);
    }
}
