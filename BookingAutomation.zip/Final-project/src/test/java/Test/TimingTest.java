package Test;

import Page.HomePage;
import Page.SignInPage;
import org.testng.annotations.Test;

public class TimingTest extends BaseTest {

    @Test
    public void timeSignInSteps() throws Exception {
        long t0 = System.currentTimeMillis();

        HomePage hp = new HomePage(driver);
        long t1 = System.currentTimeMillis();
        System.out.println("Init HomePage: " + (t1 - t0) + "ms");

        SignInPage sp = hp.signInFromPopup();
        long t2 = System.currentTimeMillis();
        System.out.println("Navigate to sign-in: " + (t2 - t1) + "ms");

        sp.enterEmail("test@test.com");
        sp.clickContinue();
        long t3 = System.currentTimeMillis();
        System.out.println("Submit email: " + (t3 - t2) + "ms");

        Thread.sleep(3000);
        long t4 = System.currentTimeMillis();
        System.out.println("After 3s wait: " + (t4 - t3) + "ms");
        System.out.println("OTP page visible: " + sp.isOtpPageDisplayed());
    }
}
