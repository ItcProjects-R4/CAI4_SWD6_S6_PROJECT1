package Test;

import Page.*;
import org.testng.Assert;
import org.testng.annotations.Test;

public class UserJourneyTest extends BaseTest {

    @Test(description = "UJ_01: Sign in with email OTP then verify account dashboard")
    public void signInAndCheckAccount() throws Exception {
        HomePage home = new HomePage(driver);
        Assert.assertTrue(home.isSearchBarDisplayed(), "Homepage should load");

        home.signInDirect();
        SignInPage signIn = new SignInPage(driver);
        Assert.assertTrue(signIn.isSignInPageDisplayed(), "Sign-in page should open");

        signIn.loginWithRandomEmail();
        Assert.assertTrue(driver.getCurrentUrl().contains("booking.com"),
                "Should return to booking.com after sign-in");

        MyAccountPage account = home.navigateToMyAccount();
        Assert.assertTrue(account.isUrlMyAccount(), "URL should contain myaccount");
        Assert.assertTrue(account.isPageLoaded(), "Account page heading visible");
        Assert.assertTrue(account.isDisplayNameVisible(), "Display name shown");
        Assert.assertTrue(account.isGeniusLevelVisible(), "Genius level shown");

        System.out.println("Account verified for: " + account.getDisplayName());
    }

    @Test(description = "UJ_02: Search for Cairo, click first property, verify details page")
    public void searchAndCheckResults() {
        HomePage home = new HomePage(driver);
        Assert.assertTrue(home.isSearchBarDisplayed(), "Homepage search bar should be visible");

        SearchResultsPage results = home.searchFor("Cairo", null, null);

        Assert.assertTrue(results.isResultsPageDisplayed(),
                "Results page should appear after search");
        Assert.assertTrue(results.getPropertyCount() > 0,
                "At least one property card should be present");
        Assert.assertTrue(results.isUrlContains("searchresults"),
                "URL should contain searchresults");

        String name = results.getFirstPropertyName();
        System.out.println("Found " + results.getPropertyCount() + " properties, clicking: " + name);

        PropertyDetailsPage details = results.clickFirstProperty();
        System.out.println("Current URL: " + driver.getCurrentUrl());
        Assert.assertTrue(details.isLoaded(),
                "Should land on property details page for: " + name + " (URL: " + driver.getCurrentUrl() + ")");
        System.out.println("Property title: " + details.getPropertyTitle());
    }
}
