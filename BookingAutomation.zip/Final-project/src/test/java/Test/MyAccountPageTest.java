package Test;

import Page.HomePage;
import Page.MyAccountPage;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.time.Duration;

public class MyAccountPageTest extends AuthenticatedBaseTest {

    private MyAccountPage myAccountPage;

    @BeforeMethod
    public void initPage() {
        HomePage homePage = new HomePage(driver);
        myAccountPage = homePage.navigateToMyAccount();
    }

    @Test(description = "TC_ACCT_001: Verify every element on My Account page is present")
    public void verifyAllAccountPageElements() {
        Assert.assertTrue(myAccountPage.isUrlMyAccount(), "URL should contain myaccount");
        Assert.assertTrue(myAccountPage.isPageLoaded(), "Page heading should be visible");
        Assert.assertTrue(myAccountPage.isDisplayNameVisible(), "Display name");
        Assert.assertTrue(myAccountPage.isGeniusLevelVisible(), "Genius Level");
        Assert.assertTrue(myAccountPage.isProfileAvatarDisplayed(), "Profile avatar");
        Assert.assertTrue(myAccountPage.isRewardsSectionVisible(), "Genius rewards section");
        Assert.assertTrue(myAccountPage.isProgressionSectionVisible(), "Progression section");
        Assert.assertTrue(myAccountPage.isCreditsSectionVisible(), "Credits section");
        Assert.assertTrue(myAccountPage.isPaymentInfoSectionVisible(), "Payment info section");
        Assert.assertTrue(myAccountPage.isManageAccountSectionVisible(), "Manage account section");
        Assert.assertTrue(myAccountPage.isPreferencesSectionVisible(), "Preferences section");
        Assert.assertTrue(myAccountPage.isTravelActivitySectionVisible(), "Travel activity section");
        Assert.assertTrue(myAccountPage.isHelpSupportSectionVisible(), "Help and support section");
        Assert.assertTrue(myAccountPage.isLegalPrivacySectionVisible(), "Legal and privacy section");
        Assert.assertTrue(myAccountPage.isManagePropertySectionVisible(), "Manage your property section");
        Assert.assertTrue(myAccountPage.isNavRewardsWalletPresent(), "Rewards & Wallet");
        Assert.assertTrue(myAccountPage.isNavPaymentMethodsPresent(), "Payment methods");
        Assert.assertTrue(myAccountPage.isNavTransactionsPresent(), "Transactions");
        Assert.assertTrue(myAccountPage.isNavPersonalDetailsPresent(), "Personal details");
        Assert.assertTrue(myAccountPage.isNavSecuritySettingsPresent(), "Security settings");
        Assert.assertTrue(myAccountPage.isNavOtherTravelersPresent(), "Other travelers");
        Assert.assertTrue(myAccountPage.isNavCustomizationPrefsPresent(), "Customization preferences");
        Assert.assertTrue(myAccountPage.isNavEmailPrefsPresent(), "Email preferences");
        Assert.assertTrue(myAccountPage.isNavTripsBookingsPresent(), "Trips and bookings");
        Assert.assertTrue(myAccountPage.isNavSavedListsPresent(), "Saved lists");
        Assert.assertTrue(myAccountPage.isNavMyReviewsPresent(), "My reviews");
        Assert.assertTrue(myAccountPage.isNavContactCSPresent(), "Contact CS");
        Assert.assertTrue(myAccountPage.isNavSafetyCenterPresent(), "Safety center");
        Assert.assertTrue(myAccountPage.isNavDisputeResPresent(), "Dispute resolution");
        Assert.assertTrue(myAccountPage.isNavPrivacyDataPresent(), "Privacy & data");
        Assert.assertTrue(myAccountPage.isNavContentGuidePresent(), "Content guidelines");
        Assert.assertTrue(myAccountPage.isNavListPropertyPresent(), "List property");
        Assert.assertTrue(myAccountPage.isFooterContactCSPresent(), "Footer Contact CS");
        Assert.assertTrue(myAccountPage.isFooterPrivacyPresent(), "Footer Privacy");
        Assert.assertTrue(myAccountPage.isFooterTermsPresent(), "Footer Terms");
    }

    private void assertRedirect(String name, Runnable click, String expectedUrlPiece) {
        WebDriverWait w = new WebDriverWait(driver, Duration.ofSeconds(10));
        click.run();
        w.until(ExpectedConditions.urlContains(expectedUrlPiece));
        String url = driver.getCurrentUrl();
        Assert.assertTrue(url.contains(expectedUrlPiece),
                name + " should redirect to URL containing '" + expectedUrlPiece
                        + "' but got: " + url);
    }

    @Test void verifyRewardsWalletRedirect()     { assertRedirect("Rewards & Wallet",          myAccountPage::clickNavRewardsWallet,     "wallet"); }
    @Test void verifyPaymentMethodsRedirect()    { assertRedirect("Payment methods",            myAccountPage::clickNavPaymentMethods,    "payment"); }
    @Test void verifyTransactionsRedirect()       { assertRedirect("Transactions",               myAccountPage::clickNavTransactions,      "transaction"); }
    @Test void verifyPersonalDetailsRedirect()   { assertRedirect("Personal details",           myAccountPage::clickNavPersonalDetails,   "personal"); }
    @Test void verifySecuritySettingsRedirect()  { assertRedirect("Security settings",          myAccountPage::clickNavSecuritySettings,  "security"); }
    @Test void verifyOtherTravelersRedirect()    { assertRedirect("Other travelers",            myAccountPage::clickNavOtherTravelers,    "other"); }
    @Test void verifyCustomizationPrefsRedirect(){ assertRedirect("Customization preferences",   myAccountPage::clickNavCustomizationPrefs,"preferences"); }
    @Test void verifyEmailPrefsRedirect()        { assertRedirect("Email preferences",           myAccountPage::clickNavEmailPrefs,        "subscription"); }
    @Test void verifyTripsBookingsRedirect()     { assertRedirect("Trips and bookings",          myAccountPage::clickNavTripsBookings,     "mytrips"); }
    @Test void verifySavedListsRedirect()        { assertRedirect("Saved lists",                myAccountPage::clickNavSavedLists,        "wishlist"); }
    @Test void verifyMyReviewsRedirect()         { assertRedirect("My reviews",                 myAccountPage::clickNavMyReviews,         "review"); }
    @Test void verifyContactCSRedirect()          { assertRedirect("Contact CS",                 myAccountPage::clickNavContactCS,         "help"); }
    @Test void verifySafetyCenterRedirect()      { assertRedirect("Safety center",              myAccountPage::clickNavSafetyCenter,      "trust-and-safety"); }
    @Test void verifyDisputeResRedirect()        { assertRedirect("Dispute resolution",          myAccountPage::clickNavDisputeRes,        "help"); }
    @Test void verifyPrivacyDataRedirect()       { assertRedirect("Privacy & data",              myAccountPage::clickNavPrivacyData,       "privacy"); }
    @Test void verifyContentGuideRedirect()      { assertRedirect("Content guidelines",          myAccountPage::clickNavContentGuide,      "content-moderation"); }
    @Test void verifyListPropertyRedirect()      { assertRedirect("List property",              myAccountPage::clickNavListProperty,      "join.booking.com"); }
}
