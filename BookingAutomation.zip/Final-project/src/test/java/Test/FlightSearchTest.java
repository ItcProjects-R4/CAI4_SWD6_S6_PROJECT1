package Test;

import Page.FlightPage;
import Page.HomePage;
import Page.SignInPage;
import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.Test;

public class FlightSearchTest extends BaseTest {

    @Test
    public void userCanSearchForFlight() throws Exception {
        // Sign in
        HomePage homePage = new HomePage(driver);
        homePage.signInDirect();
        SignInPage signInPage = new SignInPage(driver);
        signInPage.loginWithRandomEmail();

        // Navigate to Flights
        homePage = new HomePage(driver);
        homePage.clickFlightsTab();
        FlightPage flight = new FlightPage(driver);

        //--------------------------- Flight Search-------------------------------------

        //trip type
        flight.selectTripType();
        Thread.sleep(2000);

        driver.findElement(
                By.xpath("//*[contains(text(),'Round-trip')]")
        ).click();
        Thread.sleep(2000);
        // write city origin & Destination
        flight.enterOrigin("Cairo");

        Thread.sleep(2000);

        driver.findElement(By.xpath("(//li[@role='option'])[1]")).click();

        Thread.sleep(2000);
        flight.enterDestination("Sharm");
        Thread.sleep(2000);

        flight.selectDestination("Sharm");
        Thread.sleep(1000);

        // Departure Date
        flight.setDepartureDate();
        Thread.sleep(2000);
        flight.selectDateByText("June 30, 2026");
        Thread.sleep(1000);
        // Return Date - الـ calendar هيفضل مفتوح
        flight.selectDateByText("July 1, 2026");
        Thread.sleep(1000);
        Thread.sleep(2000);

        flight.clickSearch();

        Thread.sleep(8000);


        Assert.assertTrue(driver.getCurrentUrl().contains("flights"),
                "Should navigate to flights results page");
    }


    @Test
    public void testOneWay() throws Exception {


        HomePage homePage = new HomePage(driver);
        homePage.signInDirect();
        SignInPage signInPage = new SignInPage(driver);
        signInPage.loginWithRandomEmail();

        // Navigate to Flights
        homePage = new HomePage(driver);
        homePage.clickFlightsTab();
        FlightPage flight = new FlightPage(driver);
        Thread.sleep(5000);

        // اختار One-way
        flight.selectTripType();
        Thread.sleep(2000);

        driver.findElement(
                By.xpath("//span[contains(normalize-space(),'One-way')]")
        ).click();
        Thread.sleep(2000);

        // Origin
        flight.enterOrigin("Cairo");
        Thread.sleep(2000);
        driver.findElement(By.xpath("(//li[@role='option'])[1]")).click();
        Thread.sleep(2000);

        // Destination
        flight.enterDestination("Sharm");
        Thread.sleep(2000);
        flight.selectDestination("Sharm");
        Thread.sleep(1000);

        // Departure Date فقط - مفيش Return في One-way
        flight.setDepartureDate();
        Thread.sleep(2000);
        flight.selectDateByText("June 30, 2026");
        Thread.sleep(1000);

        // Search
        flight.clickSearch();
        Thread.sleep(8000);

        Assert.assertTrue(
                driver.getCurrentUrl().contains("flights"),
                "Results page did not open for One Way!"
        );
    }
}
