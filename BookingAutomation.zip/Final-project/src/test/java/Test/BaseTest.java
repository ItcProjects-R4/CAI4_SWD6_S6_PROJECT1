package Test;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.*;
import utils.CookieManager;

import java.time.Duration;

public class BaseTest {

    protected WebDriver driver;
    protected static final String BASE_URL = "https://www.booking.com";

    @BeforeMethod
    public void setUp() {

        WebDriverManager.chromedriver().setup();

        ChromeOptions options = new ChromeOptions();



        options.addArguments("--start-maximized");
        options.addArguments("--disable-notifications");
        options.addArguments("--disable-popup-blocking");
        options.addArguments("--lang=en-US");

        driver = new ChromeDriver(options);

        driver.manage().timeouts().implicitlyWait(Duration.ZERO);
        driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(60));

        driver.get(BASE_URL);

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));

        wait.until(ExpectedConditions.or(
                ExpectedConditions.titleContains("Booking.com"),
                ExpectedConditions.presenceOfElementLocated(
                        By.xpath("//input[contains(@placeholder,'Where')]"))
        ));

        dismissCookieConsent();
    }

    private void dismissCookieConsent() {

        try {

            WebDriverWait shortWait =
                    new WebDriverWait(driver, Duration.ofSeconds(3));

            By acceptBtn =
                    By.id("onetrust-accept-btn-handler");

            WebElement button =
                    shortWait.until(
                            ExpectedConditions.elementToBeClickable(acceptBtn));

            button.click();

        } catch (TimeoutException e) {
            // Cookie popup not displayed
        }
    }

    @AfterMethod
    public void tearDown() {

        if (driver != null) {
            driver.quit();
        }
    }

    @AfterSuite
    public void cleanSuite() {
        CookieManager.cleanCookies();
    }
}