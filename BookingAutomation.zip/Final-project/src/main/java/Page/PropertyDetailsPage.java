package Page;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class PropertyDetailsPage extends BasePage {

    private final By propertyTitle = By.cssSelector("h2[data-testid='title'], h1");

    public PropertyDetailsPage(WebDriver driver) {
        super(driver);
    }

    public boolean isLoaded() {
        return !getCurrentUrl().contains("searchresults")
                && isDisplayed(propertyTitle);
    }

    public String getPropertyTitle() {
        return getText(propertyTitle);
    }
}
