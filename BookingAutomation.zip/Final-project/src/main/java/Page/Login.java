package Page;

import com.mailosaur.MailosaurClient;
import com.mailosaur.MailosaurException;
import com.mailosaur.models.Message;
import com.mailosaur.models.SearchCriteria;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import java.io.IOException;
import java.time.Duration;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Login extends BasePage {

    // Mailosaur Config
    static final String API      = "0s2mtChSDrcI85Kl4S41Eci4dYeBytwE";
    static final String SERVER_ID     = "p5vcmldl";
    static final String SERVER_DOMAIN = "p5vcmldl.mailosaur.net";

    // Locators
    By signInBtn   = By.xpath("//span[text()='Sign in or register']/parent::a");
    By emailInput  = By.cssSelector("#username");
    By continueBtn = By.xpath("//button[.//span[text()='Continue with email']]");
    By verifyBtn   = By.xpath("//button[.//span[text()='Verify email']]");

    public Login(WebDriver driver) {
        super(driver);
    }

    // Generate random email
    public static String randomEmail() {
        return "user" + System.currentTimeMillis() + "@" + SERVER_DOMAIN;
    }

    // Get OTP from Mailosaur
    public static String getOtp(String email) throws MailosaurException, IOException, InterruptedException {
        MailosaurClient client = new MailosaurClient(API);
        SearchCriteria criteria = new SearchCriteria().withSentTo(email);

        // انتظر وصول الرسالة
        Message message = client.messages().get(SERVER_ID, criteria);
        String subject = message.subject();

        Pattern pattern = Pattern.compile("Booking\\.com\\s*[–-]\\s*([A-Z0-9]+)\\s+is your verification code",
                Pattern.CASE_INSENSITIVE);
        Matcher matcher = pattern.matcher(subject);

        if (matcher.find()) return matcher.group(1);
        throw new RuntimeException("Could not find OTP in subject: " + subject);
    }

    // Actions
    public void clickSignIn() {
        driver.findElement(signInBtn).click();
    }

    public void enterEmail(String email) {
        driver.findElement(emailInput).clear();
        driver.findElement(emailInput).sendKeys(email);
    }

    public void clickContinue() {
        driver.findElement(continueBtn).click();
    }

    public void enterOtp(String otp) {
        for (int i = 0; i < otp.length(); i++) {
            driver.findElement(By.cssSelector("input[name='code_" + i + "']"))
                    .sendKeys(String.valueOf(otp.charAt(i)));
        }
    }

    public void clickVerify() {
        driver.findElement(verifyBtn).click();
    }


    // Full Login Flow
    public void performLogin() throws InterruptedException, MailosaurException, IOException {
        String email = randomEmail();
        clickSignIn();
        enterEmail(email);
        clickContinue();

        // انتظر شوية لحد ما الإيميل يوصل
        Thread.sleep(Duration.ofSeconds(10));

        String otp = getOtp(email);
        enterOtp(otp);
        clickVerify();

        System.out.println("Login successful with email: " + email);
    }
}
