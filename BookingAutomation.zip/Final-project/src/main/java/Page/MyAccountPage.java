package Page;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class MyAccountPage extends BasePage {

    // Header
    private final By skipToMainBtn   = By.xpath("//a[@href='#main' and contains(text(),'Skip')]");
    private final By bookingLogo     = By.xpath("//a[@data-testid='header-booking-logo']");
    private final By profileAvatar   = By.xpath("//button[@data-testid='header-profile']");
    private final By mobileMenuBtn   = By.xpath("//button[@data-testid='header-mobile-menu-button']");

    // User Profile Summary
    private final By pageHeading     = By.xpath("//h1[contains(text(),'Your account')]");
    private final By userProfileLink = By.xpath("//a[@href and @aria-describedby='user-profile-hint']");
    private final By displayName     = By.xpath("//div[@data-testid='display-name']");
    private final By geniusLevel     = By.xpath("//div[@data-testid='genius-status']");

    // Genius Rewards Section
    private final By rewardsHeading  = By.xpath("//h2[contains(text(),'Genius rewards')]");

    // Progression Section
    private final By progressionHeading = By.xpath("//h2[contains(text(),'bookings away from')]");
    private final By checkProgressBtn   = By.xpath("//a[contains(text(),'Check your progress')]");

    // Credits & Vouchers
    private final By creditsHeading  = By.xpath("//h2[contains(text(),'Credits and voucher')]");
    private final By creditsAmount   = By.xpath("//div[@data-testid='list-item']//div[contains(.,'No Credits')]");
    private final By goToWalletBtn   = By.xpath("//a[contains(text(),'Go to Wallet')]");

    // Navigation Links
    private final By navRewardsWallet = By.xpath("//a[.//div[text()='Rewards & Wallet']]");
    private final By navPaymentMethods = By.xpath("//a[.//div[text()='Payment methods']]");
    private final By navTransactions  = By.xpath("//a[.//div[text()='Transactions']]");
    private final By navPersonalDetails = By.xpath("//a[.//div[text()='Personal details']]");
    private final By navSecuritySettings = By.xpath("//a[.//div[text()='Security settings']]");
    private final By navOtherTravelers   = By.xpath("//a[.//div[text()='Other travelers']]");
    private final By navCustomizationPrefs = By.xpath("//a[.//div[text()='Customization preferences']]");
    private final By navEmailPrefs         = By.xpath("//a[.//div[text()='Email preferences']]");
    private final By navTripsBookings = By.xpath("//a[.//div[text()='Trips and bookings']]");
    private final By navSavedLists    = By.xpath("//a[.//div[text()='Saved lists']]");
    private final By navMyReviews     = By.xpath("//a[.//div[text()='My reviews']]");
    private final By navContactCS     = By.xpath("//a[.//div[text()='Contact Customer Service']]");
    private final By navSafetyCenter  = By.xpath("//a[.//div[text()='Safety resource center']]");
    private final By navDisputeRes    = By.xpath("//a[.//div[text()='Dispute resolution']]");
    private final By navPrivacyData   = By.xpath("//a[.//div[text()='Privacy and data management']]");
    private final By navContentGuide  = By.xpath("//a[.//div[text()='Content guidelines']]");
    private final By navListProperty  = By.xpath("//a[.//div[text()='List your property']]");

    // Section headings
    private final By paymentInfoHeading     = By.xpath("//h2[contains(.,'Payment info')]");
    private final By manageAccountHeading     = By.xpath("//h2[contains(.,'Manage account')]");
    private final By preferencesHeading       = By.xpath("//h2[contains(.,'Preferences')]");
    private final By travelActivityHeading    = By.xpath("//h2[contains(.,'Travel activity')]");
    private final By helpSupportHeading       = By.xpath("//h2[contains(.,'Help and support')]");
    private final By legalPrivacyHeading      = By.xpath("//h2[contains(.,'Legal and privacy')]");
    private final By managePropertyHeading    = By.xpath("//h2[contains(.,'Manage your property')]");

    // Footer
    private final By footerContactCS  = By.xpath("//footer//a[.//div[text()='Contact Customer Service']]");
    private final By footerPrivacy    = By.xpath("//footer//a[.//div[text()='Privacy Notice']]");
    private final By footerTerms      = By.xpath("//footer//a[.//div[text()='Terms of Service']]");

    public MyAccountPage(WebDriver driver) {
        super(driver);
    }

    // Header Checks
    public boolean isUrlMyAccount() {
        String url = getCurrentUrl();
        return url.contains("myaccount") || url.contains("secure.booking.com/account");
    }

    public boolean isPageLoaded()       { return isDisplayed(pageHeading); }
    public boolean isProfileAvatarDisplayed()  { return isDisplayed(profileAvatar); }

    // User Profile
    public boolean isDisplayNameVisible()     { return isDisplayed(displayName); }
    public boolean isGeniusLevelVisible()     { return isDisplayed(geniusLevel); }
    public String getDisplayName()            { return getText(displayName); }
    public String getPageHeading()            { return getText(pageHeading); }

    // Genius Rewards
    public boolean isRewardsSectionVisible()  { return isDisplayed(rewardsHeading); }
    public String getRewardsHeading()         { return getText(rewardsHeading); }

    // Progression
    public boolean isProgressionSectionVisible() { return isDisplayed(progressionHeading); }

    // Credits
    public boolean isCreditsSectionVisible()  { return isDisplayed(creditsHeading); }

    // Navigation Section Present
    public boolean isPaymentInfoSectionVisible()    { return isDisplayed(paymentInfoHeading); }
    public boolean isManageAccountSectionVisible()   { return isDisplayed(manageAccountHeading); }
    public boolean isPreferencesSectionVisible()     { return isDisplayed(preferencesHeading); }
    public boolean isTravelActivitySectionVisible()  { return isDisplayed(travelActivityHeading); }
    public boolean isHelpSupportSectionVisible()     { return isDisplayed(helpSupportHeading); }
    public boolean isLegalPrivacySectionVisible()    { return isDisplayed(legalPrivacyHeading); }
    public boolean isManagePropertySectionVisible()  { return isDisplayed(managePropertyHeading); }

    // Navigation Link Present
    public boolean isNavRewardsWalletPresent()     { return isDisplayed(navRewardsWallet); }
    public boolean isNavPaymentMethodsPresent()    { return isDisplayed(navPaymentMethods); }
    public boolean isNavTransactionsPresent()      { return isDisplayed(navTransactions); }
    public boolean isNavPersonalDetailsPresent()   { return isDisplayed(navPersonalDetails); }
    public boolean isNavSecuritySettingsPresent()  { return isDisplayed(navSecuritySettings); }
    public boolean isNavOtherTravelersPresent()    { return isDisplayed(navOtherTravelers); }
    public boolean isNavCustomizationPrefsPresent(){ return isDisplayed(navCustomizationPrefs); }
    public boolean isNavEmailPrefsPresent()        { return isDisplayed(navEmailPrefs); }
    public boolean isNavTripsBookingsPresent()     { return isDisplayed(navTripsBookings); }
    public boolean isNavSavedListsPresent()        { return isDisplayed(navSavedLists); }
    public boolean isNavMyReviewsPresent()         { return isDisplayed(navMyReviews); }
    public boolean isNavContactCSPresent()         { return isDisplayed(navContactCS); }
    public boolean isNavSafetyCenterPresent()      { return isDisplayed(navSafetyCenter); }
    public boolean isNavDisputeResPresent()        { return isDisplayed(navDisputeRes); }
    public boolean isNavPrivacyDataPresent()       { return isDisplayed(navPrivacyData); }
    public boolean isNavContentGuidePresent()      { return isDisplayed(navContentGuide); }
    public boolean isNavListPropertyPresent()      { return isDisplayed(navListProperty); }

    // Navigation Click Methods
    public void clickNavRewardsWallet()     { click(navRewardsWallet); }
    public void clickNavPaymentMethods()    { click(navPaymentMethods); }
    public void clickNavTransactions()      { click(navTransactions); }
    public void clickNavPersonalDetails()   { click(navPersonalDetails); }
    public void clickNavSecuritySettings()  { click(navSecuritySettings); }
    public void clickNavOtherTravelers()    { click(navOtherTravelers); }
    public void clickNavCustomizationPrefs(){ click(navCustomizationPrefs); }
    public void clickNavEmailPrefs()        { click(navEmailPrefs); }
    public void clickNavTripsBookings()     { click(navTripsBookings); }
    public void clickNavSavedLists()        { click(navSavedLists); }
    public void clickNavMyReviews()         { click(navMyReviews); }
    public void clickNavContactCS()         { click(navContactCS); }
    public void clickNavSafetyCenter()      { click(navSafetyCenter); }
    public void clickNavDisputeRes()        { click(navDisputeRes); }
    public void clickNavPrivacyData()       { click(navPrivacyData); }
    public void clickNavContentGuide()      { click(navContentGuide); }
    public void clickNavListProperty()      { click(navListProperty); }

    // Navigation Back Helper
    public MyAccountPage navigateBackToMyAccount() {
        driver.navigate().back();
        HomePage homePage = new HomePage(driver);
        return homePage.navigateToMyAccount();
    }

    // Footer Links
    public boolean isFooterContactCSPresent()  { return isDisplayed(footerContactCS); }
    public boolean isFooterPrivacyPresent()    { return isDisplayed(footerPrivacy); }
    public boolean isFooterTermsPresent()      { return isDisplayed(footerTerms); }
}
