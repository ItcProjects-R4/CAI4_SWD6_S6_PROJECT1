package Page;

import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;

public class SearchResultsPage extends BasePage {

    // Header / Search bar (re-search)
    private final By destinationInput = By.xpath("//input[@placeholder='Where are you going?']");
    private final By searchBtn        = By.xpath("//button[@type='submit' and .//span[text()='Search']]");
    private final By resultsTitle     = By.xpath("//h1[contains(@class,'title')]");
    private final By resultsCount     = By.xpath("//div[@data-testid='property-card'][1]");

    // Sort
    private final By sortDropdown     = By.xpath("//button[@data-testid='sorters-dropdown-trigger']");
    private final By sortByLowest     = By.xpath("//button[@data-id='price']");
    private final By sortByTopReview  = By.xpath("//button[@data-id='review_score_and_price']");
    private final By sortByBestRanked = By.xpath("//button[@data-id='bayesian_review_score']");

    // View Toggle
    private final By listViewBtn      = By.xpath("//button[@aria-label='List']");
    private final By gridViewBtn      = By.xpath("//button[@aria-label='Grid']");

    // Map
    private final By showOnMapBtn     = By.xpath("//button[.//span[text()='Show on map']]");

    // Property Cards
    private final By propertyCards      = By.xpath("//div[@data-testid='property-card']");
    private final By firstCard          = By.xpath("(//div[@data-testid='property-card'])[1]");
    private final By firstCardTitle = By.xpath("(//div[@data-testid='property-card'])[1]//div[@data-testid='title']");
    private final By propertyName       = By.xpath(".//div[@data-testid='title']");
    private final By propertyPrice    = By.xpath(".//span[@data-testid='price-and-discounted-price']");
    private final By propertyRating   = By.xpath(".//div[@data-testid='review-score']");
    private final By wishlistHeart    = By.xpath(".//button[@aria-label='Save the property']");

    // FILTER LOCATORS

    // Budget Slider
    private final By budgetSliderMax  = By.xpath("(//input[@type='range'])[2]");

    // Star Rating Filter
    private final By star1            = By.xpath("//label[contains(.,'1 star')]");
    private final By star2            = By.xpath("//label[contains(.,'2 stars')]");
    private final By star3            = By.xpath("//label[contains(.,'3 stars')]");
    private final By star4            = By.xpath("//label[contains(.,'4 stars')]");
    private final By star5            = By.xpath("//label[contains(.,'5 stars')]");

    // Review Score Filter
    private final By reviewAny        = By.xpath("//label[contains(.,'Any score')]");
    private final By reviewGood       = By.xpath("//label[contains(.,'Good: 7+')]");
    private final By reviewVeryGood   = By.xpath("//label[contains(.,'Very Good: 8+')]");
    private final By reviewExcellent  = By.xpath("//label[contains(.,'Wonderful: 9+')]");

    // Property Type Filter
    private final By typeHotels       = By.xpath("//label[contains(.,'Hotels')]");
    private final By typeApartments   = By.xpath("//label[contains(.,'Apartments')]");
    private final By typeVillas       = By.xpath("//label[contains(.,'Villas')]");
    private final By typeHostels      = By.xpath("//label[contains(.,'Hostels')]");

    // Amenities Filter
    private final By filterPool       = By.xpath("//label[contains(.,'Swimming pool')]");
    private final By filterParking    = By.xpath("//label[contains(.,'Free parking')]");
    private final By filterBreakfast  = By.xpath("//label[contains(.,'Breakfast included')]");
    private final By filterWifi       = By.xpath("//label[contains(.,'Free WiFi')]");
    private final By filterAirport    = By.xpath("//label[contains(.,'Airport shuttle')]");

    // Meals Filter
    private final By mealsBreakfast   = By.xpath("//label[contains(.,'Breakfast included')]");
    private final By mealsHalfBoard   = By.xpath("//label[contains(.,'Half board')]");
    private final By mealsFullBoard   = By.xpath("//label[contains(.,'Full board')]");
    private final By mealsAllInclusive= By.xpath("//label[contains(.,'All-inclusive')]");

    // Availability Filter
    private final By availabilityToggle= By.xpath("//input[@data-testid='filters-group-label-content']");

    // Sustainability Filter
    private final By sustainableToggle = By.xpath("//label[contains(.,'Travel Sustainable')]");

    // Genius Filter
    private final By geniusToggle      = By.xpath("//label[contains(.,'Genius')]");

    // Clear all filters
    private final By clearAllFilters   = By.xpath("//a[contains(text(),'Reset filters')] | //button[contains(text(),'Clear all')]");

    // Loading spinner
    private final By loadingOverlay    = By.xpath("//div[@data-testid='overlay']");

    public SearchResultsPage(WebDriver driver) {
        super(driver);
    }

    // Wait for Results

    public void waitForResultsToLoad() {
        waitForVisible(propertyCards);
    }

    // Sort Methods

    public void sortByLowestPrice() {
        click(sortDropdown);
        click(sortByLowest);
        waitForResultsToLoad();
    }

    public void sortByTopReviewScore() {
        click(sortDropdown);
        click(sortByTopReview);
        waitForResultsToLoad();
    }

    // View Methods

    public void switchToListView() { click(listViewBtn); }
    public void switchToGridView() { click(gridViewBtn); }
    public void clickShowOnMap()   { click(showOnMapBtn); }

    // Filter: Budget

    public void setBudgetSlider(int percentage) {
        WebElement slider = driver.findElement(budgetSliderMax);
        int width = slider.getSize().getWidth();
        int offset = (int) ((percentage / 100.0) * width) - (width / 2);
        new Actions(driver).clickAndHold(slider).moveByOffset(offset, 0).release().perform();
        waitForResultsToLoad();
    }

    // Filter: Star Rating

    public void filterByStar(int stars) {
        switch (stars) {
            case 1 -> click(star1);
            case 2 -> click(star2);
            case 3 -> click(star3);
            case 4 -> click(star4);
            case 5 -> click(star5);
        }
        waitForResultsToLoad();
    }

    // Filter: Review Score

    public void filterByReviewGood()      { click(reviewGood);      waitForResultsToLoad(); }
    public void filterByReviewVeryGood()  { click(reviewVeryGood);  waitForResultsToLoad(); }
    public void filterByReviewExcellent() { click(reviewExcellent); waitForResultsToLoad(); }

    // Filter: Property Type

    public void filterByHotels()     { click(typeHotels);     waitForResultsToLoad(); }
    public void filterByApartments() { click(typeApartments); waitForResultsToLoad(); }
    public void filterByVillas()     { click(typeVillas);     waitForResultsToLoad(); }
    public void filterByHostels()    { click(typeHostels);    waitForResultsToLoad(); }

    // Filter: Amenities

    public void filterByPool()       { click(filterPool);      waitForResultsToLoad(); }
    public void filterByParking()    { click(filterParking);   waitForResultsToLoad(); }
    public void filterByBreakfast()  { click(filterBreakfast); waitForResultsToLoad(); }
    public void filterByWifi()       { click(filterWifi);      waitForResultsToLoad(); }
    public void filterByAirportShuttle() { click(filterAirport); waitForResultsToLoad(); }

    // Filter: Meals

    public void filterByAllInclusive() { click(mealsAllInclusive); waitForResultsToLoad(); }
    public void filterByHalfBoard()    { click(mealsHalfBoard);    waitForResultsToLoad(); }
    public void filterByFullBoard()    { click(mealsFullBoard);    waitForResultsToLoad(); }

    // Filter: Special

    public void filterByGenius()      { click(geniusToggle);      waitForResultsToLoad(); }
    public void filterBySustainable() { click(sustainableToggle); waitForResultsToLoad(); }
    public void filterByAvailability(){ click(availabilityToggle);waitForResultsToLoad(); }

    // Clear Filters

    public void clearAllFilters() {
        if (isDisplayed(clearAllFilters)) {
            click(clearAllFilters);
            waitForResultsToLoad();
        }
    }

    // Property Cards

    public int getPropertyCount() {
        return driver.findElements(propertyCards).size();
    }

    public String getResultsCountText() {
        return getText(resultsCount);
    }

    public PropertyDetailsPage clickFirstProperty() {
        waitForVisible(firstCard);
        WebElement card = driver.findElement(firstCard);
        WebElement link = card.findElement(By.tagName("a"));
        String url = link.getAttribute("href");
        if (url != null && !url.isEmpty()) {
            driver.get(url);
        } else {
            click(firstCard);
        }
        return new PropertyDetailsPage(driver);
    }

    public String getFirstPropertyName() {
        waitForVisible(firstCardTitle);
        return driver.findElement(firstCardTitle).getText();
    }

    public void clickWishlistOnFirstProperty() {
        WebElement first = driver.findElements(propertyCards).get(0);
        first.findElement(wishlistHeart).click();
    }

    // Verifications

    public boolean isResultsPageDisplayed()    { return isDisplayed(propertyCards) || getCurrentUrl().contains("searchresults"); }
    public boolean isFilterSectionDisplayed()  { return isDisplayed(budgetSliderMax); }
    public boolean isSortDropdownDisplayed()   { return isDisplayed(sortDropdown); }
    public boolean isMapButtonDisplayed()      { return isDisplayed(showOnMapBtn); }

    public boolean isUrlContains(String keyword) {
        return getCurrentUrl().contains(keyword);
    }
}
