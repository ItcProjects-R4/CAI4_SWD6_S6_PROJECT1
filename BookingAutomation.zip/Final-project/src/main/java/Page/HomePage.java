package Page;

import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.*;

import java.time.Duration;
import java.util.List;

public class HomePage extends BasePage {

    // Nav Tabs
    private final By staysTab        = By.xpath("//a[contains(@aria-label,'Stays') or .//span[text()='Stays']]");
    private final By flightsTab      = By.xpath("//a[contains(@aria-label,'Flights') or .//span[text()='Flights']]");
    private final By carRentalsTab   = By.xpath("//a[contains(@aria-label,'Car rentals') or .//span[text()='Car rentals']]");
    private final By attractionsTab  = By.xpath("//a[contains(@aria-label,'Attractions') or .//span[text()='Attractions']]");
    private final By airportTaxisTab = By.xpath("//a[contains(@aria-label,'Airport taxis') or .//span[text()='Airport taxis']]");

    // Search Bar
    private final By destinationInput    = By.xpath("//input[@placeholder='Where are you going?']");
    private final By destinationDropdown = By.xpath("(//li[@data-testid='autocomplete-result'])[1] | (//ul[@role='listbox']//li)[1] | //div[@data-testid='search-autocomplete']//li[1]");
    private final By checkInDate         = By.xpath("//span[@data-testid='date-display-field-start']");
    private final By checkOutDate        = By.xpath("//span[@data-testid='date-display-field-end']");
    private final By guestsRoomsBtn      = By.xpath("//button[@data-testid='occupancy-config']");
    private final By searchBtn           = By.xpath("//button[@type='submit' and .//span[text()='Search']] | //button[@type='submit']//span[text()='Search']/.. | //form//button[@type='submit']");

    // Guests & Rooms
    private final By adultsIncrease   = By.xpath("(//button[@aria-label='Increase number of Adults'])[1]");
    private final By adultsDecrease   = By.xpath("(//button[@aria-label='Decrease number of Adults'])[1]");
    private final By childrenIncrease = By.xpath("(//button[@aria-label='Increase number of Children'])[1]");
    private final By roomsIncrease    = By.xpath("(//button[@aria-label='Increase number of Rooms'])[1]");

    // Calendar
    private final By nextMonthArrow  = By.xpath("//button[@aria-label='Next month']");
    private final By calendarDay     = By.xpath("//td[@role='gridcell']//span[@aria-disabled='false']");

    // Currency / Language
    private final By currencyBtn     = By.xpath("//button[@data-testid='header-currency-picker-trigger']");
    private final By languageBtn     = By.xpath("//button[@data-testid='header-language-picker-trigger']");

    // Sign In
    private final By signInBtn            = By.xpath("//a[contains(@href,'sign-in') or .//span[text()='Sign in']]");
    private final By signInOrRegister     = By.xpath("//button[.//span[text()='Sign in or register']] | //a[.//span[text()='Sign in or register']]");

    // Profile dropdown (post sign-in)
    private final By profileAvatar  = By.xpath("//button[@data-testid='header-profile']");
    private final By myAccountLink  = By.xpath("//a[contains(@href,'myaccount')]");

    // Register your property
    private final By listPropertyBtn = By.xpath("//a[.//span[contains(text(),'List your property')]]");

    // Deals & Offers section
    private final By dealsSection    = By.xpath("//section[contains(@aria-labelledby,'deals')]");
    private final By dealCards       = By.xpath("//div[@data-testid='deal-component']");

    public HomePage(WebDriver driver) {
        super(driver);
    }

    // Navigation

    public void clickStaysTab()        { click(staysTab); }
    public void clickFlightsTab()      { click(flightsTab); }
    public void clickCarRentalsTab()   { click(carRentalsTab); }
    public void clickAttractionsTab()  { click(attractionsTab); }
    public void clickAirportTaxisTab() { click(airportTaxisTab); }
    public void clickSignIn() { click(signInBtn); }

    public boolean isSignInTriggerDisplayed() { return isDisplayed(signInBtn); }

    public SignInPage signInFromPopup() {
        String current = driver.getWindowHandle();
        int winCount = driver.getWindowHandles().size();

        try {
            WebDriverWait quick = new WebDriverWait(driver, Duration.ofSeconds(3));
            WebElement btn = quick.until(ExpectedConditions.visibilityOfElementLocated(signInOrRegister));
            jsClick(signInOrRegister);
        } catch (TimeoutException e) {
            driver.get("https://account.booking.com/sign-in");
        }

        waitForSignInPage();
        return new SignInPage(driver);
    }

    public void signInDirect() {
        driver.get("https://account.booking.com/sign-in");
        waitForSignInPage();
    }

    private void waitForSignInPage() {
        wait.until(ExpectedConditions.or(
            ExpectedConditions.urlContains("account.booking.com"),
            ExpectedConditions.presenceOfElementLocated(By.cssSelector("#username"))
        ));
    }

    public void clickListProperty()    { click(listPropertyBtn); }
    public void clickCurrencyBtn()     { click(currencyBtn); }
    public void clickLanguageBtn()     { click(languageBtn); }

    // Profile Dropdown (post sign-in)

    public MyAccountPage navigateToMyAccount() {
        wait.until(ExpectedConditions.elementToBeClickable(profileAvatar));
        click(profileAvatar);
        wait.until(ExpectedConditions.elementToBeClickable(myAccountLink));
        WebElement el = driver.findElement(myAccountLink);
        new Actions(driver).doubleClick(el).perform();
        return new MyAccountPage(driver);
    }

    // Search Actions

    public void enterDestination(String destination) {
        click(destinationInput);
        WebElement input = driver.findElement(destinationInput);
        input.clear();
        for (char c : destination.toCharArray()) {
            input.sendKeys(String.valueOf(c));
            sleep(100);
        }
        try {
            WebDriverWait shortWait = new WebDriverWait(driver, Duration.ofSeconds(5));
            WebElement suggestion = shortWait.until(ExpectedConditions.visibilityOfElementLocated(destinationDropdown));
            suggestion.click();
        } catch (TimeoutException e) {
            input.sendKeys(Keys.ENTER);
        }
    }

    private void sleep(long ms) {
        try { Thread.sleep(ms); } catch (InterruptedException ignored) { }
    }

    public void openCalendar() {

        By dateButton = By.xpath(
                "//button[@data-testid='date-display-field-start']" +
                        " | //span[@data-testid='date-display-field-start']" +
                        " | //button[contains(@data-testid,'date-display')]"
        );

        wait.until(ExpectedConditions.elementToBeClickable(dateButton));

        driver.findElement(dateButton).click();

        wait.until(ExpectedConditions.presenceOfElementLocated(
                By.cssSelector("[data-date]")
        ));
    }

    public void selectDateByText(String date) {

        List<WebElement> dates =
                driver.findElements(By.cssSelector("[data-date]"));

        System.out.println("Available dates found: " + dates.size());

        By dateCell = By.cssSelector("[data-date='" + date + "']");

        wait.until(ExpectedConditions.presenceOfElementLocated(dateCell));

        WebElement element = driver.findElement(dateCell);

        ((JavascriptExecutor) driver)
                .executeScript("arguments[0].click();", element);
    }
    public void clickNextMonth() {
        click(nextMonthArrow);
    }

    public void openGuestsPanel() {
        click(guestsRoomsBtn);
    }

    public void increaseAdults(int times) {
        for (int i = 0; i < times; i++) click(adultsIncrease);
    }

    public void decreaseAdults(int times) {
        for (int i = 0; i < times; i++) click(adultsDecrease);
    }

    public void increaseChildren(int times) {
        for (int i = 0; i < times; i++) click(childrenIncrease);
    }

    public void increaseRooms(int times) {
        for (int i = 0; i < times; i++) click(roomsIncrease);
    }

    public void clickSearch() {
        click(searchBtn);
    }

    // Full Search Flow

    public SearchResultsPage searchFor(String destination, String checkIn, String checkOut) {
        enterDestination(destination);
        if (checkIn != null && checkOut != null) {
            try {
                WebDriverWait shortWait = new WebDriverWait(driver, Duration.ofSeconds(3));
                shortWait.until(d -> d.findElement(checkInDate).isDisplayed());
                click(checkInDate);
                selectDateByText(checkIn);
                selectDateByText(checkOut);
            } catch (Exception e) {
                System.out.println("Date selection skipped — " + e.getMessage());
            }
        }
        clickSearch();
        return new SearchResultsPage(driver);
    }

    // Getters / Verifications

    public boolean isSearchBarDisplayed()    { return isDisplayed(destinationInput); }
    public boolean isSignInBtnDisplayed()    { return isDisplayed(signInBtn); }
    public boolean isDealsSectionDisplayed() { return isDisplayed(dealsSection); }
    public boolean isStaysTabActive()        { return isDisplayed(staysTab); }

    public String getDestinationInputValue() {
        return driver.findElement(destinationInput).getAttribute("value");
    }

    public int getDealCardsCount() {
        return driver.findElements(dealCards).size();
    }

}
