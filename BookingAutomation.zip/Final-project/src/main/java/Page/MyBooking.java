package Page;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class MyBooking extends BasePage {

    // Breadcrumbs
    @FindBy(css = "[data-testid='breadcrumb-nav']")
    WebElement breadcrumbNav;

    @FindBy(css = "a[data-testid='breadcrumb-link']")
    WebElement breadcrumbLink;

    @FindBy(css = "[data-testid='breadcrumb-current']")
    WebElement breadcrumbCurrent;

    // China Redirect Modals
    @FindBy(css = "a.site-selelct-redirect-btn")
    WebElement switchToChinaBtn;

    @FindBy(css = "button.site-selelct-close-btn")
    WebElement stayGlobalBtn;

    @FindBy(css = "a.js_site_selelct_redirect_btn")
    WebElement gotItBtn;

    // Sticky Header Nav
    @FindBy(css = "[data-testid='Property-Header-Nav-Tab-Trigger-overview']")
    WebElement tabOverview;

    @FindBy(css = "[data-testid='Property-Header-Nav-Tab-Trigger-availability']")
    WebElement tabAvailability;

    @FindBy(css = "[data-testid='Property-Header-Nav-Tab-Trigger-facilities']")
    WebElement tabFacilities;

    @FindBy(css = "[data-testid='Property-Header-Nav-Tab-Trigger-policies']")
    WebElement tabHouseRules;

    @FindBy(css = "[data-testid='Property-Header-Nav-Tab-Trigger-reviews']")
    WebElement tabReviews;

    // Top Booking Strip
    @FindBy(css = "[data-testid='wishlist-button'][aria-label='Save this item to a trip list']")
    WebElement wishlistBtn;

    @FindBy(css = "[data-testid='property-share-button']")
    WebElement shareBtn;

    @FindBy(id = "hp_book_now_button")
    WebElement reserveBtn;

    @FindBy(css = "[data-testid='price-match-trigger']")
    WebElement priceMatchBtn;

    // Availability Section
    @FindBy(css = "button[aria-label='Select dates']")
    WebElement selectDatesBtn;

    @FindBy(css = "button[aria-label='Select occupancy']")
    WebElement selectOccupancyBtn;

    @FindBy(xpath = "//button[contains(.,'Change search')]")
    WebElement changeSearchBtn;

    @FindBy(css = "button.js-reservation-button")
    public WebElement reserveRoomBtn;

    // Reviews Section
    @FindBy(css = "[data-testid='read-all-actionable']")
    public WebElement readAllReviewsBtn;

    @FindBy(css = "label[data-testid='topic-filter-component']")
    WebElement topicFilterChip;

    public MyBooking(WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
    }

    // Actions
    public void clickBreadcrumbLink() { breadcrumbLink.click(); }
    public String getCurrentBreadcrumb() { return breadcrumbCurrent.getText(); }

    public void switchToChina() { switchToChinaBtn.click(); }
    public void stayGlobal() { stayGlobalBtn.click(); }
    public void gotIt() { gotItBtn.click(); }

    public void openOverviewTab() { tabOverview.click(); }
    public void openAvailabilityTab() { tabAvailability.click(); }
    public void openFacilitiesTab() { tabFacilities.click(); }
    public void openHouseRulesTab() { tabHouseRules.click(); }
    public void openReviewsTab() { tabReviews.click(); }

    public void addToWishlist() { wishlistBtn.click(); }
    public void shareProperty() { shareBtn.click(); }
    public void reserveProperty() { reserveBtn.click(); }
    public void clickPriceMatch() { priceMatchBtn.click(); }

    public void selectDates() { selectDatesBtn.click(); }
    public void selectOccupancy() { selectOccupancyBtn.click(); }
    public void changeSearch() { changeSearchBtn.click(); }
    public void reserveRoom() { reserveRoomBtn.click(); }

    public void readAllReviews() { readAllReviewsBtn.click(); }
    public void filterByTopic() { topicFilterChip.click(); }
}
