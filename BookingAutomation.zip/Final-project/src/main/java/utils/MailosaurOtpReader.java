package utils;

import com.mailosaur.MailosaurClient;
import com.mailosaur.MailosaurException;
import com.mailosaur.models.Message;
import com.mailosaur.models.SearchCriteria;

import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MailosaurOtpReader {

    private static final String DEFAULT_API_KEY       = "c886xSgToFrwLOov3gXoagZ1pqoAufNC";
    private static final String DEFAULT_SERVER_ID     = "b3ineavg";
    private static final String DEFAULT_SERVER_DOMAIN = "b3ineavg.mailosaur.net";

    private static final String API_KEY       = firstOf(DEFAULT_API_KEY,      System.getenv("MAILOSAUR_API_KEY"));
    private static final String SERVER_ID     = firstOf(DEFAULT_SERVER_ID,    System.getenv("MAILOSAUR_SERVER_ID"));
    private static final String SERVER_DOMAIN = firstOf(DEFAULT_SERVER_DOMAIN, System.getenv("MAILOSAUR_DOMAIN"));

    private static String firstOf(String fallback, String override) {
        return (override != null && !override.isEmpty()) ? override : fallback;
    }

    private static final Pattern OTP_PATTERN = Pattern.compile(
        "Booking\\.com\\s*[–-]\\s*([A-Z0-9]+)\\s+is your verification code",
        Pattern.CASE_INSENSITIVE);

    public static String randomEmail() {
        return "user" + System.currentTimeMillis() + "@" + SERVER_DOMAIN;
    }

    public static String getOtp(String email) throws MailosaurException, IOException {
        if (API_KEY == null || SERVER_ID == null || SERVER_DOMAIN == null) {
            throw new IllegalStateException(
                "Mailosaur credentials not configured — edit DEFAULT_* fields in MailosaurOtpReader");
        }

        MailosaurClient client = new MailosaurClient(API_KEY);
        SearchCriteria criteria = new SearchCriteria().withSentTo(email);
        Message message = client.messages().get(SERVER_ID, criteria);

        String subject = message.subject();
        System.out.println("Mailosaur subject: " + subject);
        Matcher matcher = OTP_PATTERN.matcher(subject);
        if (matcher.find()) {
            return matcher.group(1);
        }

        throw new RuntimeException("Could not find OTP in subject: " + subject);
    }
}
